import Link from "next/link";
import db from "@/lib/db";
import { EpisodeStatusBadge, VersionStatusBadge, Badge } from "@/components/ui/badge";
import { evaluateCreditUsage } from "@/lib/rules/credits";
import { PURPOSE_LABELS, formatDateDot } from "@/lib/types";
import { ShieldAlert, AlertTriangle } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const [
    memberCount,
    episodeCount,
    channelCount,
    episodes,
    budget,
    recentRuns,
    incompleteVersions,
    beforePublishItems,
    allChecks,
  ] = await Promise.all([
    db.member.count(),
    db.episode.count(),
    db.channel.count(),
    db.episode.findMany({
      include: {
        versions: {
          include: { channel: true },
        },
      },
      orderBy: { no: "asc" },
    }),
    db.budgetMonth.findFirst({
      orderBy: { month: "desc" },
    }),
    db.generationRun.findMany({
      take: 5,
      orderBy: { createdAt: "desc" },
      include: { episode: true },
    }),
    db.channelVersion.findMany({
      where: {
        status: { not: "DONE" },
        channel: { active: true },
        episode: {
          status: { in: ["SCRIPTED", "GENERATED", "EDITED", "REVIEWED"] },
        },
      },
      include: {
        episode: true,
        channel: true,
      },
      orderBy: [{ episode: { no: "asc" } }, { channelCode: "asc" }],
    }),
    db.complianceItem.findMany({
      where: { blockAt: "BEFORE_PUBLISH" },
    }),
    db.complianceCheck.findMany(),
  ]);

  if (memberCount === 0 && episodeCount === 0 && channelCount === 0) {
    return (
      <div className="rounded-[8px] border border-zinc-200 bg-white p-6 text-xs text-zinc-600">
        아직 데이터가 없습니다. <code>npm run db:seed</code>를 실행하세요.
      </div>
    );
  }

  const publishedCount = episodes.filter((e) => e.status === "PUBLISHED").length;
  const creditUsed = budget?.creditUsed ?? 0;
  const creditCap = budget?.creditCap ?? 9400;
  const creditUsage = evaluateCreditUsage(creditUsed, creditCap);

  // 차단된 회차: 공개 전인데 BEFORE_PUBLISH 필수 검수 미완료 회차 (특히 3·6·7화 약기법)
  const beforePublishCodes = new Set(beforePublishItems.map((i) => i.code));
  const blockedEpisodes = episodes.filter((ep) => {
    if (ep.status === "PUBLISHED") return false;
    const epChecks = allChecks.filter(
      (c) =>
        c.episodeId === ep.id &&
        beforePublishCodes.has(c.itemCode) &&
        (c.itemCode !== "JP-04" || ep.complianceRisk)
    );
    const hasIncompleteCompliance = epChecks.some((c) => !c.done);
    return ep.complianceRisk && hasIncompleteCompliance;
  });

  // SPEC 4.1.1 최상단 빨간 경고 배너 3가지 조건 점검
  const alertReasons: string[] = [];

  if (incompleteVersions.length > 0) {
    const summary = incompleteVersions
      .map((v) => `${v.episode.no}화(${v.channelCode})`)
      .join(", ");
    alertReasons.push(
      `이번 주 발행 예정 회차 중 미완성 채널 버전이 ${incompleteVersions.length}건 있습니다: ${summary}`
    );
  }

  if (creditUsage.alertLevel === "blocker") {
    alertReasons.push(
      `이번 달 크레딧 사용률이 ${creditUsage.usagePercent}% (${creditUsed.toLocaleString()} / ${creditCap.toLocaleString()})로 90% 위험 임계치를 넘었습니다.`
    );
  }

  if (blockedEpisodes.length > 0) {
    alertReasons.push(
      `공개 예정 회차 중 컴플라이언스(약기법 JP-04 등) 미완료로 발행 차단된 회차가 있습니다: ${blockedEpisodes
        .map((e) => `${e.no}화`)
        .join(", ")}`
    );
  }

  return (
    <div className="space-y-4">
      {/* 1. 최상단 빨간 경고 배너 (SPEC 4.1.1 & AC-12) */}
      {alertReasons.length > 0 && (
        <div
          role="alert"
          data-testid="dashboard-red-alert-banner"
          className="rounded-[8px] border border-red-300 bg-red-50 p-3.5 text-xs text-red-900"
        >
          <div className="flex items-center gap-2 font-bold text-red-800">
            <ShieldAlert className="h-4 w-4 shrink-0 text-red-600" />
            <span>운영 긴급 점검 필요 ({alertReasons.length}건)</span>
          </div>
          <ul className="mt-1.5 list-disc space-y-0.5 pl-5 text-red-800">
            {alertReasons.map((reason, idx) => (
              <li key={idx}>{reason}</li>
            ))}
          </ul>
        </div>
      )}

      {/* 크레딧 80%~89% 주황 경고 배너 */}
      {creditUsage.alertLevel === "warning" && (
        <div
          role="status"
          className="flex items-center gap-2 rounded-[8px] border border-amber-300 bg-amber-50 px-3.5 py-2.5 text-xs font-medium text-amber-900"
        >
          <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600" />
          <span>{creditUsage.alertMessage}</span>
        </div>
      )}

      {/* 상단 타이틀 및 DB 요약 */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
        <div>
          <h1 className="text-base font-bold text-zinc-900">운영 대시보드</h1>
          <p className="text-xs text-zinc-500">
            오늘 처리할 채널 재조립 버전과 리소스 현황을 확인합니다.
          </p>
        </div>
        <div className="font-mono text-[11px] text-zinc-500">
          Members {memberCount} · Episodes {episodeCount} · Channels {channelCount}
        </div>
      </div>

      {/* 2. 4개 지표 카드 */}
      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="rounded-[8px] border border-zinc-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-zinc-500">이번 주 발행 수</div>
          <div className="mt-1.5 flex items-baseline justify-between">
            <span className="font-mono text-xl font-bold text-zinc-900">
              {publishedCount}본
            </span>
            <Badge variant="teal">누적 완료</Badge>
          </div>
          <div className="mt-1 text-[11px] text-zinc-400">
            3채널(JP·US·KR) 동시 발행 기준
          </div>
        </div>

        <div className="rounded-[8px] border border-zinc-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-zinc-500">이번 주 목표</div>
          <div className="mt-1.5 flex items-baseline justify-between">
            <span className="font-mono text-xl font-bold text-zinc-900">2본</span>
            <span className="font-mono text-[11px] text-zinc-500">25.3시간/주</span>
          </div>
          <div className="mt-1 text-[11px] text-zinc-400">
            숏폼 15.7h + 참여 4.5h + 장편 5.1h
          </div>
        </div>

        <div className="rounded-[8px] border border-zinc-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-zinc-500">월 크레딧 사용률</div>
          <div className="mt-1.5 flex items-baseline justify-between">
            <span className="font-mono text-xl font-bold text-zinc-900">
              {creditUsage.usagePercent}%
            </span>
            <span className="font-mono text-[11px] text-zinc-500">
              {creditUsed.toLocaleString()} / {creditCap.toLocaleString()}
            </span>
          </div>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-[2px] bg-zinc-100">
            <div
              className={
                creditUsage.alertLevel === "blocker"
                  ? "h-full bg-red-600"
                  : creditUsage.alertLevel === "warning"
                  ? "h-full bg-amber-500"
                  : "h-full bg-[#1F5E63]"
              }
              style={{ width: `${Math.min(100, creditUsage.usagePercent)}%` }}
            />
          </div>
        </div>

        <div className="rounded-[8px] border border-zinc-200 bg-white p-3.5">
          <div className="text-[11px] font-medium text-zinc-500">차단된 회차 수</div>
          <div className="mt-1.5 flex items-baseline justify-between">
            <span className="font-mono text-xl font-bold text-red-700">
              {blockedEpisodes.length}화
            </span>
            <Badge variant={blockedEpisodes.length > 0 ? "amber" : "default"}>
              약기법 대상
            </Badge>
          </div>
          <div className="mt-1 text-[11px] text-zinc-400">
            {blockedEpisodes.length > 0
              ? `검수 필요: ${blockedEpisodes.map((e) => `${e.no}화`).join(", ")}`
              : "차단된 위험 회차 없음"}
          </div>
        </div>
      </section>

      {/* 하단 2열: 3. 이번 주 할 일 / 4. 최근 생성 기록 */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* 3. 이번 주 할 일 — 미완성 채널 버전 목록 (클릭 시 해당 채널 편집 화면 이동) */}
        <section className="rounded-[8px] border border-zinc-200 bg-white lg:col-span-7">
          <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-2.5">
            <div>
              <h2 className="text-xs font-bold text-zinc-900">
                이번 주 할 일 (미완성 채널 버전)
              </h2>
              <p className="text-[11px] text-zinc-500">
                클릭 시 해당 회차·채널 재조립 편집 화면으로 이동합니다.
              </p>
            </div>
            <Badge variant="teal">{incompleteVersions.length}건</Badge>
          </div>

          {incompleteVersions.length === 0 ? (
            <div className="p-6 text-center text-xs text-zinc-500">
              진행 중인 미완성 채널 버전이 없습니다.
            </div>
          ) : (
            <div className="divide-y divide-zinc-200">
              {incompleteVersions.map((ver) => (
                <Link
                  key={ver.id}
                  href={`/episodes/${ver.episode.no}/channels/${ver.channelCode}`}
                  className="flex items-center justify-between gap-3 px-4 py-2.5 text-xs transition-colors hover:bg-zinc-50"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-semibold text-[#1F5E63]">
                        제{ver.episode.no}화
                      </span>
                      <span className="truncate font-medium text-zinc-900">
                        {ver.episode.title}
                      </span>
                      {ver.episode.complianceRisk && (
                        <Badge variant="amber">약기법</Badge>
                      )}
                    </div>
                    <div className="mt-0.5 flex items-center gap-2 text-[11px] text-zinc-500">
                      <span className="font-mono font-semibold text-zinc-700">
                        [{ver.channelCode}]
                      </span>
                      <span>{ver.channel.label}</span>
                      <span>·</span>
                      <span>
                        규격 {ver.channel.totalSec}초 / {ver.channel.cutCount}컷
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <EpisodeStatusBadge status={ver.episode.status} />
                    <VersionStatusBadge status={ver.status} />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </section>

        {/* 4. 최근 생성 기록 — 최근 5건 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white lg:col-span-5">
          <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-2.5">
            <div>
              <h2 className="text-xs font-bold text-zinc-900">최근 생성 기록</h2>
              <p className="text-[11px] text-zinc-500">최근 5건 (외부 생성 수동 기록)</p>
            </div>
            <Link
              href="/credits"
              className="text-[11px] font-medium text-[#1F5E63] hover:underline"
            >
              전체 보기
            </Link>
          </div>

          {recentRuns.length === 0 ? (
            <div className="p-6 text-center text-xs text-zinc-500">
              기록된 생성 내역이 없습니다.
            </div>
          ) : (
            <div className="divide-y divide-zinc-200">
              {recentRuns.map((run) => (
                <div
                  key={run.id}
                  className="flex items-center justify-between gap-2 px-4 py-2.5 text-xs"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-semibold text-zinc-800">
                        제{run.episode.no}화
                      </span>
                      <Badge variant="default">{run.model}</Badge>
                      <span className="text-[11px] text-zinc-500">
                        {PURPOSE_LABELS[run.purpose] ?? run.purpose}
                      </span>
                    </div>
                    <div className="mt-0.5 text-[11px] text-zinc-400">
                      시도 {run.attempts}회 · 채택 {run.accepted}컷 ·{" "}
                      {formatDateDot(run.createdAt)}
                    </div>
                  </div>
                  <div className="shrink-0 text-right font-mono text-xs font-semibold text-zinc-900">
                    {run.credits.toLocaleString()} 크레딧
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
