import type { EpisodeStatus, VersionStatus } from "@prisma/client";

export const EPISODE_STATUS_LABELS: Record<EpisodeStatus, string> = {
  PLANNING: "기획",
  SCRIPTED: "대본",
  GENERATED: "생성",
  EDITED: "편집",
  REVIEWED: "검수",
  PUBLISHED: "발행",
};

export const EPISODE_STATUS_ORDER: EpisodeStatus[] = [
  "PLANNING",
  "SCRIPTED",
  "GENERATED",
  "EDITED",
  "REVIEWED",
  "PUBLISHED",
];

export const VERSION_STATUS_LABELS: Record<VersionStatus, string> = {
  TODO: "대기",
  IN_PROGRESS: "진행중",
  DONE: "완료",
  BLOCKED: "차단",
};

export const PURPOSE_LABELS: Record<string, string> = {
  base: "베이스 생성",
  collection: "집합 컷",
  retry: "재생성",
};

export function toStringArray(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value.filter((item): item is string => typeof item === "string");
  }
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) {
        return parsed.filter((item): item is string => typeof item === "string");
      }
    } catch {
      return [];
    }
  }
  return [];
}

export function formatDateDot(date: Date | string | null | undefined): string {
  if (!date) return "-";
  const d = typeof date === "string" ? new Date(date) : date;
  if (Number.isNaN(d.getTime())) return "-";
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}.${mm}.${dd}`;
}
