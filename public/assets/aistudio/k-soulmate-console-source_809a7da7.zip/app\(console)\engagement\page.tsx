import db from "@/lib/db";
import { Badge } from "@/components/ui/badge";
import { EngagementClient } from "@/components/engagement-client";

export const dynamic = "force-dynamic";

export default async function EngagementPage() {
  const [gauges, candidates, missions] = await Promise.all([
    db.gauge.findMany({ orderBy: { id: "asc" } }),
    db.fandomCandidate.findMany({ orderBy: { id: "asc" } }),
    db.mission.findMany({
      include: { episode: true },
      orderBy: { id: "asc" },
    }),
  ]);

  if (gauges.length === 0 && candidates.length === 0 && missions.length === 0) {
    return (
      <div className="rounded-[8px] border border-zinc-200 bg-white p-6 text-xs text-zinc-600">
        아직 데이터가 없습니다. <code>npm run db:seed</code>를 실행하세요.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
        <div>
          <h1 className="text-base font-bold text-zinc-900">
            참여 관리 (응원 게이지 · 팬덤명 후보 · 미션 회수)
          </h1>
          <p className="text-xs text-zinc-500">
            팬 참여형 콘텐츠(편당 4.5시간)의 해금 게이지와 팬덤명 5대 검수 게이트를 운영합니다.
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          <Badge variant="teal">
            SHORTLIST {candidates.filter((c) => c.status === "SHORTLIST").length}건
          </Badge>
          <Badge variant="default">
            채택 미션 {missions.filter((m) => m.status === "ADOPTED").length}건
          </Badge>
        </div>
      </div>

      <EngagementClient
        gauges={gauges}
        candidates={candidates}
        missions={missions}
      />
    </div>
  );
}
