"use client";

import React, { useState } from "react";
import Image from "next/image";
import type { Member } from "@prisma/client";
import { Badge } from "@/components/ui/badge";
import { Copy, Check, X, Lock, Unlock, FileText } from "lucide-react";
import { cn } from "@/lib/utils";

interface MemberGridProps {
  members: Member[];
}

export function MemberGrid({ members }: MemberGridProps) {
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopyPrompt = async (member: Member, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const combinedPrompt = `${member.outfitSpec}\n${member.faceSpec}`;
    try {
      await navigator.clipboard.writeText(combinedPrompt);
      setCopiedId(member.id);
      setTimeout(() => {
        setCopiedId((prev) => (prev === member.id ? null : prev));
      }, 2000);
    } catch {
      // Fallback for restricted clipboard contexts
      const textarea = document.createElement("textarea");
      textarea.value = combinedPrompt;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      setCopiedId(member.id);
      setTimeout(() => {
        setCopiedId((prev) => (prev === member.id ? null : prev));
      }, 2000);
    }
  };

  return (
    <>
      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
        {members.map((member) => {
          const isLocked = member.locked;
          const hasAnimeSheet = Boolean(member.animeSheetUrl);

          return (
            <div
              key={member.id}
              role="button"
              tabIndex={0}
              onClick={() => setSelectedMember(member)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  setSelectedMember(member);
                }
              }}
              className={cn(
                "group flex flex-col overflow-hidden rounded-[8px] bg-white text-left transition-colors hover:border-[#1F5E63]",
                isLocked
                  ? "border border-zinc-200"
                  : "border-2 border-dashed border-amber-400"
              )}
            >
              {/* 실사 시트 썸네일 */}
              <div className="relative aspect-[16/10] w-full bg-zinc-100 border-b border-zinc-200">
                <Image
                  src={member.photoSheetUrl}
                  alt={`${member.nameKo} 실사 캐릭터 시트`}
                  fill
                  sizes="(max-width: 640px) 100vw, 50vw"
                  className="object-cover object-top"
                />
                <div className="absolute left-2.5 top-2.5 flex items-center gap-1.5">
                  <span className="rounded-[2px] bg-zinc-900/85 px-1.5 py-0.5 font-mono text-[11px] font-bold text-white">
                    {member.id}
                  </span>
                  {member.channelCode && (
                    <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[11px] font-semibold text-white">
                      담당 {member.channelCode}
                    </span>
                  )}
                </div>
                <div className="absolute right-2.5 top-2.5 flex items-center gap-1.5">
                  {isLocked ? (
                    <Badge variant="tealSolid" className="gap-1">
                      <Lock className="h-3 w-3" />
                      락 확정
                    </Badge>
                  ) : (
                    <Badge variant="amber" className="gap-1">
                      <Unlock className="h-3 w-3" />
                      락 미확정
                    </Badge>
                  )}
                </div>
              </div>

              {/* 카드 본문 */}
              <div className="flex flex-1 flex-col justify-between p-3.5">
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-baseline gap-1.5">
                      <h2 className="text-sm font-bold text-zinc-900">
                        {member.nameKo}
                      </h2>
                      <span className="text-[11px] text-zinc-400">
                        {member.nameJa} · {member.nameZh}
                      </span>
                    </div>
                    {hasAnimeSheet ? (
                      <Badge variant="amber">애니 시트 (판정 3/5 · 보류)</Badge>
                    ) : (
                      <Badge variant="muted">애니 시트 미제작</Badge>
                    )}
                  </div>

                  <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-zinc-600">
                    <span>{member.nationality}</span>
                    <span className="text-zinc-300">|</span>
                    <span className="font-medium text-zinc-800">
                      {member.position}
                    </span>
                    <span className="text-zinc-300">|</span>
                    <span className="font-mono">
                      {member.age}세 · {member.heightCm}cm
                    </span>
                  </div>

                  <p className="mt-2 line-clamp-1 font-mono text-[11px] text-zinc-500">
                    의상: {member.outfitSpec}
                  </p>
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-zinc-100 pt-2.5 text-[11px]">
                  <span className="font-mono text-zinc-400">
                    보이스: {member.voiceProfile ?? "미지정"}
                  </span>
                  <span className="font-semibold text-[#1F5E63] group-hover:underline">
                    상세 · 프롬프트 보기 →
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* 멤버 상세 모달 */}
      {selectedMember && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-3.5"
          onClick={() => setSelectedMember(null)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="member-modal-title"
            className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-[8px] border border-zinc-200 bg-white"
            onClick={(e) => e.stopPropagation()}
          >
            {/* 모달 헤더 */}
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-zinc-200 bg-white px-4 py-3">
              <div className="flex items-center gap-2">
                <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-xs font-bold text-white">
                  {selectedMember.id}
                </span>
                <h3
                  id="member-modal-title"
                  className="text-sm font-bold text-zinc-900"
                >
                  {selectedMember.nameKo} ({selectedMember.nameJa} ·{" "}
                  {selectedMember.nameZh})
                </h3>
                {selectedMember.locked ? (
                  <Badge variant="tealSolid">락 확정</Badge>
                ) : (
                  <Badge variant="amber">락 미확정</Badge>
                )}
              </div>
              <button
                type="button"
                onClick={() => setSelectedMember(null)}
                aria-label="닫기"
                className="rounded-[4px] p-1 text-zinc-500 hover:bg-zinc-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-4 p-4">
              {/* 실사 시트 원본 */}
              <div>
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="text-xs font-semibold text-zinc-800">
                    실사 캐릭터 시트 원본 (검증 완료)
                  </span>
                  <span className="font-mono text-[11px] text-zinc-500">
                    {selectedMember.nationality} · {selectedMember.position} ·{" "}
                    {selectedMember.age}세 · {selectedMember.heightCm}cm
                  </span>
                </div>
                <div className="relative aspect-[4/3] w-full overflow-hidden rounded-[6px] border border-zinc-200 bg-zinc-100">
                  <Image
                    src={selectedMember.photoSheetUrl}
                    alt={`${selectedMember.nameKo} 실사 캐릭터 시트 원본`}
                    fill
                    sizes="(max-width: 768px) 100vw, 640px"
                    className="object-contain"
                  />
                </div>
              </div>

              {/* 고정 의상 & 얼굴 고정 조건 */}
              <div className="space-y-3 rounded-[6px] border border-zinc-200 bg-zinc-50 p-3.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-900">
                    생성 고정 프롬프트 (outfitSpec + faceSpec)
                  </span>
                  <button
                    type="button"
                    onClick={(e) => handleCopyPrompt(selectedMember, e)}
                    className="inline-flex items-center gap-1.5 rounded-[4px] bg-[#1F5E63] px-3 py-1.5 text-xs font-medium text-white transition-colors hover:bg-[#17494d]"
                  >
                    {copiedId === selectedMember.id ? (
                      <>
                        <Check className="h-3.5 w-3.5" />
                        복사 완료
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        프롬프트 복사
                      </>
                    )}
                  </button>
                </div>

                <div className="space-y-2 text-xs">
                  <div>
                    <div className="text-[11px] font-semibold text-zinc-500">
                      고정 의상 (outfitSpec)
                    </div>
                    <p className="mt-0.5 rounded-[4px] border border-zinc-200 bg-white p-2 font-mono text-[11px] text-zinc-800">
                      {selectedMember.outfitSpec}
                    </p>
                  </div>

                  <div>
                    <div className="text-[11px] font-semibold text-zinc-500">
                      얼굴 고정 조건 (faceSpec)
                    </div>
                    <p className="mt-0.5 rounded-[4px] border border-zinc-200 bg-white p-2 font-mono text-[11px] text-zinc-800">
                      {selectedMember.faceSpec}
                    </p>
                  </div>
                </div>
              </div>

              {/* 애니메이션 시트 상태 안내 */}
              <div className="rounded-[6px] border border-zinc-200 p-3.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-zinc-800">
                    애니메이션 캐릭터 시트
                  </span>
                  {selectedMember.animeSheetUrl ? (
                    <Badge variant="amber">파일럿 테스트 3/5 (그대로 사용 불가)</Badge>
                  ) : (
                    <Badge variant="muted">애니 시트 미제작</Badge>
                  )}
                </div>

                {selectedMember.animeSheetUrl ? (
                  <div className="mt-2 space-y-2">
                    <div className="relative aspect-[4/3] w-full overflow-hidden rounded-[4px] border border-zinc-200 bg-zinc-100">
                      <Image
                        src={selectedMember.animeSheetUrl}
                        alt={`${selectedMember.nameKo} 애니 시트 테스트`}
                        fill
                        sizes="(max-width: 768px) 100vw, 640px"
                        className="object-contain"
                      />
                    </div>
                    <p className="text-[11px] text-amber-800">
                      의상(5/5)과 색감은 일치하나 얼굴 동일성 3/5(13~15세로 보임)로 판정되어 실사 시트 입력 변환 방식으로 재시도 예정입니다. 5명 전원 완성 전까지 실사화 기능은 비활성입니다. (참조:{" "}
                      <span className="inline-flex items-center gap-0.5 font-mono underline">
                        <FileText className="h-3 w-3" />
                        prompts/character-anime.md
                      </span>
                      )
                    </p>
                  </div>
                ) : (
                  <div className="mt-2 flex items-center justify-between rounded-[4px] bg-zinc-50 px-3 py-2 text-[11px] text-zinc-600">
                    <span>애니 시트 미제작 — 실사 시트 참조 변환 방식으로 제작 예정</span>
                    <span className="inline-flex items-center gap-1 font-mono font-medium text-[#1F5E63]">
                      <FileText className="h-3 w-3" />
                      prompts/character-anime.md
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
