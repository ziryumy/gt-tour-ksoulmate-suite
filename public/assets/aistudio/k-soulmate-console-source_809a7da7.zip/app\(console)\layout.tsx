import React from "react";
import { ConsoleSidebar } from "@/components/console-sidebar";

export default function ConsoleLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-[#f8f9fa] text-zinc-900">
      <ConsoleSidebar />
      <div className="md:pl-56">
        <main className="mx-auto max-w-6xl px-3.5 py-4 sm:px-5 sm:py-5">
          {children}
        </main>
      </div>
    </div>
  );
}
