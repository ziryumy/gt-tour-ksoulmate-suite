import type { VersionStatus } from "@prisma/client";

export interface PublishGateEpisodeInput {
  no: number;
  complianceRisk: boolean;
  versions: Array<{
    channelCode: string;
    status: VersionStatus;
    channel?: {
      active: boolean;
    };
  }>;
  checks: Array<{
    itemCode: string;
    done: boolean;
    item?: {
      code: string;
      label: string;
      blockAt: string;
    };
  }>;
}

export interface PublishGateResult {
  canPublish: boolean;
  incompleteChannels: string[];
  incompleteChecks: string[];
  reason: string | null;
}

const ACTIVE_CHANNEL_ORDER = ["JP", "US", "KR"];

/**
 * SPEC 5.2 발행 게이트
 * canPublish(episode):
 * 1. active 채널(JP/US/KR) 중 status !== DONE 인 것이 없어야 함
 * 2. blockAt = BEFORE_PUBLISH 인 ComplianceCheck 중 done = false 가 없어야 함
 *    (단, JP-04 약기법 항목은 complianceRisk 회차(3·6·7화)에서 필수이며, 일반 회차에서도 BEFORE_PUBLISH 항목이 미완료면 차단)
 * 3. 두 조건 모두 만족해야 true
 */
export function canPublish(episode: PublishGateEpisodeInput): PublishGateResult {
  // 1. 활성 채널(JP, US, KR) 중 DONE이 아닌 채널 추출
  const incompleteChannels: string[] = [];

  for (const code of ACTIVE_CHANNEL_ORDER) {
    const found = episode.versions.find((v) => v.channelCode === code);
    const isActive = found?.channel ? found.channel.active : code !== "CN";
    if (isActive && (!found || found.status !== "DONE")) {
      incompleteChannels.push(code);
    }
  }

  // 2. blockAt = BEFORE_PUBLISH 항목 중 미완료 항목 추출
  const incompleteChecks: string[] = [];
  for (const chk of episode.checks) {
    const blockAt = chk.item?.blockAt ?? (chk.itemCode <= "JP-04" ? "BEFORE_PUBLISH" : "AT_LAUNCH");
    if (blockAt !== "BEFORE_PUBLISH") continue;

    // JP-04(약기법)는 complianceRisk(3·6·7화)에서 필수 검수 대상
    if (chk.itemCode === "JP-04" && !episode.complianceRisk) {
      continue;
    }

    if (!chk.done) {
      incompleteChecks.push(chk.itemCode);
    }
  }

  // 만약 complianceRisk 회차인데 JP-04 체크 레코드 자체가 누락된 경우도 차단
  if (
    episode.complianceRisk &&
    !episode.checks.some((c) => c.itemCode === "JP-04" && c.done) &&
    !incompleteChecks.includes("JP-04")
  ) {
    incompleteChecks.push("JP-04");
  }

  incompleteChecks.sort();

  const ok = incompleteChannels.length === 0 && incompleteChecks.length === 0;

  if (ok) {
    return {
      canPublish: true,
      incompleteChannels: [],
      incompleteChecks: [],
      reason: null,
    };
  }

  const parts: string[] = [];
  if (incompleteChannels.length > 0) {
    parts.push(`미완성 채널: ${incompleteChannels.join(", ")}`);
  }
  if (incompleteChecks.length > 0) {
    parts.push(`미완료 검수: ${incompleteChecks.join(", ")}`);
  }

  return {
    canPublish: false,
    incompleteChannels,
    incompleteChecks,
    reason: `발행할 수 없습니다. ${parts.join(" / ")}`,
  };
}
