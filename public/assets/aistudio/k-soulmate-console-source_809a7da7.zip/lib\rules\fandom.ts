export interface FandomCheckInput {
  checkTm: boolean;
  checkDup: boolean;
  checkWord: boolean;
  checkPron: boolean;
  checkChant: boolean;
}

export const FANDOM_CHECK_META: Array<{
  key: keyof FandomCheckInput;
  label: string;
  tooltip: string;
}> = [
  {
    key: "checkTm",
    label: "상표",
    tooltip: "한·일·미 상표권 저촉 여부가 없어야 합니다",
  },
  {
    key: "checkDup",
    label: "중복",
    tooltip: "기존 아이돌 팬덤명과 중복되지 않아야 합니다",
  },
  {
    key: "checkWord",
    label: "부적절어",
    tooltip: "4개국 언어에서 부정적 의미·속어가 없어야 합니다",
  },
  {
    key: "checkPron",
    label: "발음",
    tooltip: "한·일·영·중 화자 모두 발음하기 쉬워야 합니다",
  },
  {
    key: "checkChant",
    label: "3음절",
    tooltip: "3음절 이내로 끊어 부를 수 있어야 합니다",
  },
];

/**
 * SPEC 5.4 팬덤명 규칙
 * canShortlist(candidate) = checkTm && checkDup && checkWord && checkPron && checkChant
 */
export function canShortlist(candidate: FandomCheckInput): boolean {
  return Boolean(
    candidate.checkTm &&
      candidate.checkDup &&
      candidate.checkWord &&
      candidate.checkPron &&
      candidate.checkChant
  );
}

export function getFailedFandomChecks(candidate: FandomCheckInput): string[] {
  return FANDOM_CHECK_META.filter((m) => !candidate[m.key]).map((m) => m.label);
}
