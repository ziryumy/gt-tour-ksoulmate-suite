"use client";

import React, { useState, useTransition } from "react";
import type { EpisodeStatus } from "@prisma/client";
import { EPISODE_STATUS_LABELS, EPISODE_STATUS_ORDER } from "@/lib/types";
import { transitionEpisodeStatusAction } from "@/app/actions";
import { ChevronLeft, ChevronRight, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface EpisodeStatusControlProps {
  episodeNo: number;
  currentStatus: EpisodeStatus;
  compact?: boolean;
}

export function EpisodeStatusControl({
  episodeNo,
  currentStatus,
  compact = false,
}: EpisodeStatusControlProps) {
  const [isPending, startTransition] = useTransition();
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const currentIndex = EPISODE_STATUS_ORDER.indexOf(currentStatus);
  const prevStatus =
    currentIndex > 0 ? EPISODE_STATUS_ORDER[currentIndex - 1] : null;
  const nextStatus =
    currentIndex < EPISODE_STATUS_ORDER.length - 1
      ? EPISODE_STATUS_ORDER[currentIndex + 1]
      : null;

  const handleTransition = (targetStatus: EpisodeStatus) => {
    if (targetStatus === currentStatus) return;
    setErrorMsg(null);
    startTransition(async () => {
      const res = await transitionEpisodeStatusAction({
        episodeNo,
        targetStatus,
      });
      if (!res.ok) {
        setErrorMsg(res.error ?? "상태 변경에 실패했습니다.");
      }
    });
  };

  return (
    <div className="space-y-1">
      <div className="inline-flex items-center gap-1">
        {/* ◀ 이전 버튼 */}
        <button
          type="button"
          disabled={!prevStatus || isPending}
          onClick={() => prevStatus && handleTransition(prevStatus)}
          title={
            prevStatus
              ? `이전 단계: ${EPISODE_STATUS_LABELS[prevStatus]}`
              : "첫 단계입니다"
          }
          className={cn(
            "inline-flex items-center gap-0.5 rounded-[3px] border border-zinc-200 bg-white px-1.5 py-1 text-[11px] font-medium text-zinc-700 transition-colors hover:bg-zinc-100 disabled:cursor-not-allowed disabled:opacity-40"
          )}
        >
          <ChevronLeft className="h-3 w-3" />
          {!compact && <span>이전</span>}
        </button>

        {/* 단계 드롭다운 */}
        <select
          aria-label={`제${episodeNo}화 단계 선택`}
          value={currentStatus}
          disabled={isPending}
          onChange={(e) => handleTransition(e.target.value as EpisodeStatus)}
          className={cn(
            "rounded-[3px] border px-2 py-1 text-[11px] font-semibold focus:border-[#1F5E63] focus:outline-none disabled:opacity-50",
            currentStatus === "PUBLISHED"
              ? "border-[#1F5E63] bg-[#1F5E63] text-white"
              : currentStatus === "REVIEWED"
              ? "border-amber-300 bg-amber-50 text-amber-900"
              : "border-zinc-300 bg-white text-zinc-800"
          )}
        >
          {EPISODE_STATUS_ORDER.map((st) => (
            <option
              key={st}
              value={st}
              className="bg-white text-zinc-900 font-normal"
            >
              {EPISODE_STATUS_LABELS[st]} ({st})
            </option>
          ))}
        </select>

        {/* 다음 ▶ 버튼 */}
        <button
          type="button"
          disabled={!nextStatus || isPending}
          onClick={() => nextStatus && handleTransition(nextStatus)}
          title={
            nextStatus
              ? `다음 단계: ${EPISODE_STATUS_LABELS[nextStatus]}`
              : "마지막 단계입니다"
          }
          className={cn(
            "inline-flex items-center gap-0.5 rounded-[3px] border border-zinc-200 bg-white px-1.5 py-1 text-[11px] font-medium text-zinc-700 transition-colors hover:bg-zinc-100 disabled:cursor-not-allowed disabled:opacity-40"
          )}
        >
          {!compact && <span>다음</span>}
          <ChevronRight className="h-3 w-3" />
        </button>
      </div>

      {errorMsg && (
        <div
          role="alert"
          className="flex items-start gap-1 rounded-[3px] border border-red-300 bg-red-50 px-2 py-1 text-[11px] text-red-800"
        >
          <AlertCircle className="mt-0.5 h-3 w-3 shrink-0 text-red-600" />
          <span>{errorMsg}</span>
        </div>
      )}
    </div>
  );
}
