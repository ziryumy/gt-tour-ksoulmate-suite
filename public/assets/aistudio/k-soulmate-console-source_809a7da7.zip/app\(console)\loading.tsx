export default function ConsoleLoading() {
  return (
    <div className="space-y-4 py-2">
      <div className="h-6 w-48 animate-pulse rounded-[4px] bg-zinc-200" />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[1, 2, 3, 4].map((n) => (
          <div
            key={n}
            className="h-20 animate-pulse rounded-[8px] border border-zinc-200 bg-white p-3"
          />
        ))}
      </div>
      <div className="h-64 animate-pulse rounded-[8px] border border-zinc-200 bg-white" />
      <p className="text-xs text-zinc-500">데이터를 불러오는 중입니다...</p>
    </div>
  );
}
