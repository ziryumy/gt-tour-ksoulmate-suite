"use client";

import React, { useState, useEffect, useRef, useTransition } from "react";
import Image from "next/image";
import Link from "next/link";
import type { Channel, ChannelVersion, Member, VersionStatus } from "@prisma/client";
import { Badge, VersionStatusBadge } from "@/components/ui/badge";
import { validateChannelLength } from "@/lib/rules/length";
import {
  saveChannelVersionAction,
  publishChannelAndEpisodeAction,
} from "@/app/actions";
import { toStringArray, VERSION_STATUS_LABELS, formatDateDot } from "@/lib/types";
import {
  Lock,
  Save,
  AlertTriangle,
  ShieldAlert,
  CheckCircle2,
  ExternalLink,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface ChannelRuleGuide {
  forbidden: string;
  required: string;
}

const CHANNEL_NARRATION_RULES: Record<string, ChannelRuleGuide> = {
  JP: {
    forbidden: "감탄사(すごい！), 과장된 형용사, 설명하는 문장",
    required: "1인칭, 과거형 회상, 신체 감각(손·숨·목소리), 문장 사이 0.8~1.2초 여백",
  },
  US: {
    forbidden: "문어체, 긴 문장, 조용한 톤",
    required: '현재형, 감탄, 시청자에게 말 거는 호흡("watch this"), 하이햇 동기 컷 전환',
  },
  KR: {
    forbidden: "과장, 감성적 수사",
    required: "오늘의 표현 명시, 장소명, 다음 화 예고, 한 컷 5초 이상 유지",
  },
  CN: {
    forbidden: "일본어 대본 단순 번역",
    required: "감성적이되 짧은 문장, 화면 하단 자막 영역 확보 (1차 창작)",
  },
};

const WORKFLOW_STEP_TITLES: Record<string, string> = {
  script: "나레이션 대본",
  vo: "나레이션 보이스 (V.O.)",
  cut: "편집 호흡 (컷 수 · 총 길이)",
  bgm: "BGM 트랙 선택",
  subtitle: "자막 및 채널 버전 완료 확인",
  publish: "발행 (게이트 검증)",
};

export interface ChannelVersionEditorProps {
  episode: {
    id: number;
    no: number;
    title: string;
    place: string;
    baseVideoUrl: string | null;
    expressions: string[];
    complianceRisk: boolean;
  };
  channel: Channel;
  version: ChannelVersion | null;
  narrator: Member | null;
  episodeMember: Member | null;
  publishGate: {
    canPublish: boolean;
    incompleteChannels: string[];
    incompleteChecks: string[];
    reason: string | null;
  };
  showDedicatedLink?: boolean;
}

export function ChannelVersionEditor({
  episode,
  channel,
  version,
  narrator,
  episodeMember,
  publishGate,
  showDedicatedLink = false,
}: ChannelVersionEditorProps) {
  const workflowOrder = toStringArray(channel.workflowOrder);
  const bgmTracks = toStringArray(channel.bgmTracks);
  const hasSeparateScriptStep = workflowOrder.includes("script");

  const [narration, setNarration] = useState<string>(version?.narration ?? "");
  const [voStatus, setVoStatus] = useState<VersionStatus>(
    version?.voStatus ?? "TODO"
  );
  const [bgmTrackId, setBgmTrackId] = useState<string>(
    version?.bgmTrackId ?? bgmTracks[0] ?? ""
  );
  const [cutCountInput, setCutCountInput] = useState<string>(
    String(version?.cutCount ?? channel.cutCount)
  );
  const [totalSecInput, setTotalSecInput] = useState<string>(
    String(version?.totalSec ?? channel.totalSec)
  );
  const [status, setStatus] = useState<VersionStatus>(
    version?.status ?? "TODO"
  );
  const [subtitleDone, setSubtitleDone] = useState<boolean>(
    version?.status === "DONE"
  );
  const [publishedUrl, setPublishedUrl] = useState<string>(
    version?.publishedUrl ?? ""
  );

  const [isDirty, setIsDirty] = useState(false);
  const [toast, setToast] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);
  const [isPending, startTransition] = useTransition();
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // 채널 탭 전환 시 초기 상태 동기화
  useEffect(() => {
    setNarration(version?.narration ?? "");
    setVoStatus(version?.voStatus ?? "TODO");
    setBgmTrackId(version?.bgmTrackId ?? bgmTracks[0] ?? "");
    setCutCountInput(String(version?.cutCount ?? channel.cutCount));
    setTotalSecInput(String(version?.totalSec ?? channel.totalSec));
    setStatus(version?.status ?? "TODO");
    setSubtitleDone(version?.status === "DONE");
    setPublishedUrl(version?.publishedUrl ?? "");
    setIsDirty(false);
    setToast(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [episode.no, channel.code]);

  // 저장되지 않은 변경이 있으면 브라우저 이탈 시 확인
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [isDirty]);

  const parsedCutCount =
    cutCountInput.trim() === "" ? null : Number(cutCountInput);
  const parsedTotalSec =
    totalSecInput.trim() === "" ? null : Number(totalSecInput);

  const lengthValidation = validateChannelLength({
    cutCount: parsedCutCount,
    totalSec: parsedTotalSec,
    targetCutCount: channel.cutCount,
    targetTotalSec: channel.totalSec,
    targetAvgCutSec: channel.avgCutSec,
  });

  const performSave = (overrideStatus?: VersionStatus) => {
    const statusToSave = overrideStatus ?? status;
    startTransition(async () => {
      const res = await saveChannelVersionAction({
        episodeNo: episode.no,
        channelCode: channel.code as "JP" | "US" | "KR" | "CN",
        narration,
        voStatus,
        bgmTrackId: bgmTrackId || null,
        cutCount:
          parsedCutCount && Number.isFinite(parsedCutCount)
            ? Math.round(parsedCutCount)
            : null,
        totalSec:
          parsedTotalSec && Number.isFinite(parsedTotalSec)
            ? Math.round(parsedTotalSec)
            : null,
        status: statusToSave,
        publishedUrl: publishedUrl.trim() || null,
      });

      if (res.ok) {
        setIsDirty(false);
        setToast({ type: "success", text: "저장했습니다" });
      } else {
        setToast({
          type: "error",
          text: res.error ?? "저장하지 못했습니다. 다시 시도해 주세요.",
        });
      }
    });
  };

  // 5초 디바운스 자동 저장
  useEffect(() => {
    if (!isDirty) return;
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    debounceTimerRef.current = setTimeout(() => {
      performSave();
    }, 5000);

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    isDirty,
    narration,
    voStatus,
    bgmTrackId,
    cutCountInput,
    totalSecInput,
    status,
    publishedUrl,
  ]);

  const handlePublish = () => {
    if (!parsedCutCount || !parsedTotalSec) return;
    startTransition(async () => {
      const res = await publishChannelAndEpisodeAction({
        episodeNo: episode.no,
        channelCode: channel.code as "JP" | "US" | "KR" | "CN",
        publishedUrl,
        cutCount: Math.round(parsedCutCount),
        totalSec: Math.round(parsedTotalSec),
      });
      if (res.ok) {
        setIsDirty(false);
        setToast({ type: "success", text: res.message ?? "저장했습니다" });
      } else {
        setToast({
          type: "error",
          text: res.error ?? "저장하지 못했습니다. 다시 시도해 주세요.",
        });
      }
    });
  };

  const ruleGuide = CHANNEL_NARRATION_RULES[channel.code] ?? {
    forbidden: "번역투 문장 금지",
    required: "채널 고유 호흡 준수",
  };

  // 고정 패널에 표시할 캐릭터 시트 2인 (회차 담당 멤버 + 채널 내레이터 멤버)
  const fixedMembers: Member[] = [];
  if (episodeMember) fixedMembers.push(episodeMember);
  if (narrator && (!episodeMember || narrator.id !== episodeMember.id)) {
    fixedMembers.push(narrator);
  }

  const renderScriptTextareaBlock = () => (
    <div className="space-y-2.5">
      {/* 상단 고정 화법 규칙 안내 */}
      <div className="rounded-[4px] border border-zinc-200 bg-zinc-50 p-2.5 text-xs space-y-1">
        <div className="flex flex-wrap items-center justify-between gap-1">
          <span className="font-semibold text-zinc-800">
            화법 규칙: {channel.tone}
          </span>
          <Badge variant="teal">독립 재창작 (번역 금지)</Badge>
        </div>
        <div className="text-[11px] text-red-700">
          <strong>금지:</strong> {ruleGuide.forbidden}
        </div>
        <div className="text-[11px] text-[#1F5E63]">
          <strong>필수:</strong> {ruleGuide.required}
        </div>
      </div>

      <div>
        <div className="mb-1 flex items-center justify-between text-[11px] text-zinc-500">
          <label htmlFor={`narration-${channel.code}`} className="font-medium">
            {channel.code} 채널 나레이션 대본 (입력 시 5초 뒤 자동 저장)
          </label>
          <span className="font-mono">{narration.length}자</span>
        </div>
        <textarea
          id={`narration-${channel.code}`}
          rows={7}
          value={narration}
          onChange={(e) => {
            setNarration(e.target.value);
            setIsDirty(true);
          }}
          placeholder={`${channel.code} 채널 화법(${channel.tone})에 맞춘 나레이션 대본을 작성하세요...`}
          className="w-full rounded-[4px] border border-zinc-300 bg-white p-3 font-mono text-xs leading-relaxed text-zinc-900 focus:border-[#1F5E63] focus:outline-none"
        />
      </div>
    </div>
  );

  const renderWorkflowSection = (step: string, index: number) => {
    const stepNo = String(index + 1).padStart(2, "0");
    const stepTitle = WORKFLOW_STEP_TITLES[step] ?? step;

    switch (step) {
      case "script":
        return (
          <div
            key={step}
            data-workflow-step="script"
            className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-2.5"
          >
            <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
              <div className="flex items-center gap-2">
                <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                  STEP {stepNo}
                </span>
                <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
              </div>
              <span className="font-mono text-[11px] text-zinc-400">script</span>
            </div>
            {renderScriptTextareaBlock()}
          </div>
        );

      case "vo":
        return (
          <div
            key={step}
            data-workflow-step="vo"
            className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-3"
          >
            <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
              <div className="flex items-center gap-2">
                <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                  STEP {stepNo}
                </span>
                <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
              </div>
              <span className="font-mono text-[11px] text-zinc-400">vo</span>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 text-xs">
              <div>
                <label
                  htmlFor={`vo-status-${channel.code}`}
                  className="block text-[11px] font-medium text-zinc-600"
                >
                  V.O. 제작 상태
                </label>
                <select
                  id={`vo-status-${channel.code}`}
                  value={voStatus}
                  onChange={(e) => {
                    setVoStatus(e.target.value as VersionStatus);
                    setIsDirty(true);
                  }}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 text-xs font-medium text-zinc-900 focus:border-[#1F5E63] focus:outline-none"
                >
                  {(["TODO", "IN_PROGRESS", "DONE", "BLOCKED"] as VersionStatus[]).map(
                    (st) => (
                      <option key={st} value={st}>
                        {VERSION_STATUS_LABELS[st]} ({st})
                      </option>
                    )
                  )}
                </select>
              </div>

              <div>
                <span className="block text-[11px] font-medium text-zinc-500">
                  보이스 프로필 (읽기 전용 · 고정)
                </span>
                <div className="mt-1 flex items-center justify-between rounded-[4px] border border-zinc-200 bg-zinc-100 px-2.5 py-1.5 font-mono text-xs text-zinc-600">
                  <span>
                    {narrator
                      ? `${narrator.nameKo} (${narrator.voiceProfile ?? "미지정"})`
                      : channel.narratorId}
                  </span>
                  <Badge variant="default">고정</Badge>
                </div>
              </div>
            </div>

            {/* workflowOrder에 script 단계가 별도로 없는 채널(US/KR/CN)은 V.O. 섹션 내에서 대본 입력 제공 */}
            {!hasSeparateScriptStep && (
              <div className="border-t border-zinc-100 pt-2.5">
                {renderScriptTextareaBlock()}
              </div>
            )}
          </div>
        );

      case "cut":
        return (
          <div
            key={step}
            data-workflow-step="cut"
            className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-3"
          >
            <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
              <div className="flex items-center gap-2">
                <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                  STEP {stepNo}
                </span>
                <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
              </div>
              <span className="font-mono text-[11px] text-zinc-500">
                규격: {channel.totalSec}초 / {channel.cutCount}컷 / 평균{" "}
                {channel.avgCutSec}초 (±0.3초)
              </span>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 text-xs">
              <div>
                <label
                  htmlFor={`cut-count-${channel.code}`}
                  className="block text-[11px] font-medium text-zinc-600"
                >
                  컷 수 (기준 {channel.cutCount}컷)
                </label>
                <input
                  id={`cut-count-${channel.code}`}
                  type="number"
                  min={1}
                  max={500}
                  value={cutCountInput}
                  onChange={(e) => {
                    setCutCountInput(e.target.value);
                    setIsDirty(true);
                  }}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 font-mono text-xs text-zinc-900 focus:border-[#1F5E63] focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor={`total-sec-${channel.code}`}
                  className="block text-[11px] font-medium text-zinc-600"
                >
                  총 길이 초 (기준 {channel.totalSec}초)
                </label>
                <input
                  id={`total-sec-${channel.code}`}
                  type="number"
                  min={1}
                  max={1200}
                  value={totalSecInput}
                  onChange={(e) => {
                    setTotalSecInput(e.target.value);
                    setIsDirty(true);
                  }}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 font-mono text-xs text-zinc-900 focus:border-[#1F5E63] focus:outline-none"
                />
              </div>

              <div>
                <span className="block text-[11px] font-medium text-zinc-500">
                  계산된 평균 컷 (읽기 전용 · 실시간)
                </span>
                <div
                  data-testid="calculated-avg-cut"
                  className={cn(
                    "mt-1 flex items-center justify-between rounded-[4px] border px-2.5 py-1.5 font-mono text-xs font-bold",
                    lengthValidation.hasWarning
                      ? "border-amber-400 bg-amber-50 text-amber-900"
                      : "border-zinc-200 bg-zinc-100 text-zinc-900"
                  )}
                >
                  <span>
                    {lengthValidation.avgCutSec !== null
                      ? `${lengthValidation.avgCutSec}초`
                      : "-"}
                  </span>
                  <span className="text-[10px] font-normal text-zinc-500">
                    목표 {channel.avgCutSec}초
                  </span>
                </div>
              </div>
            </div>

            {lengthValidation.hasWarning && (
              <div
                role="alert"
                data-testid="length-warning-banner"
                className="flex items-start gap-2 rounded-[4px] border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900"
              >
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" />
                <div>
                  <div className="font-semibold">
                    편집 호흡 규격 이탈 경고 (저장은 가능하나 발행은 차단됩니다)
                  </div>
                  <ul className="mt-0.5 list-disc pl-4 text-[11px] text-amber-800">
                    {lengthValidation.warnings.map((w, i) => (
                      <li key={i}>{w}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        );

      case "bgm":
        return (
          <div
            key={step}
            data-workflow-step="bgm"
            className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-2.5"
          >
            <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
              <div className="flex items-center gap-2">
                <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                  STEP {stepNo}
                </span>
                <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
              </div>
              <span className="text-[11px] text-zinc-400">
                미리듣기 미지원 (Phase 1)
              </span>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 text-xs">
              <div>
                <label
                  htmlFor={`bgm-track-${channel.code}`}
                  className="block text-[11px] font-medium text-zinc-600"
                >
                  라이브러리 트랙 (3종 중 선택)
                </label>
                <select
                  id={`bgm-track-${channel.code}`}
                  value={bgmTrackId}
                  onChange={(e) => {
                    setBgmTrackId(e.target.value);
                    setIsDirty(true);
                  }}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 font-mono text-xs text-zinc-900 focus:border-[#1F5E63] focus:outline-none"
                >
                  {bgmTracks.map((track) => (
                    <option key={track} value={track}>
                      {track}
                    </option>
                  ))}
                </select>
              </div>
              <div className="rounded-[4px] border border-zinc-200 bg-zinc-50 px-3 py-2 text-[11px] text-zinc-600">
                리듬 기준: <strong>{channel.rhythmBasis}</strong>
              </div>
            </div>
          </div>
        );

      case "subtitle":
        return (
          <div
            key={step}
            data-workflow-step="subtitle"
            className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-2.5"
          >
            <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
              <div className="flex items-center gap-2">
                <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                  STEP {stepNo}
                </span>
                <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
              </div>
              <VersionStatusBadge status={status} />
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 items-center text-xs">
              <label className="inline-flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={subtitleDone}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    setSubtitleDone(checked);
                    const nextSt: VersionStatus = checked ? "DONE" : "IN_PROGRESS";
                    setStatus(nextSt);
                    setIsDirty(true);
                  }}
                  className="h-4 w-4 rounded-[2px] border-zinc-300 accent-[#1F5E63]"
                />
                <span className="font-medium text-zinc-800">
                  자막 검수 및 싱크 배치 완료 (체크 시 채널 상태 DONE 전환)
                </span>
              </label>

              <div>
                <label
                  htmlFor={`version-status-${channel.code}`}
                  className="block text-[11px] font-medium text-zinc-600"
                >
                  채널 버전 전체 상태
                </label>
                <select
                  id={`version-status-${channel.code}`}
                  value={status}
                  onChange={(e) => {
                    const nextSt = e.target.value as VersionStatus;
                    setStatus(nextSt);
                    setSubtitleDone(nextSt === "DONE");
                    setIsDirty(true);
                  }}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-zinc-900 focus:border-[#1F5E63] focus:outline-none"
                >
                  {(["TODO", "IN_PROGRESS", "DONE", "BLOCKED"] as VersionStatus[]).map(
                    (st) => (
                      <option key={st} value={st}>
                        {VERSION_STATUS_LABELS[st]} ({st})
                      </option>
                    )
                  )}
                </select>
              </div>
            </div>
          </div>
        );

      case "publish": {
        const isPublishBlocked =
          !publishGate.canPublish || lengthValidation.hasWarning;

        return (
          <div
            key={step}
            data-workflow-step="publish"
            className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-3"
          >
            <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
              <div className="flex items-center gap-2">
                <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                  STEP {stepNo}
                </span>
                <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
              </div>
              {version?.publishedAt && (
                <span className="font-mono text-[11px] text-[#1F5E63]">
                  발행일: {formatDateDot(version.publishedAt)}
                </span>
              )}
            </div>

            {!publishGate.canPublish && (
              <div
                role="alert"
                data-testid="publish-gate-blocker"
                className="flex items-start gap-2 rounded-[4px] border border-red-300 bg-red-50 px-3 py-2 text-xs text-red-900"
              >
                <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
                <div>
                  <div className="font-bold">{publishGate.reason}</div>
                  <p className="mt-0.5 text-[11px] text-red-700">
                    활성 3개 채널(JP·US·KR) 모두 DONE 상태이고 발행 전 필수 컴플라이언스 검수가 완료되어야 발행 버튼이 활성화됩니다.
                  </p>
                </div>
              </div>
            )}

            <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
              <div className="flex-1">
                <label
                  htmlFor={`publish-url-${channel.code}`}
                  className="block text-[11px] font-medium text-zinc-600"
                >
                  발행 게시물 URL (수동 입력)
                </label>
                <input
                  id={`publish-url-${channel.code}`}
                  type="url"
                  value={publishedUrl}
                  onChange={(e) => {
                    setPublishedUrl(e.target.value);
                    setIsDirty(true);
                  }}
                  placeholder={`https://social.k-soulmate.internal/${channel.code.toLowerCase()}/ep-${String(
                    episode.no
                  ).padStart(2, "0")}`}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 font-mono text-xs text-zinc-900 focus:border-[#1F5E63] focus:outline-none"
                />
              </div>

              <button
                type="button"
                disabled={
                  isPublishBlocked || !publishedUrl.trim() || isPending
                }
                onClick={handlePublish}
                data-testid="publish-submit-button"
                className="inline-flex items-center justify-center rounded-[4px] bg-[#1F5E63] px-4 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-[#17494d] disabled:cursor-not-allowed disabled:bg-zinc-300 disabled:text-zinc-500"
              >
                발행 확정
              </button>
            </div>
          </div>
        );
      }

      default:
        return null;
    }
  };

  return (
    <div className="space-y-4">
      {/* 상단 채널 요약 & 수동 저장 바 */}
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-[6px] border border-zinc-200 bg-zinc-50 px-3.5 py-2.5">
        <div className="flex flex-wrap items-center gap-2">
          <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-xs font-bold text-white">
            {channel.code}
          </span>
          <span className="text-xs font-bold text-zinc-900">
            {channel.label}
          </span>
          <span className="text-[11px] text-zinc-500">
            · 작업 순서:{" "}
            <strong className="font-mono text-[#1F5E63]">
              {workflowOrder.join(" → ")}
            </strong>
          </span>
        </div>

        <div className="flex items-center gap-2">
          {showDedicatedLink && (
            <Link
              href={`/episodes/${episode.no}/channels/${channel.code}`}
              className="inline-flex items-center gap-1 rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1 text-[11px] font-medium text-zinc-700 hover:bg-zinc-100"
            >
              <span>전용 편집 화면</span>
              <ExternalLink className="h-3 w-3" />
            </Link>
          )}
          <button
            type="button"
            disabled={isPending}
            onClick={() => performSave()}
            data-testid="save-channel-version-button"
            className="inline-flex items-center gap-1.5 rounded-[4px] bg-[#1F5E63] px-3 py-1 text-xs font-semibold text-white hover:bg-[#17494d] disabled:opacity-50"
          >
            <Save className="h-3.5 w-3.5" />
            <span>{isPending ? "저장 중..." : "저장"}</span>
          </button>
        </div>
      </div>

      {/* 토스트 알림 */}
      {toast && (
        <div
          role="status"
          data-testid="save-toast"
          className={cn(
            "flex items-center justify-between rounded-[4px] border px-3 py-2 text-xs font-medium",
            toast.type === "success"
              ? "border-emerald-300 bg-emerald-50 text-emerald-900"
              : "border-red-300 bg-red-50 text-red-900"
          )}
        >
          <span className="inline-flex items-center gap-1.5">
            <CheckCircle2 className="h-3.5 w-3.5" />
            {toast.text}
          </span>
          <button
            type="button"
            onClick={() => setToast(null)}
            className="text-[11px] underline"
          >
            닫기
          </button>
        </div>
      )}

      {/* 본문: 좌측 가변 워크플로우 섹션 / 우측 고정 항목 패널 */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* 가변 항목 (workflowOrder 순서대로 배치) */}
        <div
          data-testid="workflow-sections-container"
          className="space-y-3 lg:col-span-8"
        >
          {workflowOrder.map((step, index) =>
            renderWorkflowSection(step, index)
          )}
        </div>

        {/* 고정 항목 패널 (SPEC 4.5: 읽기 전용 회색 패널) */}
        <aside className="lg:col-span-4 space-y-3">
          <div className="rounded-[6px] border border-zinc-200 bg-zinc-100/80 p-3.5 space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-200 pb-2">
              <div className="flex items-center gap-1.5">
                <Lock className="h-3.5 w-3.5 text-zinc-500" />
                <span className="text-xs font-bold text-zinc-700">
                  고정 — 채널과 무관하게 동일
                </span>
              </div>
              <Badge variant="default">편집 불가</Badge>
            </div>

            {/* 1. 베이스 영상 링크 */}
            <div className="space-y-1 text-xs">
              <div className="text-[11px] font-semibold text-zinc-500">
                베이스 영상 마스터 (130초 헤드룸)
              </div>
              <div className="rounded-[4px] border border-zinc-200 bg-zinc-50 px-2.5 py-1.5 font-mono text-[11px] text-zinc-600 break-all">
                {episode.baseVideoUrl ?? "베이스 마스터 미등록 (생성 대기)"}
              </div>
            </div>

            {/* 2. 오늘의 한국어 3표현 */}
            <div className="space-y-1.5 text-xs">
              <div className="text-[11px] font-semibold text-zinc-500">
                오늘의 한국어 3표현 (대사 원음 고정)
              </div>
              <div className="space-y-1">
                {episode.expressions.map((expr, idx) => (
                  <div
                    key={idx}
                    className="rounded-[4px] border border-zinc-200 bg-zinc-50 px-2.5 py-1.5 text-xs font-medium text-zinc-700"
                  >
                    <span className="mr-1.5 font-mono text-[10px] text-zinc-400">
                      0{idx + 1}
                    </span>
                    「{expr}」
                  </div>
                ))}
              </div>
            </div>

            {/* 3. 캐릭터 시트 썸네일 2인 (회차 담당 + 채널 내레이터) */}
            <div className="space-y-1.5 text-xs">
              <div className="text-[11px] font-semibold text-zinc-500">
                참여 캐릭터 시트 (회차 담당 · 채널 내레이터)
              </div>
              <div className="grid grid-cols-2 gap-2">
                {fixedMembers.map((m) => (
                  <div
                    key={m.id}
                    className="overflow-hidden rounded-[4px] border border-zinc-200 bg-zinc-50"
                  >
                    <div className="relative aspect-[4/3] w-full bg-zinc-200">
                      <Image
                        src={m.photoSheetUrl}
                        alt={m.nameKo}
                        fill
                        sizes="160px"
                        className="object-cover object-top"
                      />
                    </div>
                    <div className="p-1.5 text-[11px]">
                      <div className="font-bold text-zinc-800">
                        {m.nameKo}{" "}
                        <span className="font-mono text-[10px] text-zinc-500">
                          ({m.id})
                        </span>
                      </div>
                      <div className="text-[10px] text-zinc-500">
                        {episodeMember?.id === m.id && narrator?.id === m.id
                          ? "주인공 · 내레이터"
                          : episodeMember?.id === m.id
                          ? "회차 주인공"
                          : `${channel.code} 내레이터`}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-[4px] border border-zinc-200 bg-zinc-50 px-2.5 py-2 text-[11px] text-zinc-500">
              장소 고정: <strong className="text-zinc-700">{episode.place}</strong>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
