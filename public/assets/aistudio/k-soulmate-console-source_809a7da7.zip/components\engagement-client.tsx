"use client";

import React, { useState, useTransition } from "react";
import type { Gauge, FandomCandidate, Mission, Episode } from "@prisma/client";
import { Badge } from "@/components/ui/badge";
import {
  canShortlist,
  FANDOM_CHECK_META,
  type FandomCheckInput,
} from "@/lib/rules/fandom";
import {
  updateGaugeAction,
  toggleFandomCheckAction,
  updateFandomStatusAction,
  updateMissionStatusAction,
} from "@/app/actions";
import {
  Unlock,
  Lock,
  CheckCircle2,
  XCircle,
  Award,
  AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface MissionWithEpisode extends Mission {
  episode: Episode;
}

interface EngagementClientProps {
  gauges: Gauge[];
  candidates: FandomCandidate[];
  missions: MissionWithEpisode[];
}

export function EngagementClient({
  gauges,
  candidates,
  missions,
}: EngagementClientProps) {
  const [isPending, startTransition] = useTransition();
  const [feedback, setFeedback] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  const handleGaugeUpdate = (id: number, nextValue: number) => {
    startTransition(async () => {
      const res = await updateGaugeAction({ id, current: nextValue });
      if (res.ok) {
        setFeedback({ type: "success", text: res.message ?? "저장했습니다" });
      } else {
        setFeedback({
          type: "error",
          text: res.error ?? "업데이트에 실패했습니다.",
        });
      }
    });
  };

  const handleToggleCheck = (
    id: number,
    field: keyof FandomCheckInput,
    value: boolean
  ) => {
    startTransition(async () => {
      const res = await toggleFandomCheckAction({ id, field, value });
      if (!res.ok) {
        setFeedback({
          type: "error",
          text: res.error ?? "검증 상태 저장에 실패했습니다.",
        });
      }
    });
  };

  const handleFandomStatus = (
    id: number,
    status: "CANDIDATE" | "SHORTLIST" | "ADOPTED"
  ) => {
    startTransition(async () => {
      const res = await updateFandomStatusAction({ id, status });
      if (res.ok) {
        setFeedback({ type: "success", text: res.message ?? "변경했습니다." });
      } else {
        setFeedback({
          type: "error",
          text: res.error ?? "상태 변경에 실패했습니다.",
        });
      }
    });
  };

  const handleMissionStatus = (
    id: number,
    status: "COLLECTING" | "ADOPTED" | "REJECTED"
  ) => {
    startTransition(async () => {
      const res = await updateMissionStatusAction({ id, status });
      if (res.ok) {
        setFeedback({
          type: "success",
          text: res.message ?? "미션 상태를 변경했습니다.",
        });
      } else {
        setFeedback({
          type: "error",
          text: res.error ?? "미션 상태 변경에 실패했습니다.",
        });
      }
    });
  };

  return (
    <div className="space-y-4">
      {feedback && (
        <div
          role="status"
          className={cn(
            "flex items-center justify-between rounded-[4px] border px-3 py-2 text-xs font-medium",
            feedback.type === "success"
              ? "border-emerald-300 bg-emerald-50 text-emerald-900"
              : "border-red-300 bg-red-50 text-red-900"
          )}
        >
          <span className="inline-flex items-center gap-1.5">
            {feedback.type === "success" ? (
              <CheckCircle2 className="h-3.5 w-3.5" />
            ) : (
              <AlertCircle className="h-3.5 w-3.5" />
            )}
            {feedback.text}
          </span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="text-[11px] underline"
          >
            닫기
          </button>
        </div>
      )}

      {/* 1. 응원 게이지 블록 (SPEC 4.8.1 & AC-14) */}
      <section className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-zinc-100 pb-2.5">
          <div>
            <h2 className="text-xs font-bold text-zinc-900">
              1. 응원 게이지 (해금 트래커)
            </h2>
            <p className="text-[11px] text-zinc-500">
              임계값 달성 시 해금됨 상태로 전환됩니다. (기본 시드: 하루토 얼굴 공개 50%)
            </p>
          </div>
          <Badge variant="default">실시간 연동</Badge>
        </div>

        <div className="space-y-3">
          {gauges.map((g) => {
            const isUnlocked = g.unlocked || g.current >= g.threshold;

            return (
              <div
                key={g.id}
                data-testid={`gauge-card-${g.id}`}
                className={cn(
                  "rounded-[6px] border p-3.5 space-y-2.5",
                  isUnlocked
                    ? "border-[#1F5E63] bg-[#1F5E63]/5"
                    : "border-zinc-200 bg-zinc-50"
                )}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {isUnlocked ? (
                      <Unlock className="h-4 w-4 text-[#1F5E63]" />
                    ) : (
                      <Lock className="h-4 w-4 text-zinc-400" />
                    )}
                    <span className="text-sm font-bold text-zinc-900">
                      {g.label}
                    </span>
                    {isUnlocked ? (
                      <Badge
                        variant="tealSolid"
                        data-testid="gauge-unlocked-badge"
                      >
                        해금됨
                      </Badge>
                    ) : (
                      <Badge variant="default" data-testid="gauge-locked-badge">
                        잠김 (목표 {g.threshold}%)
                      </Badge>
                    )}
                  </div>

                  <div className="font-mono text-xs font-bold text-zinc-900">
                    현재 {g.current}% / 임계값 {g.threshold}%
                  </div>
                </div>

                {/* 프로그레스 바 */}
                <div className="relative h-3 w-full overflow-hidden rounded-[2px] bg-zinc-200">
                  <div
                    className={cn(
                      "h-full transition-all",
                      isUnlocked ? "bg-[#1F5E63]" : "bg-amber-500"
                    )}
                    style={{ width: `${Math.min(100, g.current)}%` }}
                  />
                  <div
                    title={`해금 임계선 ${g.threshold}%`}
                    className="absolute inset-y-0 w-0.5 bg-red-600"
                    style={{ left: `${Math.min(100, g.threshold)}%` }}
                  />
                </div>

                {/* 게이지 조절 컨트롤 */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    {[0, 25, 49, 50, 75, 100].map((pct) => (
                      <button
                        key={pct}
                        type="button"
                        disabled={isPending}
                        onClick={() => handleGaugeUpdate(g.id, pct)}
                        className={cn(
                          "rounded-[3px] border px-2 py-1 font-mono text-[11px] font-medium transition-colors",
                          g.current === pct
                            ? "border-[#1F5E63] bg-[#1F5E63] text-white"
                            : pct >= g.threshold
                            ? "border-[#1F5E63]/40 bg-white text-[#1F5E63] hover:bg-[#1F5E63]/10"
                            : "border-zinc-300 bg-white text-zinc-700 hover:bg-zinc-100"
                        )}
                      >
                        {pct}%{pct === g.threshold ? " (해금 기준)" : ""}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 2. 팬덤명 후보 블록 (SPEC 4.8.2 & AC-13) */}
      <section className="rounded-[8px] border border-zinc-200 bg-white">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 px-4 py-3">
          <div>
            <h2 className="text-xs font-bold text-zinc-900">
              2. 팬덤명 후보 검수 (5대 조건 게이트)
            </h2>
            <p className="text-[11px] text-zinc-500">
              상표·중복·부적절어·발음·3음절 이내 5개 검사를 모두 통과해야만 SHORTLIST로 올릴 수 있습니다.
            </p>
          </div>
          <Badge variant="default">그룹명은 미확정 (B-1 준수)</Badge>
        </div>

        {/* 데스크톱 표 */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-200 bg-zinc-50 text-[11px] font-semibold text-zinc-600">
                <th className="px-3.5 py-2.5 w-24">후보명</th>
                <th className="px-3.5 py-2.5">제안 이유</th>
                <th className="px-3.5 py-2.5 w-16 text-right">득표</th>
                <th className="px-3.5 py-2.5">5개 검사 통과 여부 (클릭 시 전환)</th>
                <th className="px-3.5 py-2.5 w-28">현재 상태</th>
                <th className="px-3.5 py-2.5 w-48 text-right">단계 변경</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200">
              {candidates.map((cand) => {
                const eligible = canShortlist(cand);

                return (
                  <tr key={cand.id} className="hover:bg-zinc-50">
                    <td className="px-3.5 py-2.5 font-bold text-zinc-900">
                      {cand.name}
                    </td>
                    <td className="px-3.5 py-2.5 text-zinc-600">
                      {cand.reason}
                    </td>
                    <td className="px-3.5 py-2.5 text-right font-mono font-semibold text-zinc-800">
                      {cand.votes}표
                    </td>
                    <td className="px-3.5 py-2.5">
                      <div className="flex flex-wrap items-center gap-1.5">
                        {FANDOM_CHECK_META.map((meta) => {
                          const passed = cand[meta.key];
                          return (
                            <button
                              key={meta.key}
                              type="button"
                              disabled={isPending}
                              title={meta.tooltip}
                              onClick={() =>
                                handleToggleCheck(cand.id, meta.key, !passed)
                              }
                              className={cn(
                                "inline-flex items-center gap-1 rounded-[2px] border px-1.5 py-0.5 text-[11px] font-medium transition-colors",
                                passed
                                  ? "border-[#1F5E63]/40 bg-[#1F5E63]/10 text-[#1F5E63]"
                                  : "border-red-300 bg-red-50 text-red-700"
                              )}
                            >
                              {passed ? (
                                <CheckCircle2 className="h-3 w-3" />
                              ) : (
                                <XCircle className="h-3 w-3" />
                              )}
                              <span>{meta.label}</span>
                            </button>
                          );
                        })}
                      </div>
                      {!cand.checkChant && (
                        <div className="mt-1 text-[10px] text-red-600">
                          ※ 3음절 이내로 끊어 부를 수 있어야 합니다
                        </div>
                      )}
                    </td>
                    <td className="px-3.5 py-2.5">
                      <Badge
                        variant={
                          cand.status === "ADOPTED"
                            ? "tealSolid"
                            : cand.status === "SHORTLIST"
                            ? "teal"
                            : "default"
                        }
                      >
                        {cand.status}
                      </Badge>
                    </td>
                    <td className="px-3.5 py-2.5 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          disabled={
                            !eligible ||
                            cand.status === "SHORTLIST" ||
                            isPending
                          }
                          data-testid={`shortlist-btn-${cand.id}`}
                          title={
                            eligible
                              ? "SHORTLIST로 승격"
                              : "3음절 이내로 끊어 부를 수 있어야 합니다 (5개 검사 모두 통과 필요)"
                          }
                          onClick={() =>
                            handleFandomStatus(cand.id, "SHORTLIST")
                          }
                          className="rounded-[3px] border border-[#1F5E63] bg-[#1F5E63] px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-[#17494d] disabled:cursor-not-allowed disabled:border-zinc-200 disabled:bg-zinc-200 disabled:text-zinc-400"
                        >
                          SHORTLIST
                        </button>
                        {cand.status !== "CANDIDATE" && (
                          <button
                            type="button"
                            disabled={isPending}
                            onClick={() =>
                              handleFandomStatus(cand.id, "CANDIDATE")
                            }
                            className="rounded-[3px] border border-zinc-300 bg-white px-2 py-1 text-[11px] text-zinc-600 hover:bg-zinc-100"
                          >
                            해제
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* 모바일 카드 리스트 (375px 폭 대응) */}
        <div className="md:hidden divide-y divide-zinc-200">
          {candidates.map((cand) => {
            const eligible = canShortlist(cand);
            return (
              <div key={cand.id} className="p-3.5 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-zinc-900">
                      {cand.name}
                    </span>
                    <span className="font-mono text-[11px] text-zinc-500">
                      {cand.votes}표
                    </span>
                  </div>
                  <Badge
                    variant={
                      cand.status === "SHORTLIST" ? "tealSolid" : "default"
                    }
                  >
                    {cand.status}
                  </Badge>
                </div>
                <p className="text-zinc-600">{cand.reason}</p>
                <div className="flex flex-wrap gap-1">
                  {FANDOM_CHECK_META.map((meta) => {
                    const passed = cand[meta.key];
                    return (
                      <button
                        key={meta.key}
                        type="button"
                        title={meta.tooltip}
                        onClick={() =>
                          handleToggleCheck(cand.id, meta.key, !passed)
                        }
                        className={cn(
                          "inline-flex items-center gap-1 rounded-[2px] border px-1.5 py-0.5 text-[11px]",
                          passed
                            ? "border-[#1F5E63]/40 bg-[#1F5E63]/10 text-[#1F5E63]"
                            : "border-red-300 bg-red-50 text-red-700"
                        )}
                      >
                        {passed ? (
                          <CheckCircle2 className="h-3 w-3" />
                        ) : (
                          <XCircle className="h-3 w-3" />
                        )}
                        <span>{meta.label}</span>
                      </button>
                    );
                  })}
                </div>
                <div className="flex justify-end pt-1">
                  <button
                    type="button"
                    disabled={
                      !eligible || cand.status === "SHORTLIST" || isPending
                    }
                    onClick={() => handleFandomStatus(cand.id, "SHORTLIST")}
                    className="rounded-[3px] bg-[#1F5E63] px-3 py-1 text-[11px] font-semibold text-white disabled:cursor-not-allowed disabled:bg-zinc-200 disabled:text-zinc-400"
                  >
                    SHORTLIST 등록
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. 미션 회수 블록 (SPEC 4.8.3) */}
      <section className="rounded-[8px] border border-zinc-200 bg-white">
        <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-3">
          <div>
            <h2 className="text-xs font-bold text-zinc-900">
              3. 회차별 팬 미션 회수 트래커
            </h2>
            <p className="text-[11px] text-zinc-500">
              COLLECTING에서 ADOPTED(채택)로 전환된 미션은 해당 회차 엔딩 크레딧 등재 대상으로 표시됩니다.
            </p>
          </div>
          <Badge variant="teal">{missions.length}건</Badge>
        </div>

        <div className="divide-y divide-zinc-200">
          {missions.map((ms) => {
            const isAdopted = ms.status === "ADOPTED";

            return (
              <div
                key={ms.id}
                className={cn(
                  "flex flex-wrap items-center justify-between gap-3 px-4 py-3 text-xs",
                  isAdopted ? "bg-[#1F5E63]/5" : "bg-white"
                )}
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono font-bold text-[#1F5E63]">
                      제{ms.episode.no}화
                    </span>
                    <Badge variant="default">
                      {ms.type === "expression" ? "표현 미션" : "팬덤명 공모"}
                    </Badge>
                    <span className="font-semibold text-zinc-900">
                      {ms.body}
                    </span>
                    {isAdopted && (
                      <Badge variant="tealSolid" className="gap-1">
                        <Award className="h-3 w-3" />
                        엔딩 크레딧 등재 대상
                      </Badge>
                    )}
                  </div>
                  <div className="text-[11px] text-zinc-500">
                    회차: {ms.episode.title} · 참여 투표 {ms.votes}건
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <select
                    aria-label={`미션 ${ms.id} 상태 변경`}
                    value={ms.status}
                    disabled={isPending}
                    onChange={(e) =>
                      handleMissionStatus(
                        ms.id,
                        e.target.value as "COLLECTING" | "ADOPTED" | "REJECTED"
                      )
                    }
                    className="rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1 text-xs font-semibold text-zinc-800 focus:border-[#1F5E63] focus:outline-none"
                  >
                    <option value="COLLECTING">수집중 (COLLECTING)</option>
                    <option value="ADOPTED">채택됨 · 크레딧 대상 (ADOPTED)</option>
                    <option value="REJECTED">보류 (REJECTED)</option>
                  </select>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
