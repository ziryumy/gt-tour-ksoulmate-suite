import db from "@/lib/db";
import { MemberGrid } from "@/components/member-grid";
import { Badge } from "@/components/ui/badge";

export const dynamic = "force-dynamic";

export default async function MembersPage() {
  // 5인은 항상 M1~M5 순서 고정 (정렬 옵션 없음)
  const members = await db.member.findMany({
    orderBy: { id: "asc" },
  });

  if (members.length === 0) {
    return (
      <div className="rounded-[8px] border border-zinc-200 bg-white p-6 text-xs text-zinc-600">
        아직 데이터가 없습니다. <code>npm run db:seed</code>를 실행하세요.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
        <div>
          <h1 className="text-base font-bold text-zinc-900">
            캐릭터 락 레지스트리 (5인)
          </h1>
          <p className="text-xs text-zinc-500">
            5인의 아이덴티티 고정 시트(M1~M5 고정 순서)를 확인하고 생성 프롬프트를 복사합니다.
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          <Badge variant="tealSolid">
            실사 시트 {members.filter((m) => m.locked).length}/5 확정
          </Badge>
          <Badge variant="default">정렬 고정 (M1~M5)</Badge>
        </div>
      </div>

      <MemberGrid members={members} />
    </div>
  );
}
