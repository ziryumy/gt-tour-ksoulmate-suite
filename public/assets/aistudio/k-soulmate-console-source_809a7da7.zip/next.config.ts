import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "cdn.omniultra.imagine.art",
      },
    ],
  },
};

export default nextConfig;
