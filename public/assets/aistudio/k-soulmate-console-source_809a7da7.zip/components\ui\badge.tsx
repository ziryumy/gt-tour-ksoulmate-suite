import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
import type { EpisodeStatus, VersionStatus } from "@prisma/client";
import { EPISODE_STATUS_LABELS, VERSION_STATUS_LABELS } from "@/lib/types";

const badgeVariants = cva(
  "inline-flex items-center border px-1.5 py-0.5 text-[11px] font-medium leading-tight rounded-[2px] select-none whitespace-nowrap",
  {
    variants: {
      variant: {
        default: "border-zinc-300 bg-zinc-100 text-zinc-700",
        teal: "border-[#1F5E63]/30 bg-[#1F5E63]/10 text-[#1F5E63]",
        tealSolid: "border-[#1F5E63] bg-[#1F5E63] text-white",
        amber: "border-amber-300 bg-amber-50 text-amber-800",
        red: "border-red-300 bg-red-50 text-red-700",
        emerald: "border-emerald-300 bg-emerald-50 text-emerald-800",
        muted: "border-zinc-200 bg-zinc-50 text-zinc-400",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return (
    <span className={cn(badgeVariants({ variant }), className)} {...props} />
  );
}

export function EpisodeStatusBadge({ status }: { status: EpisodeStatus }) {
  const variantMap: Record<
    EpisodeStatus,
    VariantProps<typeof badgeVariants>["variant"]
  > = {
    PLANNING: "default",
    SCRIPTED: "default",
    GENERATED: "teal",
    EDITED: "teal",
    REVIEWED: "amber",
    PUBLISHED: "tealSolid",
  };
  return (
    <Badge variant={variantMap[status]}>{EPISODE_STATUS_LABELS[status]}</Badge>
  );
}

export function VersionStatusBadge({ status }: { status: VersionStatus }) {
  const variantMap: Record<
    VersionStatus,
    VariantProps<typeof badgeVariants>["variant"]
  > = {
    TODO: "default",
    IN_PROGRESS: "amber",
    DONE: "tealSolid",
    BLOCKED: "red",
  };
  return (
    <Badge variant={variantMap[status]}>{VERSION_STATUS_LABELS[status]}</Badge>
  );
}
