"use client";

import React from "react";

export default function ConsoleError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="rounded-[8px] border border-red-300 bg-red-50 p-4 text-xs text-red-900">
      <h2 className="text-sm font-semibold text-red-800">
        화면을 불러오는 중 오류가 발생했습니다.
      </h2>
      <p className="mt-1 text-red-700">
        {error.message || "일시적인 데이터베이스 오류가 발생했습니다. 다시 시도해 주세요."}
      </p>
      <button
        type="button"
        onClick={() => reset()}
        className="mt-3 rounded-[4px] bg-[#1F5E63] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#17494d]"
      >
        다시 시도
      </button>
    </div>
  );
}
