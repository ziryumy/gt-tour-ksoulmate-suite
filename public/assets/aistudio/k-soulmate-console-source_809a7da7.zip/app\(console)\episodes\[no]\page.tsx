import Link from "next/link";
import { notFound } from "next/navigation";
import db from "@/lib/db";
import { Badge } from "@/components/ui/badge";
import { EpisodeStatusControl } from "@/components/episode-status-control";
import { EpisodeChannelTabs } from "@/components/episode-channel-tabs";
import { canPublish } from "@/lib/rules/compliance";
import { PURPOSE_LABELS, toStringArray, formatDateDot } from "@/lib/types";
import {
  ArrowLeft,
  Lock,
  CheckSquare,
  Square,
  ShieldAlert,
  CheckCircle2,
} from "lucide-react";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

const CHANNEL_ORDER = ["JP", "US", "KR", "CN"];

export default async function EpisodeDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ no: string }>;
  searchParams: Promise<{ channel?: string }>;
}) {
  const { no } = await params;
  const { channel: initialChannelCode } = await searchParams;
  const episodeNo = Number(no);

  if (!Number.isInteger(episodeNo) || episodeNo < 1) {
    notFound();
  }

  const [episode, channels, complianceItems, members] = await Promise.all([
    db.episode.findUnique({
      where: { no: episodeNo },
      include: {
        member: true,
        versions: {
          include: { channel: true },
        },
        runs: {
          orderBy: { createdAt: "desc" },
        },
      },
    }),
    db.channel.findMany(),
    db.complianceItem.findMany({
      orderBy: { code: "asc" },
    }),
    db.member.findMany(),
  ]);

  if (!episode) {
    notFound();
  }

  const checks = await db.complianceCheck.findMany({
    where: { episodeId: episode.id },
    include: { item: true },
  });

  const publishGate = canPublish({
    no: episode.no,
    complianceRisk: episode.complianceRisk,
    versions: episode.versions,
    checks,
  });

  const checkMap = new Map(checks.map((c) => [c.itemCode, c]));
  const expressions = toStringArray(episode.expressions);

  const orderedChannels = CHANNEL_ORDER.map((code) =>
    channels.find((c) => c.code === code)
  ).filter((c): c is NonNullable<typeof c> => Boolean(c));

  const tabItems = orderedChannels.map((ch) => ({
    channel: ch,
    version: episode.versions.find((v) => v.channelCode === ch.code) ?? null,
    narrator: members.find((m) => m.id === ch.narratorId) ?? null,
  }));

  const totalRunCredits = episode.runs.reduce((acc, r) => acc + r.credits, 0);

  return (
    <div className="space-y-4">
      {/* 상단 내비게이션 */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Link
          href="/episodes"
          className="inline-flex items-center gap-1 text-xs font-medium text-zinc-500 hover:text-[#1F5E63]"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          에피소드 보드(12화)로 돌아가기
        </Link>

        {publishGate.canPublish ? (
          <div className="inline-flex items-center gap-1.5 rounded-[4px] border border-emerald-300 bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-900">
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-700" />
            <span>발행 가능 (3채널 완료 · 필수 검수 통과)</span>
          </div>
        ) : (
          <div className="inline-flex items-center gap-1.5 rounded-[4px] border border-red-300 bg-red-50 px-2.5 py-1 text-[11px] font-semibold text-red-900">
            <ShieldAlert className="h-3.5 w-3.5 text-red-600" />
            <span>{publishGate.reason}</span>
          </div>
        )}
      </div>

      {/* 1. 헤더: 화번 · 제목 · 장소 · 담당 멤버 · 상태 이동 컨트롤 */}
      <header
        className={cn(
          "rounded-[8px] border p-4",
          episode.complianceRisk
            ? "border-amber-300 bg-amber-50/60"
            : "border-zinc-200 bg-white"
        )}
      >
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-[2px] bg-[#1F5E63] px-2 py-0.5 font-mono text-xs font-bold text-white">
                제{episode.no}화
              </span>
              <h1 className="text-base font-bold text-zinc-900">
                {episode.title}
              </h1>
              {episode.complianceRisk && (
                <Badge variant="amber">약기법 필수 검수 회차</Badge>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-zinc-600">
              <span>장소: {episode.place}</span>
              <span className="text-zinc-300">|</span>
              <span>
                담당 멤버:{" "}
                <strong className="font-semibold text-zinc-800">
                  {episode.member
                    ? `${episode.member.nameKo} (${episode.member.id} · ${episode.member.position})`
                    : "5인 전원 합류"}
                </strong>
              </span>
              {episode.baseVideoUrl && (
                <>
                  <span className="text-zinc-300">|</span>
                  <span className="font-mono text-[11px] text-zinc-500">
                    베이스 마스터: {episode.baseVideoUrl}
                  </span>
                </>
              )}
            </div>
          </div>

          <div className="flex flex-col items-end gap-1">
            <span className="text-[11px] text-zinc-500">
              단계 이동 (버튼 / 드롭다운)
            </span>
            <EpisodeStatusControl
              episodeNo={episode.no}
              currentStatus={episode.status}
            />
          </div>
        </div>
      </header>

      {/* 2. 오늘의 표현 3개 (읽기 전용 카드, 고정 항목) */}
      <section className="rounded-[8px] border border-zinc-200 bg-white p-4">
        <div className="mb-2.5 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Lock className="h-3.5 w-3.5 text-zinc-500" />
            <h2 className="text-xs font-bold text-zinc-900">
              오늘의 한국어 3표현
            </h2>
          </div>
          <Badge variant="default">고정 — 4채널 공통 원음</Badge>
        </div>
        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
          {expressions.map((expr, idx) => (
            <div
              key={idx}
              className="rounded-[6px] border border-zinc-200 bg-zinc-50 p-3"
            >
              <div className="font-mono text-[10px] font-semibold text-zinc-400">
                표현 0{idx + 1}
              </div>
              <div className="mt-1 text-xs font-semibold text-zinc-800">
                「{expr}」
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3 & 4. 채널 탭 4개 + 채널 버전 편집기 */}
      <EpisodeChannelTabs
        episode={{
          id: episode.id,
          no: episode.no,
          title: episode.title,
          place: episode.place,
          baseVideoUrl: episode.baseVideoUrl,
          expressions,
          complianceRisk: episode.complianceRisk,
        }}
        episodeMember={episode.member}
        items={tabItems}
        publishGate={publishGate}
        initialChannelCode={initialChannelCode}
      />

      {/* 하단 2열: 5. 생성 기록 표 + 6. 컴플라이언스 체크리스트 요약 */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* 5. 생성 기록 표 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white lg:col-span-6">
          <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-2.5">
            <div>
              <h2 className="text-xs font-bold text-zinc-900">생성 기록</h2>
              <p className="text-[11px] text-zinc-500">
                제{episode.no}화 외부 영상 생성 로그
              </p>
            </div>
            <span className="font-mono text-xs font-semibold text-[#1F5E63]">
              합계 {totalRunCredits.toLocaleString()} 크레딧
            </span>
          </div>

          {episode.runs.length === 0 ? (
            <div className="p-6 text-center text-xs text-zinc-500">
              아직 기록된 생성 로그가 없습니다.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-zinc-200 bg-zinc-50 text-[11px] font-semibold text-zinc-600">
                    <th className="px-3 py-2">모델</th>
                    <th className="px-3 py-2">목적</th>
                    <th className="px-3 py-2 text-right">시도</th>
                    <th className="px-3 py-2 text-right">채택</th>
                    <th className="px-3 py-2 text-right">크레딧</th>
                    <th className="px-3 py-2 text-right">일자</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-200">
                  {episode.runs.map((run) => (
                    <tr key={run.id}>
                      <td className="px-3 py-2 font-mono font-medium text-zinc-800">
                        {run.model}
                      </td>
                      <td className="px-3 py-2 text-zinc-600">
                        {PURPOSE_LABELS[run.purpose] ?? run.purpose}
                      </td>
                      <td className="px-3 py-2 text-right font-mono">
                        {run.attempts}
                      </td>
                      <td className="px-3 py-2 text-right font-mono">
                        {run.accepted}
                      </td>
                      <td className="px-3 py-2 text-right font-mono font-semibold text-zinc-900">
                        {run.credits.toLocaleString()}
                      </td>
                      <td className="px-3 py-2 text-right font-mono text-[11px] text-zinc-400">
                        {formatDateDot(run.createdAt)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* 6. 컴플라이언스 체크리스트 요약 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white lg:col-span-6">
          <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-2.5">
            <div>
              <h2 className="text-xs font-bold text-zinc-900">
                컴플라이언스 체크리스트 요약
              </h2>
              <p className="text-[11px] text-zinc-500">
                일본 시장 7개 법규 검수 상태
              </p>
            </div>
            <Link
              href="/compliance"
              className="text-[11px] font-medium text-[#1F5E63] hover:underline"
            >
              매트릭스에서 편집 →
            </Link>
          </div>

          <div className="divide-y divide-zinc-200">
            {complianceItems.map((item) => {
              const chk = checkMap.get(item.code);
              const done = chk?.done ?? false;
              const isYakgi = item.code === "JP-04";
              const isMandatoryYakgi = isYakgi && episode.complianceRisk;
              const isNotApplicableYakgi = isYakgi && !episode.complianceRisk;

              return (
                <div
                  key={item.code}
                  className={cn(
                    "flex items-center justify-between gap-2 px-4 py-2 text-xs",
                    isMandatoryYakgi && !done
                      ? "bg-amber-50/70"
                      : isNotApplicableYakgi
                      ? "bg-zinc-50 text-zinc-400"
                      : ""
                  )}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    {done ? (
                      <CheckSquare className="h-3.5 w-3.5 shrink-0 text-[#1F5E63]" />
                    ) : (
                      <Square className="h-3.5 w-3.5 shrink-0 text-zinc-400" />
                    )}
                    <span className="font-mono text-[11px] font-semibold">
                      {item.code}
                    </span>
                    <span className="truncate font-medium">{item.label}</span>
                    {isMandatoryYakgi && (
                      <Badge variant="amber">약기법 필수</Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {isNotApplicableYakgi ? (
                      <Badge variant="muted">일반 회차 (비대상)</Badge>
                    ) : (
                      <>
                        <Badge
                          variant={
                            item.blockAt === "BEFORE_PUBLISH" ? "red" : "default"
                          }
                        >
                          {item.blockAt === "BEFORE_PUBLISH"
                            ? "발행 전 필수"
                            : "런칭 시"}
                        </Badge>
                        <Badge variant={done ? "tealSolid" : "default"}>
                          {done ? "완료" : "미완료"}
                        </Badge>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
}
