# REPORT.md — K-soulmate 콘텐츠 운영 콘솔 최종 검증 보고서

작성일: 2026-10-27
대상 버전: Phase 1 (M1 ~ M5 전체 구현 완료)

---

## 1. AGENTS.md 2장 "절대 하지 말 것" 6개 항목 점검

| # | 금지 규칙 | 점검 결과 | 근거 |
|---|---|:---:|---|
| 1 | 드래그 앤 드롭으로 단계를 옮기게 만들지 말 것 | **준수 (위반 0)** | `dnd-kit`, `react-beautiful-dnd` 등 미설치. 전체 코드 내 `draggable`, `onDragStart`, `onDrop` 0건. 에피소드 단계 이동은 오직 `◀ 이전 / 다음 ▶` 버튼과 `<select>` 드롭다운으로만 구현 (`components/episode-status-control.tsx`) |
| 2 | AI 생성 API를 호출하지 말 것 | **준수 (위반 0)** | 외부 AI API(Higgsfield, Claude 등) SDK/엔드포인트 호출 코드 0건. 생성 결과 및 크레딧은 수동 기록(`recordGenerationRunAction`, `updateBudgetCreditUsedAction`) |
| 3 | 도메인 데이터를 창작하지 말 것 | **준수 (위반 0)** | `data/*.json` 6개 원본 파일 일체 수정 없음. `prisma/seed.ts`가 `data/*.json`을 그대로 읽어 DB 적재 |
| 4 | 결제·로그인·공개 페이지를 만들지 말 것 | **준수 (위반 0)** | 인증·결제·공개 팬페이지 라우트 없음 |
| 5 | UI 문구를 영어로 쓰지 말 것 | **준수 (위반 0)** | 모든 화면 라벨·상태 배지·경고·에러·빈 상태 안내 문구 한국어 적용 |
| 6 | 숫자를 반올림하거나 예쁘게 바꾸지 말 것 | **준수 (위반 0)** | `15.7시간`, `25.3시간`, `$350` (`$310 + $40`), `49만 원`, `9,400 크레딧` 등 원본 수치 그대로 표시 |

---

## 2. SPEC.md 6장 수용 기준 (AC-01 ~ AC-16) 전수 검증 표

| ID | 수용 기준 | 판정 | 검증 근거 (파일·라인 및 실행 결과) |
|---|---|:---:|---|
| **AC-01** | `npm run db:seed` 실행 후 DB에 Member 5건, Episode 12건, Channel 4건이 존재한다 | **통과** | `prisma/seed.ts` 멱등(`upsert`) 실행 결과 `Members=5, Episodes=12, Channels=4` 확인 |
| **AC-02** | `/members`에 5인 카드가 M1~M5 순서로 표시되고, 각 카드에 실사 시트 썸네일이 보인다 | **통과** | `app/(console)/members/page.tsx:9-11` (`orderBy: { id: "asc" }`), `components/member-grid.tsx:64-70` (`next/image` 썸네일) |
| **AC-03** | 멤버 상세에서 "프롬프트 복사"를 누르면 `outfitSpec`+`faceSpec`이 클립보드에 들어간다 | **통과** | `components/member-grid.tsx:18-39` 및 `194-209` (`navigator.clipboard.writeText`) |
| **AC-04** | `/episodes`에서 12화가 모두 보이고, 3·6·7화에 "약기법" 배지가 있다 | **통과** | `app/(console)/episodes/page.tsx:117-143`, `RiskEpisodes=3,6,7`에 연한 주황 배경(`bg-amber-50/70`) 및 `<Badge variant="amber">약기법</Badge>` 표시 |
| **AC-05** | 에피소드 상태를 버튼 또는 드롭다운으로만 변경할 수 있다. 드래그 앤 드롭 코드가 존재하지 않는다 | **통과** | `components/episode-status-control.tsx:45-106` (`◀ 이전` / `<select>` / `다음 ▶`), 드래그 코드 0건 |
| **AC-06** | 1화 상세에서 채널 탭 4개가 보이고, CN 탭은 "Phase 2" 배지와 함께 비활성이다 | **통과** | `components/episode-channel-tabs.tsx:58-87` (`disabled={!channel.active || channel.code === "CN"}` 및 `<Badge variant="muted">Phase 2</Badge>`) |
| **AC-07** | JP 채널 편집 화면의 섹션 순서가 대본 → V.O. → 편집 호흡 → BGM이고, US는 BGM → 컷 → V.O. 순서다 | **통과** | `components/channel-version-editor.tsx:528-534`에서 `channel.workflowOrder` 배열 순회 렌더링. 검증 출력: `JP_order=script->vo->cut->bgm->subtitle->publish | US_order=bgm->cut->vo->subtitle->publish` |
| **AC-08** | 컷 수 24, 총 길이 90을 입력하면 평균 컷이 3.75로 계산되어 표시된다. 컷 수를 10으로 바꾸면 경고가 뜬다 | **통과** | `lib/rules/length.ts:24-75` 및 `components/channel-version-editor.tsx:318-386`. 검증 출력: `24cuts/90s => avgCut=3.75, hasWarning=false | 10cuts/90s => avgCut=9, hasWarning=true` |
| **AC-09** | 채널 버전 편집 후 새로고침해도 값이 유지된다 (자동 저장 또는 저장 버튼) | **통과** | `components/channel-version-editor.tsx:136-188` (5초 디바운스 자동 저장 + 수동 저장 버튼) 및 `app/actions.ts:95-153` (`saveChannelVersionAction` Prisma upsert 영속화 확인) |
| **AC-10** | JP/US/KR 중 하나라도 DONE이 아니면 발행 버튼이 비활성이고, 사유가 구체적으로 표시된다 | **통과** | `lib/rules/compliance.ts:36-96` (`canPublish`). 검증 출력: `ep2 canPublish=false, reason="발행할 수 없습니다. 미완성 채널: US, KR"` |
| **AC-11** | 3화의 약기법 체크가 미완료면 발행이 차단된다 | **통과** | `lib/rules/compliance.ts:52-72` 및 `components/channel-version-editor.tsx:443-497`. 검증 출력: `ep3 (JP-04 false) canPublish=false, reason="발행할 수 없습니다. 미완료 검수: JP-04"` |
| **AC-12** | 크레딧 사용률 90%에서 대시보드 상단에 빨간 배너가 뜬다 | **통과** | `lib/rules/credits.ts:18-45` (`usageRatio >= 0.9` → `alertLevel="blocker"`), `app/(console)/dashboard/page.tsx:96-119` (`dashboard-red-alert-banner`) |
| **AC-13** | 팬덤명 후보 중 5개 검사 중 하나라도 미통과면 SHORTLIST 버튼이 비활성이다 | **통과** | `lib/rules/fandom.ts:44-52` (`canShortlist`), `components/engagement-client.tsx:287-302` (`disabled={!eligible ...}`) |
| **AC-14** | 응원 게이지 50%에서 "해금됨" 상태로 바뀐다 | **통과** | `app/actions.ts:346-380` (`unlocked = current >= gauge.threshold`) 및 `components/engagement-client.tsx:148-159` (`<Badge variant="tealSolid">해금됨</Badge>`) |
| **AC-15** | 375px 폭에서 사이드바가 접히고 표가 카드로 전환된다 | **통과** | `components/console-sidebar.tsx:73-155` (`md:hidden` 상단 헤더 + 드로어), `app/(console)/episodes/page.tsx:100` (`hidden md:block` 표) 및 `196행` (`md:hidden` 카드 리스트), `components/compliance-matrix.tsx:36` & `165행`, `components/engagement-client.tsx:221` & `322행` |
| **AC-16** | `npm run build`가 경고 없이 통과한다 | **통과** | `next build --turbopack` 실행 결과 TypeScript/ESLint 에러 및 경고 0건으로 전 라우트 빌드 성공 (exit 0) |

---

## 3. 빈 상태 (Empty State) 및 반응형 점검

- **빈 상태 안내 문구**: 모든 데이터 테이블이 비어 있을 때 `/dashboard`, `/members`, `/episodes`, `/credits`, `/compliance`, `/engagement` 전 화면에서 `"아직 데이터가 없습니다. npm run db:seed를 실행하세요."` 한국어 안내 문구를 출력합니다.
- **로딩 및 에러 처리**: `app/(console)/loading.tsx`(스켈레톤 + 한국어 안내), `app/(console)/error.tsx`(한국어 오류 메시지 및 재시도 버튼) 적용 완료.
- **반응형 레이아웃 (375px / 768px / 1280px)**:
  - `375px`: 좌측 사이드바가 상단 컴팩트 헤더(`K-soulmate 운영 콘솔` + 메뉴 버튼)로 접히고, 멤버 그리드는 1열, 에피소드·컴플라이언스·팬덤명 표는 모바일 카드 리스트로 자동 전환됩니다.
  - `768px / 1280px`: 고정 좌측 사이드바(`w-56`)와 고밀도 테이블·2열 그리드가 유지됩니다.

---

## 4. 남은 이슈 및 다음에 할 일 (Phase 2 이관 항목)

`DECISIONS.md` B절(미확정 항목)에 따라 아래 항목은 Phase 1에서 의도적으로 제외되었으며 추후 의사결정 후 확장합니다.

1. **애니메이션 캐릭터 시트 5인 완성 (B-4 / A-5)**:
   - 현재 하루토(M4) 파일럿 시트가 얼굴 동일성 3/5(13~15세로 보임) 판정이므로, `prompts/character-anime.md`의 **실사 시트 참조 변환 방식(8등신·긴 얼굴형·작은 눈 명시)** 으로 하루토 재검증 후 M1·M2·M3·M5까지 5장 모두 확보되면 `data/members.json`의 `animeSheetUrl`을 업데이트합니다.
2. **중화권(CN · 샤오홍슈) 채널 개시 (B-5)**:
   - 2분기 중국 파트너 경유 계정 개설 완료 후 `data/channels.json`의 `CN.active`를 `true`로 전환합니다.
3. **그룹명 최종 확정 (B-1)**:
   - 후보 5종(`오롯`, `이음`, `가온`, `새김`, `한결`) 중 상표·발음·3음절 검증 및 팬 투표를 거쳐 확정합니다.
4. **로그인·권한 및 외부 플랫폼 API 연동 (B-2, B-3, B-7)**:
   - Phase 2에서 팀원별 권한(유코·유키·가영) 및 SNS/Higgsfield 연동 여부를 검토합니다.
