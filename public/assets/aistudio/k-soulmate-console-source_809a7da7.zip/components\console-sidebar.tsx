"use client";

import React, { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Users,
  Film,
  Coins,
  ShieldAlert,
  HeartHandshake,
  Menu,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  href: string;
  label: string;
  subLabel: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV_ITEMS: NavItem[] = [
  {
    href: "/dashboard",
    label: "대시보드",
    subLabel: "오늘 할 일 · 요약",
    icon: LayoutDashboard,
  },
  {
    href: "/members",
    label: "캐릭터 락",
    subLabel: "5인 시트 · 프롬프트",
    icon: Users,
  },
  {
    href: "/episodes",
    label: "에피소드",
    subLabel: "시즌1 12화 × 4채널",
    icon: Film,
  },
  {
    href: "/credits",
    label: "크레딧",
    subLabel: "월 예산 · 채택률",
    icon: Coins,
  },
  {
    href: "/compliance",
    label: "컴플라이언스",
    subLabel: "일본 7항목 · 약기법",
    icon: ShieldAlert,
  },
  {
    href: "/engagement",
    label: "참여",
    subLabel: "게이지 · 팬덤명 · 미션",
    icon: HeartHandshake,
  },
];

export function ConsoleSidebar() {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isActive = (href: string) => {
    if (href === "/dashboard") return pathname === "/dashboard";
    return pathname === href || pathname.startsWith(`${href}/`);
  };

  return (
    <>
      {/* 모바일 상단 바 (375px ~ 767px) */}
      <header className="md:hidden sticky top-0 z-30 flex items-center justify-between border-b border-zinc-200 bg-white px-3.5 py-2.5">
        <div className="flex items-center gap-2">
          <span className="inline-block h-2.5 w-2.5 rounded-[2px] bg-[#1F5E63]" />
          <span className="text-sm font-semibold tracking-tight text-zinc-900">
            K-soulmate 운영 콘솔
          </span>
        </div>
        <button
          type="button"
          onClick={() => setMobileOpen((prev) => !prev)}
          aria-label={mobileOpen ? "메뉴 닫기" : "메뉴 열기"}
          className="inline-flex items-center justify-center rounded-[4px] border border-zinc-200 p-1.5 text-zinc-700 hover:bg-zinc-100"
        >
          {mobileOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </button>
      </header>

      {/* 모바일 오버레이 드로어 */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div
            className="fixed inset-0 bg-black/30"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="relative z-50 flex w-60 flex-col border-r border-zinc-200 bg-white">
            <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-3">
              <div>
                <p className="text-xs font-semibold text-[#1F5E63]">K-soulmate</p>
                <p className="text-sm font-bold text-zinc-900">콘텐츠 운영 콘솔</p>
              </div>
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                aria-label="메뉴 닫기"
                className="rounded-[4px] p-1 text-zinc-500 hover:bg-zinc-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <nav className="flex-1 space-y-0.5 p-2">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.href);
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      "flex items-center gap-2.5 rounded-[4px] px-2.5 py-2 text-xs font-medium transition-colors",
                      active
                        ? "bg-[#1F5E63] text-white"
                        : "text-zinc-700 hover:bg-zinc-100"
                    )}
                  >
                    <Icon
                      className={cn(
                        "h-4 w-4 shrink-0",
                        active ? "text-white" : "text-zinc-500"
                      )}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="truncate">{item.label}</div>
                      <div
                        className={cn(
                          "truncate text-[10px]",
                          active ? "text-zinc-200" : "text-zinc-400"
                        )}
                      >
                        {item.subLabel}
                      </div>
                    </div>
                  </Link>
                );
              })}
            </nav>
            <div className="border-t border-zinc-200 px-3.5 py-2.5 text-[11px] text-zinc-500">
              시즌 1 · 12화 × 4채널 · 내부 전용
            </div>
          </aside>
        </div>
      )}

      {/* 데스크톱 고정 좌측 사이드바 (768px 이상) */}
      <aside className="hidden md:flex md:w-56 md:flex-col md:fixed md:inset-y-0 md:left-0 border-r border-zinc-200 bg-white z-20">
        <div className="border-b border-zinc-200 px-4 py-3.5">
          <div className="flex items-center gap-1.5">
            <span className="inline-block h-2 w-2 rounded-[2px] bg-[#1F5E63]" />
            <span className="text-[11px] font-semibold tracking-wider text-[#1F5E63]">
              K-SOULMATE
            </span>
          </div>
          <h1 className="mt-0.5 text-sm font-bold text-zinc-900">
            콘텐츠 운영 콘솔
          </h1>
          <p className="mt-0.5 text-[11px] text-zinc-500">
            5인 · 12화 · 4채널 재조립
          </p>
        </div>

        <nav className="flex-1 space-y-0.5 px-2.5 py-3">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-2.5 rounded-[4px] px-2.5 py-2 text-xs font-medium transition-colors",
                  active
                    ? "bg-[#1F5E63] text-white"
                    : "text-zinc-700 hover:bg-zinc-100"
                )}
              >
                <Icon
                  className={cn(
                    "h-4 w-4 shrink-0",
                    active ? "text-white" : "text-zinc-500"
                  )}
                />
                <div className="min-w-0 flex-1">
                  <div className="truncate leading-snug">{item.label}</div>
                  <div
                    className={cn(
                      "truncate text-[10px] leading-tight",
                      active ? "text-zinc-200" : "text-zinc-400"
                    )}
                  >
                    {item.subLabel}
                  </div>
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-zinc-200 px-4 py-2.5 text-[11px] text-zinc-500 space-y-0.5">
          <div className="flex items-center justify-between">
            <span>운영 단계</span>
            <span className="font-mono font-semibold text-zinc-700">Phase 1</span>
          </div>
          <div className="flex items-center justify-between">
            <span>주당 기준 공수</span>
            <span className="font-mono text-zinc-700">25.3시간</span>
          </div>
        </div>
      </aside>
    </>
  );
}
