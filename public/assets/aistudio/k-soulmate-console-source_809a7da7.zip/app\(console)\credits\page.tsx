import fs from "fs";
import path from "path";
import Link from "next/link";
import db from "@/lib/db";
import { Badge } from "@/components/ui/badge";
import {
  evaluateCreditUsage,
  calculateEpisodeCreditStats,
} from "@/lib/rules/credits";
import { CreditsClient } from "@/components/credits-client";
import { AlertTriangle, ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

interface RawBudgetFile {
  currency: { assumedKrwPerUsd: number; note: string };
  monthlyBudget: {
    higgsfieldCreditsUsd: number;
    claudeUsd: number;
    claudeSeats: number;
    totalUsd: number;
    annualUsd: number;
    totalKrw: number;
  };
  notes: string[];
}

export default async function CreditsPage() {
  const [budget, episodes] = await Promise.all([
    db.budgetMonth.findFirst({ orderBy: { month: "desc" } }),
    db.episode.findMany({
      include: { runs: true },
      orderBy: { no: "asc" },
    }),
  ]);

  if (!budget) {
    return (
      <div className="rounded-[8px] border border-zinc-200 bg-white p-6 text-xs text-zinc-600">
        아직 데이터가 없습니다. <code>npm run db:seed</code>를 실행하세요.
      </div>
    );
  }

  const budgetJsonPath = path.join(process.cwd(), "data", "budget.json");
  const rawBudget = JSON.parse(
    fs.readFileSync(budgetJsonPath, "utf-8")
  ) as RawBudgetFile;

  const usage = evaluateCreditUsage(budget.creditUsed, budget.creditCap);
  const episodeStats = episodes.map((ep) => calculateEpisodeCreditStats(ep, 0.75));
  const totalLoggedCredits = episodeStats.reduce(
    (acc, s) => acc + s.totalCredits,
    0
  );

  const gaugeColorClass =
    usage.alertLevel === "blocker"
      ? "bg-red-600"
      : usage.alertLevel === "warning"
      ? "bg-amber-500"
      : "bg-[#1F5E63]";

  const totalManWon = Math.round(rawBudget.monthlyBudget.totalKrw / 10000);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
        <div>
          <h1 className="text-base font-bold text-zinc-900">크레딧 · 예산 관리</h1>
          <p className="text-xs text-zinc-500">
            크레딧은 다음 달로 이월되지 않습니다. 월 단위 상한과 회차별 채택률(기준 75%)을 점검합니다.
          </p>
        </div>
        <Badge variant="amber">월 단위 리셋 · 이월 불가</Badge>
      </div>

      {/* 임계치 경고/차단 배너 */}
      {usage.alertLevel !== "normal" && usage.alertMessage && (
        <div
          role="alert"
          className={cn(
            "flex items-start gap-2 rounded-[6px] border px-4 py-3 text-xs",
            usage.alertLevel === "blocker"
              ? "border-red-300 bg-red-50 text-red-900"
              : "border-amber-300 bg-amber-50 text-amber-900"
          )}
        >
          {usage.alertLevel === "blocker" ? (
            <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
          ) : (
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
          )}
          <div>
            <div className="font-bold">
              {usage.alertLevel === "blocker"
                ? "크레딧 90% 초과 위험 경보"
                : "크레딧 80% 도달 주의"}
            </div>
            <p className="mt-0.5">{usage.alertMessage}</p>
          </div>
        </div>
      )}

      {/* 1. 이번 달 게이지 + 2. 요금제 카드 + 4. 월 예산 요약 */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        {/* 1. 이번 달 게이지 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-900">
              이번 달 크레딧 게이지 ({budget.month})
            </span>
            <Badge
              variant={
                usage.alertLevel === "blocker"
                  ? "red"
                  : usage.alertLevel === "warning"
                  ? "amber"
                  : "teal"
              }
            >
              {usage.usagePercent}% 사용
            </Badge>
          </div>

          <div className="flex items-baseline justify-between font-mono">
            <span className="text-xl font-bold text-zinc-900">
              {usage.creditUsed.toLocaleString()}
            </span>
            <span className="text-xs text-zinc-500">
              / {usage.creditCap.toLocaleString()} 크레딧 (잔여{" "}
              {usage.remainingCredits.toLocaleString()})
            </span>
          </div>

          <div className="h-2.5 w-full overflow-hidden rounded-[2px] bg-zinc-100">
            <div
              data-testid="credit-gauge-bar"
              className={cn("h-full transition-all", gaugeColorClass)}
              style={{ width: `${Math.min(100, usage.usagePercent)}%` }}
            />
          </div>

          <div className="flex justify-between text-[10px] font-mono text-zinc-400">
            <span>0%</span>
            <span className="text-amber-600">80% 경고 (7,520)</span>
            <span className="text-red-600">90% 차단 (8,460)</span>
          </div>
        </section>

        {/* 2. 요금제 카드 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-900">현재 요금제 구성</span>
            <Badge variant="tealSolid">{budget.plan.toUpperCase()}</Badge>
          </div>
          <div className="space-y-1 text-xs text-zinc-600">
            <div className="flex justify-between">
              <span>Higgsfield 플랜</span>
              <span className="font-mono font-semibold text-zinc-900">
                {budget.plan.toUpperCase()} (승인 상한 {budget.creditCap.toLocaleString()} 크레딧)
              </span>
            </div>
            <div className="flex justify-between">
              <span>Claude Team Standard</span>
              <span className="font-mono font-semibold text-zinc-900">
                {budget.claudeSeats}석 ($20 × {budget.claudeSeats})
              </span>
            </div>
            <div className="flex justify-between">
              <span>월 계획 생성량</span>
              <span className="font-mono text-zinc-800">
                약 416회 (숏폼4·참여4·장편1)
              </span>
            </div>
          </div>
        </section>

        {/* 4. 월 예산 요약 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-900">월 예산 요약</span>
            <span className="font-mono text-[11px] text-zinc-500">
              가정 환율 {rawBudget.currency.assumedKrwPerUsd.toLocaleString()}원/$
            </span>
          </div>
          <div className="space-y-1 text-xs text-zinc-600">
            <div className="flex justify-between">
              <span>크레딧 비용 + Claude 비용</span>
              <span className="font-mono text-zinc-900">
                ${rawBudget.monthlyBudget.higgsfieldCreditsUsd} + $
                {rawBudget.monthlyBudget.claudeUsd}
              </span>
            </div>
            <div className="flex justify-between border-t border-zinc-100 pt-1.5">
              <span className="font-semibold text-zinc-800">월 합계</span>
              <span className="font-mono text-sm font-bold text-[#1F5E63]">
                ${rawBudget.monthlyBudget.totalUsd} (약 {totalManWon}만 원)
              </span>
            </div>
            <div className="flex justify-between text-[11px] text-zinc-400">
              <span>연간 환산</span>
              <span className="font-mono">
                ${rawBudget.monthlyBudget.annualUsd.toLocaleString()}
              </span>
            </div>
          </div>
        </section>
      </div>

      {/* 5. 수동 입력 및 생성 기록 추가 폼 */}
      <CreditsClient
        month={budget.month}
        initialCreditUsed={budget.creditUsed}
        creditCap={budget.creditCap}
      />

      {/* 3. 회차별 소모 표 (채택률 75% 미만 행 강조) */}
      <section className="rounded-[8px] border border-zinc-200 bg-white">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 px-4 py-3">
          <div>
            <h2 className="text-xs font-bold text-zinc-900">
              회차별 생성 소모 및 채택률 표
            </h2>
            <p className="text-[11px] text-zinc-500">
              채택률(채택 컷 ÷ 시도 횟수)이 기준값 75% 미만인 회차는 재생성 위험으로 강조됩니다.
            </p>
          </div>
          <div className="font-mono text-xs font-semibold text-zinc-700">
            회차 로그 합계: {totalLoggedCredits.toLocaleString()} 크레딧
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-200 bg-zinc-50 text-[11px] font-semibold text-zinc-600">
                <th className="px-3.5 py-2.5 w-16">회차</th>
                <th className="px-3.5 py-2.5">제목</th>
                <th className="px-3.5 py-2.5 text-right">생성 횟수 (시도/채택)</th>
                <th className="px-3.5 py-2.5 text-right">채택률 (기준 75%)</th>
                <th className="px-3.5 py-2.5 text-right">소모 크레딧</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200">
              {episodeStats.map((st) => (
                <tr
                  key={st.episodeId}
                  data-testid={`credit-row-ep-${st.episodeNo}`}
                  className={cn(
                    "transition-colors hover:bg-zinc-50",
                    st.isLowAdoption ? "bg-amber-50/80" : "bg-white"
                  )}
                >
                  <td className="px-3.5 py-2.5 font-mono font-bold text-zinc-900">
                    <Link
                      href={`/episodes/${st.episodeNo}`}
                      className="hover:text-[#1F5E63] hover:underline"
                    >
                      제{st.episodeNo}화
                    </Link>
                  </td>
                  <td className="px-3.5 py-2.5 font-medium text-zinc-800">
                    <div className="flex items-center gap-2">
                      <span>{st.episodeTitle}</span>
                      {st.isLowAdoption && (
                        <Badge variant="amber">재생성 위험 (&lt;75%)</Badge>
                      )}
                    </div>
                  </td>
                  <td className="px-3.5 py-2.5 text-right font-mono text-zinc-700">
                    {st.totalAttempts > 0
                      ? `${st.totalAttempts}회 (${st.totalAccepted}컷 채택)`
                      : "-"}
                  </td>
                  <td className="px-3.5 py-2.5 text-right font-mono">
                    {st.adoptionPercent !== null ? (
                      <span
                        className={cn(
                          "font-semibold",
                          st.isLowAdoption ? "text-amber-800" : "text-[#1F5E63]"
                        )}
                      >
                        {st.adoptionPercent}%
                      </span>
                    ) : (
                      <span className="text-zinc-400">미실행</span>
                    )}
                  </td>
                  <td className="px-3.5 py-2.5 text-right font-mono font-semibold text-zinc-900">
                    {st.totalCredits > 0
                      ? `${st.totalCredits.toLocaleString()} 크레딧`
                      : "0"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
