export type CreditAlertLevel = "normal" | "warning" | "blocker";

export interface CreditUsageSummary {
  creditUsed: number;
  creditCap: number;
  usageRatio: number;
  usagePercent: number;
  remainingCredits: number;
  alertLevel: CreditAlertLevel;
  alertMessage: string | null;
}

/**
 * SPEC 5.3 크레딧 규칙
 * usageRatio = creditUsed / creditCap
 * if (usageRatio >= 0.9) -> blocker 배너
 * if (usageRatio >= 0.8) -> warning 배너
 */
export function evaluateCreditUsage(
  creditUsed: number,
  creditCap: number
): CreditUsageSummary {
  const safeCap = creditCap > 0 ? creditCap : 1;
  const usageRatio = creditUsed / safeCap;
  const usagePercent = Number((usageRatio * 100).toFixed(1));
  const remainingCredits = Math.max(0, creditCap - creditUsed);

  let alertLevel: CreditAlertLevel = "normal";
  let alertMessage: string | null = null;

  if (usageRatio >= 0.9) {
    alertLevel = "blocker";
    alertMessage = `이번 달 크레딧 사용률이 ${usagePercent}% (${creditUsed.toLocaleString()} / ${creditCap.toLocaleString()})로 위험 임계치(90%)를 도달·초과했습니다. 재생성을 중단하고 잔여 크레딧(${remainingCredits.toLocaleString()})을 점검하세요.`;
  } else if (usageRatio >= 0.8) {
    alertLevel = "warning";
    alertMessage = `이번 달 크레딧 사용률이 ${usagePercent}% (${creditUsed.toLocaleString()} / ${creditCap.toLocaleString()})로 경고 임계치(80%)를 넘었습니다.`;
  }

  return {
    creditUsed,
    creditCap,
    usageRatio,
    usagePercent,
    remainingCredits,
    alertLevel,
    alertMessage,
  };
}

export interface EpisodeCreditSummary {
  episodeId: number;
  episodeNo: number;
  episodeTitle: string;
  runCount: number;
  totalAttempts: number;
  totalAccepted: number;
  adoptionRate: number | null;
  adoptionPercent: number | null;
  isLowAdoption: boolean;
  totalCredits: number;
}

export function calculateEpisodeCreditStats(
  episode: {
    id: number;
    no: number;
    title: string;
    runs: Array<{ attempts: number; accepted: number; credits: number }>;
  },
  threshold = 0.75
): EpisodeCreditSummary {
  const runCount = episode.runs.length;
  const totalAttempts = episode.runs.reduce((acc, r) => acc + r.attempts, 0);
  const totalAccepted = episode.runs.reduce((acc, r) => acc + r.accepted, 0);
  const totalCredits = episode.runs.reduce((acc, r) => acc + r.credits, 0);

  if (totalAttempts === 0) {
    return {
      episodeId: episode.id,
      episodeNo: episode.no,
      episodeTitle: episode.title,
      runCount,
      totalAttempts: 0,
      totalAccepted: 0,
      adoptionRate: null,
      adoptionPercent: null,
      isLowAdoption: false,
      totalCredits: 0,
    };
  }

  const adoptionRate = totalAccepted / totalAttempts;
  const adoptionPercent = Number((adoptionRate * 100).toFixed(1));
  const isLowAdoption = adoptionRate < threshold;

  return {
    episodeId: episode.id,
    episodeNo: episode.no,
    episodeTitle: episode.title,
    runCount,
    totalAttempts,
    totalAccepted,
    adoptionRate,
    adoptionPercent,
    isLowAdoption,
    totalCredits,
  };
}
