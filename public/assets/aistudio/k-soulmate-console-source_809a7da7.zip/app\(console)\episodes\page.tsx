import Link from "next/link";
import db from "@/lib/db";
import { Badge } from "@/components/ui/badge";
import { EpisodeStatusControl } from "@/components/episode-status-control";
import { toStringArray, VERSION_STATUS_LABELS } from "@/lib/types";
import { cn } from "@/lib/utils";
import type { VersionStatus } from "@prisma/client";

export const dynamic = "force-dynamic";

const CHANNEL_ORDER = ["JP", "US", "KR", "CN"] as const;

function ChannelDot({
  episodeNo,
  code,
  status,
  active,
}: {
  episodeNo: number;
  code: string;
  status: VersionStatus;
  active: boolean;
}) {
  const dotClass = !active
    ? "bg-zinc-200 border-zinc-300"
    : status === "DONE"
    ? "bg-[#1F5E63] border-[#1F5E63]"
    : status === "IN_PROGRESS"
    ? "bg-amber-500 border-amber-600"
    : status === "BLOCKED"
    ? "bg-red-500 border-red-600"
    : "bg-zinc-200 border-zinc-300";

  if (!active) {
    return (
      <span
        title={`${code}: Phase 2 (비활성)`}
        className="inline-flex items-center gap-1 text-[10px] font-mono text-zinc-400"
      >
        <span className={cn("inline-block h-2 w-2 rounded-[1px] border", dotClass)} />
        <span>{code}</span>
      </span>
    );
  }

  return (
    <Link
      href={`/episodes/${episodeNo}/channels/${code}`}
      title={`${code} 편집 (${VERSION_STATUS_LABELS[status]})`}
      className="inline-flex items-center gap-1 rounded-[2px] px-1 py-0.5 text-[10px] font-mono text-zinc-700 hover:bg-zinc-200/70"
    >
      <span className={cn("inline-block h-2 w-2 rounded-[1px] border", dotClass)} />
      <span>{code}</span>
    </Link>
  );
}

export default async function EpisodesPage() {
  const [episodes, channels] = await Promise.all([
    db.episode.findMany({
      include: {
        member: true,
        versions: true,
      },
      orderBy: { no: "asc" },
    }),
    db.channel.findMany(),
  ]);

  if (episodes.length === 0) {
    return (
      <div className="rounded-[8px] border border-zinc-200 bg-white p-6 text-xs text-zinc-600">
        아직 데이터가 없습니다. <code>npm run db:seed</code>를 실행하세요.
      </div>
    );
  }

  const channelMap = new Map(channels.map((c) => [c.code, c]));

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
        <div>
          <h1 className="text-base font-bold text-zinc-900">
            에피소드 보드 (시즌1 · 12화)
          </h1>
          <p className="text-xs text-zinc-500">
            12화의 제작 단계(버튼/드롭다운 이동), 담당 멤버, 오늘의 한국어 3표현 및 4채널 진행 현황을 관리합니다.
          </p>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-zinc-500">
          <span className="inline-flex items-center gap-1">
            <span className="inline-block h-2 w-2 rounded-[1px] bg-[#1F5E63]" /> 완료
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="inline-block h-2 w-2 rounded-[1px] bg-amber-500" /> 진행중
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="inline-block h-2 w-2 rounded-[1px] bg-zinc-200 border border-zinc-300" /> 대기/Phase2
          </span>
        </div>
      </div>

      {/* 데스크톱 표 (768px 이상, zebra 없이 hairline 구분선) */}
      <div className="hidden md:block overflow-x-auto rounded-[8px] border border-zinc-200 bg-white">
        <table className="w-full border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-zinc-200 bg-zinc-50 text-[11px] font-semibold text-zinc-600">
              <th className="px-3 py-2.5 w-14">화</th>
              <th className="px-3 py-2.5">제목</th>
              <th className="px-3 py-2.5">장소</th>
              <th className="px-3 py-2.5 w-24">담당</th>
              <th className="px-3 py-2.5">오늘의 표현 (3개)</th>
              <th className="px-3 py-2.5 w-56">상태 이동 (버튼/드롭다운)</th>
              <th className="px-3 py-2.5 w-44">채널 진행 (4개 점)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-200">
            {episodes.map((ep) => {
              const expressions = toStringArray(ep.expressions);
              const verMap = new Map(ep.versions.map((v) => [v.channelCode, v]));

              return (
                <tr
                  key={ep.id}
                  className={cn(
                    "transition-colors hover:bg-zinc-100/70",
                    ep.complianceRisk ? "bg-amber-50/70" : "bg-white"
                  )}
                >
                  <td className="px-3 py-2.5 font-mono font-bold text-zinc-900">
                    <Link
                      href={`/episodes/${ep.no}`}
                      className="block hover:text-[#1F5E63]"
                    >
                      제{ep.no}화
                    </Link>
                  </td>
                  <td className="px-3 py-2.5">
                    <Link
                      href={`/episodes/${ep.no}`}
                      className="flex items-center gap-1.5 font-semibold text-zinc-900 hover:text-[#1F5E63] hover:underline"
                    >
                      <span>{ep.title}</span>
                      {ep.complianceRisk && (
                        <Badge variant="amber">약기법</Badge>
                      )}
                    </Link>
                  </td>
                  <td className="px-3 py-2.5 text-zinc-600">{ep.place}</td>
                  <td className="px-3 py-2.5">
                    {ep.member ? (
                      <span className="font-medium text-zinc-800">
                        {ep.member.nameKo}{" "}
                        <span className="font-mono text-[10px] text-zinc-400">
                          ({ep.member.id})
                        </span>
                      </span>
                    ) : (
                      <span className="text-zinc-500">5인 전원</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex flex-wrap gap-1">
                      {expressions.map((expr, idx) => (
                        <span
                          key={idx}
                          className="rounded-[2px] border border-zinc-200 bg-white/80 px-1.5 py-0.5 text-[11px] text-zinc-700"
                        >
                          {expr}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="px-3 py-2.5">
                    <EpisodeStatusControl
                      episodeNo={ep.no}
                      currentStatus={ep.status}
                    />
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-1.5">
                      {CHANNEL_ORDER.map((code) => {
                        const ver = verMap.get(code);
                        const ch = channelMap.get(code);
                        return (
                          <ChannelDot
                            key={code}
                            episodeNo={ep.no}
                            code={code}
                            status={ver?.status ?? "TODO"}
                            active={ch?.active ?? code !== "CN"}
                          />
                        );
                      })}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* 모바일 카드 리스트 (768px 미만 / 375px 폭 대응) */}
      <div className="md:hidden space-y-2.5">
        {episodes.map((ep) => {
          const expressions = toStringArray(ep.expressions);
          const verMap = new Map(ep.versions.map((v) => [v.channelCode, v]));

          return (
            <div
              key={ep.id}
              className={cn(
                "rounded-[8px] border p-3.5 transition-colors",
                ep.complianceRisk
                  ? "border-amber-300 bg-amber-50/70"
                  : "border-zinc-200 bg-white"
              )}
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <Link
                  href={`/episodes/${ep.no}`}
                  className="flex items-center gap-1.5"
                >
                  <span className="font-mono text-xs font-bold text-[#1F5E63]">
                    제{ep.no}화
                  </span>
                  {ep.complianceRisk && <Badge variant="amber">약기법</Badge>}
                </Link>
                <EpisodeStatusControl
                  episodeNo={ep.no}
                  currentStatus={ep.status}
                  compact
                />
              </div>

              <Link href={`/episodes/${ep.no}`} className="block mt-1.5">
                <h2 className="text-sm font-bold text-zinc-900 hover:text-[#1F5E63] hover:underline">
                  {ep.title}
                </h2>
                <div className="mt-0.5 text-xs text-zinc-600">
                  {ep.place} ·{" "}
                  {ep.member ? `${ep.member.nameKo} (${ep.member.id})` : "5인 전원"}
                </div>
              </Link>

              <div className="mt-2 flex flex-wrap gap-1">
                {expressions.map((expr, idx) => (
                  <span
                    key={idx}
                    className="rounded-[2px] border border-zinc-200 bg-white px-1.5 py-0.5 text-[11px] text-zinc-700"
                  >
                    {expr}
                  </span>
                ))}
              </div>

              <div className="mt-2.5 flex items-center justify-between border-t border-zinc-200/70 pt-2">
                <span className="text-[11px] text-zinc-500">채널 진행</span>
                <div className="flex items-center gap-1.5">
                  {CHANNEL_ORDER.map((code) => {
                    const ver = verMap.get(code);
                    const ch = channelMap.get(code);
                    return (
                      <ChannelDot
                        key={code}
                        episodeNo={ep.no}
                        code={code}
                        status={ver?.status ?? "TODO"}
                        active={ch?.active ?? code !== "CN"}
                      />
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
