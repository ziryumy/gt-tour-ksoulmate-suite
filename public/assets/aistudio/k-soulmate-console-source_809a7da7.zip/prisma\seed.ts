import { PrismaClient, EpisodeStatus, VersionStatus } from "@prisma/client";
import fs from "fs";
import path from "path";

const prisma = new PrismaClient();

interface RawMember {
  id: string;
  nameKo: string;
  nameJa?: string | null;
  nameZh?: string | null;
  nationality: string;
  position: string;
  age: number;
  heightCm: number;
  photoSheetUrl: string;
  animeSheetUrl?: string | null;
  outfitSpec: string;
  faceSpec: string;
  voiceProfile?: string | null;
  channelCode?: string | null;
  locked: boolean;
}

interface RawChannel {
  code: string;
  label: string;
  narratorId: string;
  tone: string;
  totalSec: number;
  cutCount: number;
  avgCutSec: number;
  rhythmBasis: string;
  workflowOrder: string[];
  bgmTracks: string[];
  active: boolean;
}

interface RawEpisode {
  no: number;
  title: string;
  place: string;
  memberId: string | null;
  expressions: string[];
  status: EpisodeStatus;
  complianceRisk: boolean;
}

interface RawComplianceItem {
  code: string;
  label: string;
  detail: string;
  blockAt: string;
  ownerRole?: string;
}

interface RawBudget {
  monthlyPlan: {
    estimatedCredits: number;
  };
  monthlyBudget: {
    claudeSeats: number;
    totalUsd: number;
  };
}

interface RawKpis {
  gaugeSeed: Array<{
    label: string;
    threshold: number;
    current: number;
  }>;
}

function readJson<T>(filename: string): T {
  const filePath = path.join(process.cwd(), "data", filename);
  return JSON.parse(fs.readFileSync(filePath, "utf-8")) as T;
}

async function main() {
  const members = readJson<RawMember[]>("members.json");
  const channels = readJson<RawChannel[]>("channels.json");
  const episodes = readJson<RawEpisode[]>("episodes.json");
  const complianceItems = readJson<RawComplianceItem[]>("compliance.json");
  const budget = readJson<RawBudget>("budget.json");
  const kpis = readJson<RawKpis>("kpis.json");

  // 1. Seed Members
  for (const m of members) {
    await prisma.member.upsert({
      where: { id: m.id },
      update: {
        nameKo: m.nameKo,
        nameJa: m.nameJa ?? null,
        nameZh: m.nameZh ?? null,
        nationality: m.nationality,
        position: m.position,
        age: m.age,
        heightCm: m.heightCm,
        photoSheetUrl: m.photoSheetUrl,
        animeSheetUrl: m.animeSheetUrl ?? null,
        outfitSpec: m.outfitSpec,
        faceSpec: m.faceSpec,
        voiceProfile: m.voiceProfile ?? null,
        channelCode: m.channelCode ?? null,
        locked: m.locked,
      },
      create: {
        id: m.id,
        nameKo: m.nameKo,
        nameJa: m.nameJa ?? null,
        nameZh: m.nameZh ?? null,
        nationality: m.nationality,
        position: m.position,
        age: m.age,
        heightCm: m.heightCm,
        photoSheetUrl: m.photoSheetUrl,
        animeSheetUrl: m.animeSheetUrl ?? null,
        outfitSpec: m.outfitSpec,
        faceSpec: m.faceSpec,
        voiceProfile: m.voiceProfile ?? null,
        channelCode: m.channelCode ?? null,
        locked: m.locked,
      },
    });
  }

  // 2. Seed Channels
  for (const c of channels) {
    await prisma.channel.upsert({
      where: { code: c.code },
      update: {
        label: c.label,
        narratorId: c.narratorId,
        tone: c.tone,
        totalSec: c.totalSec,
        cutCount: c.cutCount,
        avgCutSec: c.avgCutSec,
        rhythmBasis: c.rhythmBasis,
        workflowOrder: c.workflowOrder,
        bgmTracks: c.bgmTracks,
        active: c.active,
      },
      create: {
        code: c.code,
        label: c.label,
        narratorId: c.narratorId,
        tone: c.tone,
        totalSec: c.totalSec,
        cutCount: c.cutCount,
        avgCutSec: c.avgCutSec,
        rhythmBasis: c.rhythmBasis,
        workflowOrder: c.workflowOrder,
        bgmTracks: c.bgmTracks,
        active: c.active,
      },
    });
  }

  // 3. Seed Episodes & ChannelVersions
  const ep1Narrations: Record<string, string> = {
    JP: `오늘, 처음으로 혼자 주문했어요.\n형은 밖에 나가 있었어요. 저 혼자였어요.\n카운터까지 걸어가는 동안, 손이 조금 떨렸어요.\n「얼음은 적게 넣어 주세요」\n연습한 그 문장이, 제 입에서 나왔어요.\n컵을 받았을 때 —\n아, 왠지 조금 자랑스러웠어요.\n형은 밖에서 웃고 있었어요.`,
    US: `Okay so — watch this.\nHyung dips. Leaves him ALONE.\nJust him, the counter, and pure pressure.\nBarista's like "... you good?"\nAnd he says it. Clean.\n「얼음은 적게」— ICE. LESS.\nMan said it PERFECT. First try. No help.\nOkay okay okay. That's my boy.`,
    KR: `혼자 주문에 성공했습니다.\n오늘 배운 표현은 「얼음은 적게 넣어 주세요」입니다.\n성수동 ○○카페에서 실제로 통하는 문장입니다.\n다음 화는 편의점입니다. 훨씬 어렵습니다.`,
    CN: "",
  };

  for (const e of episodes) {
    const ep = await prisma.episode.upsert({
      where: { no: e.no },
      update: {
        title: e.title,
        place: e.place,
        memberId: e.memberId,
        expressions: e.expressions,
        status: e.status,
        complianceRisk: e.complianceRisk,
        baseVideoUrl: e.no <= 4 ? `https://storage.k-soulmate.internal/ep-${String(e.no).padStart(2, "0")}-master-130s.mp4` : null,
      },
      create: {
        no: e.no,
        title: e.title,
        place: e.place,
        memberId: e.memberId,
        expressions: e.expressions,
        status: e.status,
        complianceRisk: e.complianceRisk,
        baseVideoUrl: e.no <= 4 ? `https://storage.k-soulmate.internal/ep-${String(e.no).padStart(2, "0")}-master-130s.mp4` : null,
      },
    });

    for (const c of channels) {
      let vStatus: VersionStatus = VersionStatus.TODO;
      let voStatus: VersionStatus = VersionStatus.TODO;
      if (e.no === 1 && c.active) {
        vStatus = VersionStatus.DONE;
        voStatus = VersionStatus.DONE;
      } else if (e.no === 2 && c.code === "JP") {
        vStatus = VersionStatus.DONE;
        voStatus = VersionStatus.DONE;
      } else if (e.no === 2 && (c.code === "US" || c.code === "KR")) {
        vStatus = VersionStatus.IN_PROGRESS;
        voStatus = VersionStatus.IN_PROGRESS;
      } else if (e.no === 3 && c.code === "JP") {
        vStatus = VersionStatus.IN_PROGRESS;
        voStatus = VersionStatus.DONE;
      }

      await prisma.channelVersion.upsert({
        where: {
          episodeId_channelCode: {
            episodeId: ep.id,
            channelCode: c.code,
          },
        },
        update: {
          narration: e.no === 1 ? ep1Narrations[c.code] ?? "" : "",
          voStatus,
          bgmTrackId: c.bgmTracks[0] ?? null,
          cutCount: c.cutCount,
          totalSec: c.totalSec,
          status: vStatus,
          publishedUrl:
            e.no === 1 && c.active
              ? `https://social.k-soulmate.internal/${c.code.toLowerCase()}/ep-01`
              : null,
          publishedAt: e.no === 1 && c.active ? new Date("2026-10-20T09:00:00Z") : null,
        },
        create: {
          episodeId: ep.id,
          channelCode: c.code,
          narration: e.no === 1 ? ep1Narrations[c.code] ?? "" : "",
          voStatus,
          bgmTrackId: c.bgmTracks[0] ?? null,
          cutCount: c.cutCount,
          totalSec: c.totalSec,
          status: vStatus,
          publishedUrl:
            e.no === 1 && c.active
              ? `https://social.k-soulmate.internal/${c.code.toLowerCase()}/ep-01`
              : null,
          publishedAt: e.no === 1 && c.active ? new Date("2026-10-20T09:00:00Z") : null,
        },
      });
    }
  }

  // 4. Seed ComplianceItems & ComplianceChecks
  for (const item of complianceItems) {
    await prisma.complianceItem.upsert({
      where: { code: item.code },
      update: {
        label: item.label,
        detail: item.detail,
        blockAt: item.blockAt,
      },
      create: {
        code: item.code,
        label: item.label,
        detail: item.detail,
        blockAt: item.blockAt,
      },
    });
  }

  const allEpisodes = await prisma.episode.findMany({ orderBy: { no: "asc" } });
  for (const ep of allEpisodes) {
    for (const item of complianceItems) {
      const done =
        ep.no === 1 ||
        (ep.no === 2 && item.blockAt === "BEFORE_PUBLISH" && item.code !== "JP-04") ||
        (ep.no === 2 && item.code === "JP-04");
      await prisma.complianceCheck.upsert({
        where: {
          episodeId_itemCode: {
            episodeId: ep.id,
            itemCode: item.code,
          },
        },
        update: {
          done,
          owner: item.ownerRole ?? "",
        },
        create: {
          episodeId: ep.id,
          itemCode: item.code,
          done,
          owner: item.ownerRole ?? "",
        },
      });
    }
  }

  // 5. Seed BudgetMonth
  await prisma.budgetMonth.upsert({
    where: { month: "2026-11" },
    update: {
      plan: "ultra",
      creditCap: budget.monthlyPlan.estimatedCredits,
      creditUsed: 5640,
      claudeSeats: budget.monthlyBudget.claudeSeats,
      costUsd: budget.monthlyBudget.totalUsd,
    },
    create: {
      month: "2026-11",
      plan: "ultra",
      creditCap: budget.monthlyPlan.estimatedCredits,
      creditUsed: 5640,
      claudeSeats: budget.monthlyBudget.claudeSeats,
      costUsd: budget.monthlyBudget.totalUsd,
    },
  });

  // 6. Seed Gauge (from kpis.json)
  for (let i = 0; i < kpis.gaugeSeed.length; i++) {
    const g = kpis.gaugeSeed[i];
    await prisma.gauge.upsert({
      where: { id: i + 1 },
      update: {
        label: g.label,
        threshold: g.threshold,
        current: g.current,
        unlocked: g.current >= g.threshold,
      },
      create: {
        id: i + 1,
        label: g.label,
        threshold: g.threshold,
        current: g.current,
        unlocked: g.current >= g.threshold,
      },
    });
  }

  // 7. Seed FandomCandidates (from DECISIONS.md B-1)
  const fandomSeed = [
    { id: 1, name: "오롯", reason: "모자람 없이 온전한 다섯 명의 하모니", votes: 142, checkTm: true, checkDup: true, checkWord: true, checkPron: true, checkChant: true, status: "SHORTLIST" },
    { id: 2, name: "이음", reason: "한국어 표현으로 세계 팬들의 마음을 잇다", votes: 118, checkTm: true, checkDup: true, checkWord: true, checkPron: true, checkChant: true, status: "CANDIDATE" },
    { id: 3, name: "가온", reason: "세상의 중심에서 함께 성장하는 메이트", votes: 95, checkTm: true, checkDup: false, checkWord: true, checkPron: true, checkChant: true, status: "CANDIDATE" },
    { id: 4, name: "새김", reason: "매일 세 문장씩 마음에 새기는 기록", votes: 84, checkTm: true, checkDup: true, checkWord: true, checkPron: false, checkChant: true, status: "CANDIDATE" },
    { id: 5, name: "한결", reason: "처음부터 끝까지 한결같은 응원", votes: 63, checkTm: true, checkDup: true, checkWord: true, checkPron: true, checkChant: false, status: "CANDIDATE" },
  ];

  for (const fc of fandomSeed) {
    await prisma.fandomCandidate.upsert({
      where: { id: fc.id },
      update: fc,
      create: fc,
    });
  }

  // 8. Seed GenerationRuns (idempotent via deterministic IDs)
  const epByNo = new Map(allEpisodes.map((e) => [e.no, e.id]));
  const runSeed = [
    { id: 1, episodeId: epByNo.get(1)!, model: "seedance-2.0", purpose: "base", attempts: 59, accepted: 44, credits: 1350 },
    { id: 2, episodeId: epByNo.get(1)!, model: "seedance-2.0", purpose: "retry", attempts: 2, accepted: 2, credits: 60 },
    { id: 3, episodeId: epByNo.get(2)!, model: "seedance-2.0", purpose: "base", attempts: 61, accepted: 46, credits: 1410 },
    { id: 4, episodeId: epByNo.get(3)!, model: "seedance-2.5", purpose: "base", attempts: 68, accepted: 44, credits: 1720 },
    { id: 5, episodeId: epByNo.get(4)!, model: "seedance-2.0", purpose: "base", attempts: 52, accepted: 40, credits: 1100 },
  ];

  for (const r of runSeed) {
    await prisma.generationRun.upsert({
      where: { id: r.id },
      update: r,
      create: r,
    });
  }

  // 9. Seed Missions
  const missionSeed = [
    { id: 1, episodeId: epByNo.get(1)!, type: "expression", body: "성수동 카페에서 실제로 쓰는 테이크아웃 표현 추천", votes: 48, status: "ADOPTED" },
    { id: 2, episodeId: epByNo.get(2)!, type: "expression", body: "편집숍에서 사이즈 교환 요청할 때 자연스러운 한마디", votes: 31, status: "COLLECTING" },
    { id: 3, episodeId: epByNo.get(3)!, type: "fandom_name", body: "K-soulmate 공식 팬덤명 1차 아이디어 응모", votes: 92, status: "COLLECTING" },
  ];

  for (const ms of missionSeed) {
    await prisma.mission.upsert({
      where: { id: ms.id },
      update: ms,
      create: ms,
    });
  }

  const [memberCount, episodeCount, channelCount] = await Promise.all([
    prisma.member.count(),
    prisma.episode.count(),
    prisma.channel.count(),
  ]);

  console.log(`Seed complete: Members ${memberCount} · Episodes ${episodeCount} · Channels ${channelCount}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
