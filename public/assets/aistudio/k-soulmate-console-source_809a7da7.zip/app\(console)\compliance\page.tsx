import db from "@/lib/db";
import { Badge } from "@/components/ui/badge";
import { ComplianceMatrix } from "@/components/compliance-matrix";
import { ShieldAlert, CheckCircle2 } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function CompliancePage() {
  const [items, episodes, checks] = await Promise.all([
    db.complianceItem.findMany({ orderBy: { code: "asc" } }),
    db.episode.findMany({ orderBy: { no: "asc" } }),
    db.complianceCheck.findMany(),
  ]);

  if (items.length === 0 || episodes.length === 0) {
    return (
      <div className="rounded-[8px] border border-zinc-200 bg-white p-6 text-xs text-zinc-600">
        아직 데이터가 없습니다. <code>npm run db:seed</code>를 실행하세요.
      </div>
    );
  }

  const beforePublishCodes = new Set(
    items.filter((i) => i.blockAt === "BEFORE_PUBLISH").map((i) => i.code)
  );

  // 약기법 위험 회차(3·6·7화) 중 BEFORE_PUBLISH 미완료 회차 + 전체 발행 차단 회차 계산
  const riskBlockedEpisodes = episodes.filter((ep) => {
    if (!ep.complianceRisk) return false;
    const epChecks = checks.filter(
      (c) => c.episodeId === ep.id && beforePublishCodes.has(c.itemCode)
    );
    return epChecks.some((c) => !c.done);
  });

  const allBlockedEpisodes = episodes.filter((ep) => {
    if (ep.status === "PUBLISHED") return false;
    const epChecks = checks.filter(
      (c) =>
        c.episodeId === ep.id &&
        beforePublishCodes.has(c.itemCode) &&
        (c.itemCode !== "JP-04" || ep.complianceRisk)
    );
    return epChecks.some((c) => !c.done);
  });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
        <div>
          <h1 className="text-base font-bold text-zinc-900">
            컴플라이언스 게이트 (일본 시장 7항목 × 12화)
          </h1>
          <p className="text-xs text-zinc-500">
            특정상거래법·경품표시법·개인정보보호법·약기법(JP-01~04) 미완료 시 해당 회차의 발행이 차단됩니다.
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          <Badge variant="amber">3·6·7화 약기법 필수</Badge>
          <Badge variant="red">발행 전 차단 4항목</Badge>
        </div>
      </div>

      {/* 상단 요약 배너 (SPEC 4.7: "발행 차단 중인 회차: 3화, 6화...") */}
      {riskBlockedEpisodes.length > 0 ? (
        <div
          role="alert"
          data-testid="compliance-blocked-summary"
          className="flex flex-wrap items-center justify-between gap-2 rounded-[6px] border border-red-300 bg-red-50 px-4 py-3 text-xs text-red-900"
        >
          <div className="flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 shrink-0 text-red-600" />
            <span className="font-bold">
              발행 차단 중인 회차 (약기법 필수 대상):{" "}
              {riskBlockedEpisodes.map((e) => `${e.no}화`).join(", ")}
            </span>
          </div>
          <span className="text-[11px] text-red-700">
            전체 미완료 검수 회차:{" "}
            {allBlockedEpisodes.map((e) => `${e.no}화`).join(", ")}
          </span>
        </div>
      ) : (
        <div className="flex items-center gap-2 rounded-[6px] border border-emerald-300 bg-emerald-50 px-4 py-3 text-xs font-semibold text-emerald-900">
          <CheckCircle2 className="h-4 w-4 text-emerald-700" />
          <span>3·6·7화 약기법 필수 회차의 발행 전 검수가 모두 완료되었습니다.</span>
        </div>
      )}

      <ComplianceMatrix items={items} episodes={episodes} checks={checks} />
    </div>
  );
}
