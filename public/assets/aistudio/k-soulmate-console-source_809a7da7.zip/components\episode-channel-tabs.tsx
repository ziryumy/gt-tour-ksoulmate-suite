"use client";

import React, { useState } from "react";
import type { Channel, ChannelVersion, Member } from "@prisma/client";
import { Badge, VersionStatusBadge } from "@/components/ui/badge";
import { ChannelVersionEditor } from "@/components/channel-version-editor";
import { cn } from "@/lib/utils";

interface ChannelWithVersion {
  channel: Channel;
  version: ChannelVersion | null;
  narrator: Member | null;
}

interface EpisodeChannelTabsProps {
  episode: {
    id: number;
    no: number;
    title: string;
    place: string;
    baseVideoUrl: string | null;
    expressions: string[];
    complianceRisk: boolean;
  };
  episodeMember: Member | null;
  items: ChannelWithVersion[];
  publishGate: {
    canPublish: boolean;
    incompleteChannels: string[];
    incompleteChecks: string[];
    reason: string | null;
  };
  initialChannelCode?: string;
}

export function EpisodeChannelTabs({
  episode,
  episodeMember,
  items,
  publishGate,
  initialChannelCode,
}: EpisodeChannelTabsProps) {
  const defaultCode =
    initialChannelCode &&
    items.some((i) => i.channel.code === initialChannelCode && i.channel.active)
      ? initialChannelCode
      : "JP";

  const [selectedCode, setSelectedCode] = useState<string>(defaultCode);

  const currentItem =
    items.find((i) => i.channel.code === selectedCode) ?? items[0];

  return (
    <section className="rounded-[8px] border border-zinc-200 bg-white">
      {/* 4개 채널 탭 (JP / US / KR / CN) */}
      <div
        role="tablist"
        aria-label="채널 버전 탭"
        className="flex flex-wrap border-b border-zinc-200 bg-zinc-50 px-2 pt-2 gap-1"
      >
        {items.map(({ channel, version }) => {
          const isDisabled = !channel.active || channel.code === "CN";
          const isSelected = selectedCode === channel.code && !isDisabled;

          return (
            <button
              key={channel.code}
              type="button"
              role="tab"
              aria-selected={isSelected}
              disabled={isDisabled}
              onClick={() => {
                if (!isDisabled) setSelectedCode(channel.code);
              }}
              className={cn(
                "inline-flex items-center gap-2 rounded-t-[4px] border-x border-t px-3.5 py-2 text-xs font-semibold transition-colors",
                isDisabled
                  ? "cursor-not-allowed border-transparent bg-zinc-100 text-zinc-400"
                  : isSelected
                  ? "-mb-px border-zinc-200 bg-white text-[#1F5E63]"
                  : "border-transparent bg-transparent text-zinc-600 hover:bg-zinc-100 hover:text-zinc-900"
              )}
            >
              <span className="font-mono font-bold">{channel.code}</span>
              <span className="hidden sm:inline text-[11px] font-normal">
                {channel.label}
              </span>
              {isDisabled ? (
                <Badge variant="muted">Phase 2</Badge>
              ) : (
                version && <VersionStatusBadge status={version.status} />
              )}
            </button>
          );
        })}
      </div>

      {/* 선택된 채널 버전 편집기 (SPEC 4.4.4 -> 4.5) */}
      {currentItem && (
        <div className="p-4">
          <ChannelVersionEditor
            episode={episode}
            channel={currentItem.channel}
            version={currentItem.version}
            narrator={currentItem.narrator}
            episodeMember={episodeMember}
            publishGate={publishGate}
            showDedicatedLink
          />
        </div>
      )}
    </section>
  );
}
