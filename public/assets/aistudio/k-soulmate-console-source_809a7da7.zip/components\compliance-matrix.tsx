"use client";

import React, { useTransition } from "react";
import type { ComplianceItem, ComplianceCheck, Episode } from "@prisma/client";
import { Badge } from "@/components/ui/badge";
import { toggleComplianceCheckAction } from "@/app/actions";
import { cn } from "@/lib/utils";

interface ComplianceMatrixProps {
  items: ComplianceItem[];
  episodes: Episode[];
  checks: ComplianceCheck[];
}

export function ComplianceMatrix({
  items,
  episodes,
  checks,
}: ComplianceMatrixProps) {
  const [isPending, startTransition] = useTransition();

  const checkMap = new Map<string, ComplianceCheck>();
  for (const c of checks) {
    checkMap.set(`${c.episodeId}:${c.itemCode}`, c);
  }

  const handleToggle = (episodeId: number, itemCode: string, nextDone: boolean) => {
    startTransition(async () => {
      await toggleComplianceCheckAction({
        episodeId,
        itemCode,
        done: nextDone,
      });
    });
  };

  return (
    <div className="space-y-4">
      {/* 데스크톱 7항목 × 12화 매트릭스 */}
      <div className="hidden md:block overflow-x-auto rounded-[8px] border border-zinc-200 bg-white">
        <table className="w-full border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-zinc-200 bg-zinc-50 text-[11px] font-semibold text-zinc-600">
              <th className="px-3 py-2.5 w-64">법규 항목 (7종)</th>
              <th className="px-2 py-2.5 w-20 text-center">차단 시점</th>
              <th className="px-2 py-2.5 w-16 text-center">담당</th>
              {episodes.map((ep) => (
                <th
                  key={ep.id}
                  className={cn(
                    "px-1.5 py-2.5 text-center font-mono",
                    ep.complianceRisk
                      ? "bg-amber-100/70 text-amber-900 font-bold"
                      : "text-zinc-700"
                  )}
                >
                  <div>{ep.no}화</div>
                  {ep.complianceRisk && (
                    <div className="text-[9px] font-sans text-amber-800">
                      약기법
                    </div>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-200">
            {items.map((item) => {
              const isYakgiRow = item.code === "JP-04";
              const sampleCheck = checks.find((c) => c.itemCode === item.code);
              const ownerLabel =
                sampleCheck?.owner && sampleCheck.owner.trim() !== ""
                  ? sampleCheck.owner
                  : "미지정";

              return (
                <tr key={item.code} className="hover:bg-zinc-50/70">
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono text-[11px] font-bold text-[#1F5E63]">
                        {item.code}
                      </span>
                      <span className="font-semibold text-zinc-900">
                        {item.label}
                      </span>
                      {isYakgiRow && <Badge variant="amber">3·6·7화 필수</Badge>}
                    </div>
                    <p className="mt-0.5 text-[11px] text-zinc-500 line-clamp-2">
                      {item.detail}
                    </p>
                  </td>
                  <td className="px-2 py-2.5 text-center">
                    <Badge
                      variant={
                        item.blockAt === "BEFORE_PUBLISH" ? "red" : "default"
                      }
                    >
                      {item.blockAt === "BEFORE_PUBLISH" ? "발행 전" : "런칭 시"}
                    </Badge>
                  </td>
                  <td className="px-2 py-2.5 text-center text-[11px] text-zinc-600">
                    {ownerLabel}
                  </td>
                  {episodes.map((ep) => {
                    const chk = checkMap.get(`${ep.id}:${item.code}`);
                    const done = chk?.done ?? false;
                    // 3·6·7화는 약기법 항목이 필수이며 회색 처리 불가
                    const isYakgiMandatoryCell =
                      isYakgiRow && ep.complianceRisk;
                    // 일반 회차의 약기법 셀은 비대상(회색) 표시
                    const isYakgiGreyedCell =
                      isYakgiRow && !ep.complianceRisk;

                    return (
                      <td
                        key={ep.id}
                        className={cn(
                          "px-1.5 py-2.5 text-center align-middle",
                          isYakgiMandatoryCell
                            ? done
                              ? "bg-emerald-50/70"
                              : "bg-amber-100/80"
                            : isYakgiGreyedCell
                            ? "bg-zinc-100 text-zinc-300"
                            : ""
                        )}
                      >
                        {isYakgiGreyedCell ? (
                          <span
                            title="약기법 비대상 회차"
                            className="font-mono text-[10px] text-zinc-400"
                          >
                            -
                          </span>
                        ) : (
                          <div className="flex flex-col items-center justify-center gap-0.5">
                            <input
                              type="checkbox"
                              aria-label={`제${ep.no}화 ${item.code} ${item.label} 검수`}
                              checked={done}
                              disabled={isPending}
                              onChange={(e) =>
                                handleToggle(ep.id, item.code, e.target.checked)
                              }
                              className="h-4 w-4 cursor-pointer rounded-[2px] border-zinc-300 accent-[#1F5E63]"
                            />
                            {isYakgiMandatoryCell && (
                              <span
                                className={cn(
                                  "text-[9px] font-bold",
                                  done ? "text-[#1F5E63]" : "text-red-700"
                                )}
                              >
                                필수
                              </span>
                            )}
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* 모바일 카드 뷰 (375px 폭 대응) */}
      <div className="md:hidden space-y-3">
        {items.map((item) => {
          const isYakgiRow = item.code === "JP-04";
          const sampleCheck = checks.find((c) => c.itemCode === item.code);
          const ownerLabel =
            sampleCheck?.owner && sampleCheck.owner.trim() !== ""
              ? sampleCheck.owner
              : "미지정";

          return (
            <div
              key={item.code}
              className="rounded-[8px] border border-zinc-200 bg-white p-3.5 space-y-2.5"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono text-xs font-bold text-[#1F5E63]">
                      {item.code}
                    </span>
                    <span className="text-xs font-bold text-zinc-900">
                      {item.label}
                    </span>
                  </div>
                  <p className="mt-0.5 text-[11px] text-zinc-500">
                    {item.detail}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1 shrink-0">
                  <Badge
                    variant={
                      item.blockAt === "BEFORE_PUBLISH" ? "red" : "default"
                    }
                  >
                    {item.blockAt === "BEFORE_PUBLISH" ? "발행 전 필수" : "런칭 시"}
                  </Badge>
                  <span className="text-[10px] text-zinc-500">
                    담당: {ownerLabel}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {episodes.map((ep) => {
                  const chk = checkMap.get(`${ep.id}:${item.code}`);
                  const done = chk?.done ?? false;
                  const isYakgiMandatoryCell =
                    isYakgiRow && ep.complianceRisk;
                  const isYakgiGreyedCell = isYakgiRow && !ep.complianceRisk;

                  if (isYakgiGreyedCell) {
                    return (
                      <div
                        key={ep.id}
                        className="flex items-center justify-between rounded-[4px] border border-zinc-100 bg-zinc-50 px-2 py-1 text-[11px] text-zinc-400"
                      >
                        <span className="font-mono">{ep.no}화</span>
                        <span>-</span>
                      </div>
                    );
                  }

                  return (
                    <label
                      key={ep.id}
                      className={cn(
                        "flex cursor-pointer items-center justify-between rounded-[4px] border px-2 py-1 text-[11px]",
                        isYakgiMandatoryCell
                          ? done
                            ? "border-emerald-300 bg-emerald-50 font-semibold"
                            : "border-amber-400 bg-amber-50 font-bold text-amber-900"
                          : "border-zinc-200 bg-white"
                      )}
                    >
                      <span className="font-mono">{ep.no}화</span>
                      <input
                        type="checkbox"
                        checked={done}
                        disabled={isPending}
                        onChange={(e) =>
                          handleToggle(ep.id, item.code, e.target.checked)
                        }
                        className="h-3.5 w-3.5 accent-[#1F5E63]"
                      />
                    </label>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
