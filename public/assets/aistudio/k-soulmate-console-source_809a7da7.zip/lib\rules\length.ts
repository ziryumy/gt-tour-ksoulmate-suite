export interface LengthValidationInput {
  cutCount: number | null | undefined;
  totalSec: number | null | undefined;
  targetCutCount: number;
  targetTotalSec: number;
  targetAvgCutSec: number;
}

export interface LengthValidationResult {
  avgCutSec: number | null;
  avgCutDiff: number | null;
  totalSecDiff: number | null;
  isAvgCutWarning: boolean;
  isTotalSecWarning: boolean;
  hasWarning: boolean;
  warnings: string[];
}

/**
 * SPEC 5.1 길이 검증 규칙
 * avgCut = totalSec / cutCount
 * if (|avgCut - channel.avgCutSec| > 0.3) -> warning
 * if (totalSec !== channel.totalSec ± 3) -> warning
 * 경고는 저장을 막지 않음. 발행만 막음.
 */
export function validateChannelLength(
  input: LengthValidationInput
): LengthValidationResult {
  const { cutCount, totalSec, targetTotalSec, targetAvgCutSec } = input;
  const warnings: string[] = [];

  if (
    cutCount === null ||
    cutCount === undefined ||
    totalSec === null ||
    totalSec === undefined ||
    cutCount <= 0 ||
    totalSec <= 0
  ) {
    return {
      avgCutSec: null,
      avgCutDiff: null,
      totalSecDiff: null,
      isAvgCutWarning: true,
      isTotalSecWarning: true,
      hasWarning: true,
      warnings: ["컷 수와 총 길이(초)를 1 이상의 값으로 입력해 주세요."],
    };
  }

  const rawAvg = totalSec / cutCount;
  const avgCutSec = Number(rawAvg.toFixed(2));
  const avgCutDiff = Number(Math.abs(rawAvg - targetAvgCutSec).toFixed(2));
  const totalSecDiff = Math.abs(totalSec - targetTotalSec);

  // 부동소수점 오차 방지를 위해 0.3001 기준 비교
  const isAvgCutWarning = Math.abs(rawAvg - targetAvgCutSec) > 0.3001;
  const isTotalSecWarning = totalSecDiff > 3;

  if (isAvgCutWarning) {
    warnings.push(
      `평균 컷 길이(${avgCutSec}초)가 채널 규격(${targetAvgCutSec}초 ±0.3초)을 벗어났습니다.`
    );
  }

  if (isTotalSecWarning) {
    warnings.push(
      `총 길이(${totalSec}초)가 채널 규격(${targetTotalSec}초 ±3초)을 벗어났습니다.`
    );
  }

  return {
    avgCutSec,
    avgCutDiff,
    totalSecDiff,
    isAvgCutWarning,
    isTotalSecWarning,
    hasWarning: isAvgCutWarning || isTotalSecWarning,
    warnings,
  };
}
