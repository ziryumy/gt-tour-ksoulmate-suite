import Link from "next/link";
import { notFound } from "next/navigation";
import db from "@/lib/db";
import { Badge, EpisodeStatusBadge, VersionStatusBadge } from "@/components/ui/badge";
import { ChannelVersionEditor } from "@/components/channel-version-editor";
import { canPublish } from "@/lib/rules/compliance";
import { toStringArray } from "@/lib/types";
import { ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

const CHANNEL_ORDER = ["JP", "US", "KR", "CN"];

export default async function EpisodeChannelEditPage({
  params,
}: {
  params: Promise<{ no: string; code: string }>;
}) {
  const { no, code } = await params;
  const episodeNo = Number(no);
  const channelCode = code.toUpperCase();

  if (!Number.isInteger(episodeNo) || episodeNo < 1) {
    notFound();
  }

  const [episode, channels, members] = await Promise.all([
    db.episode.findUnique({
      where: { no: episodeNo },
      include: {
        member: true,
        versions: {
          include: { channel: true },
        },
      },
    }),
    db.channel.findMany(),
    db.member.findMany(),
  ]);

  if (!episode) {
    notFound();
  }

  const targetChannel = channels.find((c) => c.code === channelCode);
  if (!targetChannel) {
    notFound();
  }

  const checks = await db.complianceCheck.findMany({
    where: { episodeId: episode.id },
    include: { item: true },
  });

  const publishGate = canPublish({
    no: episode.no,
    complianceRisk: episode.complianceRisk,
    versions: episode.versions,
    checks,
  });

  const version =
    episode.versions.find((v) => v.channelCode === targetChannel.code) ?? null;
  const narrator =
    members.find((m) => m.id === targetChannel.narratorId) ?? null;

  const orderedChannels = CHANNEL_ORDER.map((c) =>
    channels.find((ch) => ch.code === c)
  ).filter((c): c is NonNullable<typeof c> => Boolean(c));

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Link
          href={`/episodes/${episode.no}`}
          className="inline-flex items-center gap-1 text-xs font-medium text-zinc-500 hover:text-[#1F5E63]"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          제{episode.no}화 상세로 돌아가기
        </Link>
        <div className="flex items-center gap-2">
          <EpisodeStatusBadge status={episode.status} />
          {episode.complianceRisk && <Badge variant="amber">약기법</Badge>}
        </div>
      </div>

      {/* 헤더 및 채널 전환 탭 */}
      <div className="rounded-[8px] border border-zinc-200 bg-white">
        <div className="border-b border-zinc-200 px-4 py-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-[2px] bg-[#1F5E63] px-2 py-0.5 font-mono text-xs font-bold text-white">
              제{episode.no}화 · {targetChannel.code}
            </span>
            <h1 className="text-base font-bold text-zinc-900">
              {episode.title} — {targetChannel.label} 버전 편집
            </h1>
          </div>
        </div>

        {/* 4채널 탭 바 */}
        <div className="flex flex-wrap gap-1 border-b border-zinc-200 bg-zinc-50 px-2 pt-2">
          {orderedChannels.map((ch) => {
            const ver = episode.versions.find((v) => v.channelCode === ch.code);
            const isDisabled = !ch.active || ch.code === "CN";
            const isCurrent = ch.code === targetChannel.code;

            if (isDisabled) {
              return (
                <span
                  key={ch.code}
                  className="inline-flex cursor-not-allowed items-center gap-2 rounded-t-[4px] px-3.5 py-2 text-xs font-semibold text-zinc-400"
                >
                  <span className="font-mono font-bold">{ch.code}</span>
                  <Badge variant="muted">Phase 2</Badge>
                </span>
              );
            }

            return (
              <Link
                key={ch.code}
                href={`/episodes/${episode.no}/channels/${ch.code}`}
                className={cn(
                  "inline-flex items-center gap-2 rounded-t-[4px] border-x border-t px-3.5 py-2 text-xs font-semibold transition-colors",
                  isCurrent
                    ? "-mb-px border-zinc-200 bg-white text-[#1F5E63]"
                    : "border-transparent text-zinc-600 hover:bg-zinc-100"
                )}
              >
                <span className="font-mono font-bold">{ch.code}</span>
                <span className="hidden sm:inline text-[11px] font-normal">
                  {ch.label}
                </span>
                {ver && <VersionStatusBadge status={ver.status} />}
              </Link>
            );
          })}
        </div>

        <div className="p-4">
          {!targetChannel.active ? (
            <div className="rounded-[6px] border border-dashed border-zinc-300 bg-zinc-50 p-6 text-center text-xs text-zinc-600">
              CN 채널은 Phase 2(2분기, 중국 파트너 경유 개설) 대상이므로 현재 비활성 상태입니다.
            </div>
          ) : (
            <ChannelVersionEditor
              episode={{
                id: episode.id,
                no: episode.no,
                title: episode.title,
                place: episode.place,
                baseVideoUrl: episode.baseVideoUrl,
                expressions: toStringArray(episode.expressions),
                complianceRisk: episode.complianceRisk,
              }}
              channel={targetChannel}
              version={version}
              narrator={narrator}
              episodeMember={episode.member}
              publishGate={publishGate}
            />
          )}
        </div>
      </div>
    </div>
  );
}
