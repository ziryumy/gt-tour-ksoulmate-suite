"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import db from "@/lib/db";
import { canPublish } from "@/lib/rules/compliance";
import { validateChannelLength } from "@/lib/rules/length";
import { canShortlist } from "@/lib/rules/fandom";
import type { EpisodeStatus, VersionStatus } from "@prisma/client";

export interface ActionResponse {
  ok: boolean;
  message?: string;
  error?: string;
}

const EpisodeStatusSchema = z.object({
  episodeNo: z.number().int().min(1).max(12),
  targetStatus: z.enum([
    "PLANNING",
    "SCRIPTED",
    "GENERATED",
    "EDITED",
    "REVIEWED",
    "PUBLISHED",
  ]),
});

export async function transitionEpisodeStatusAction(
  input: z.infer<typeof EpisodeStatusSchema>
): Promise<ActionResponse> {
  const parsed = EpisodeStatusSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: "유효하지 않은 에피소드 상태 변경 요청입니다." };
  }

  const { episodeNo, targetStatus } = parsed.data;

  try {
    const episode = await db.episode.findUnique({
      where: { no: episodeNo },
      include: {
        versions: {
          include: { channel: true },
        },
      },
    });

    if (!episode) {
      return { ok: false, error: "해당 에피소드를 찾을 수 없습니다." };
    }

    if (targetStatus === "PUBLISHED") {
      const checks = await db.complianceCheck.findMany({
        where: { episodeId: episode.id },
        include: { item: true },
      });

      const gate = canPublish({
        no: episode.no,
        complianceRisk: episode.complianceRisk,
        versions: episode.versions,
        checks,
      });

      if (!gate.canPublish) {
        return {
          ok: false,
          error:
            gate.reason ??
            "발행 조건(활성 3채널 완료 및 필수 컴플라이언스 검수)을 충족하지 못했습니다.",
        };
      }
    }

    await db.episode.update({
      where: { id: episode.id },
      data: { status: targetStatus as EpisodeStatus },
    });

    revalidatePath("/dashboard");
    revalidatePath("/episodes");
    revalidatePath(`/episodes/${episodeNo}`);
    revalidatePath("/compliance");

    return {
      ok: true,
      message: `제${episodeNo}화 상태를 변경했습니다.`,
    };
  } catch {
    return {
      ok: false,
      error: "상태를 변경하지 못했습니다. 다시 시도해 주세요.",
    };
  }
}

const SaveChannelVersionSchema = z.object({
  episodeNo: z.number().int().min(1).max(12),
  channelCode: z.enum(["JP", "US", "KR", "CN"]),
  narration: z.string(),
  voStatus: z.enum(["TODO", "IN_PROGRESS", "DONE", "BLOCKED"]),
  bgmTrackId: z.string().nullable(),
  cutCount: z.number().int().min(1).max(500).nullable(),
  totalSec: z.number().int().min(1).max(1200).nullable(),
  status: z.enum(["TODO", "IN_PROGRESS", "DONE", "BLOCKED"]),
  publishedUrl: z.string().nullable(),
});

export async function saveChannelVersionAction(
  input: z.infer<typeof SaveChannelVersionSchema>
): Promise<ActionResponse> {
  const parsed = SaveChannelVersionSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      error: "저장하지 못했습니다. 입력값을 확인해 주세요.",
    };
  }

  const data = parsed.data;

  try {
    const episode = await db.episode.findUnique({
      where: { no: data.episodeNo },
    });
    if (!episode) {
      return { ok: false, error: "에피소드를 찾을 수 없습니다." };
    }

    // 주의: 길이 경고는 저장을 막지 않음 (SPEC 5.1)
    await db.channelVersion.upsert({
      where: {
        episodeId_channelCode: {
          episodeId: episode.id,
          channelCode: data.channelCode,
        },
      },
      update: {
        narration: data.narration,
        voStatus: data.voStatus as VersionStatus,
        bgmTrackId: data.bgmTrackId,
        cutCount: data.cutCount,
        totalSec: data.totalSec,
        status: data.status as VersionStatus,
        publishedUrl: data.publishedUrl || null,
      },
      create: {
        episodeId: episode.id,
        channelCode: data.channelCode,
        narration: data.narration,
        voStatus: data.voStatus as VersionStatus,
        bgmTrackId: data.bgmTrackId,
        cutCount: data.cutCount,
        totalSec: data.totalSec,
        status: data.status as VersionStatus,
        publishedUrl: data.publishedUrl || null,
      },
    });

    revalidatePath("/dashboard");
    revalidatePath("/episodes");
    revalidatePath(`/episodes/${data.episodeNo}`);
    revalidatePath(`/episodes/${data.episodeNo}/channels/${data.channelCode}`);

    return { ok: true, message: "저장했습니다" };
  } catch {
    return {
      ok: false,
      error: "저장하지 못했습니다. 다시 시도해 주세요.",
    };
  }
}

const PublishEpisodeFromChannelSchema = z.object({
  episodeNo: z.number().int().min(1).max(12),
  channelCode: z.enum(["JP", "US", "KR", "CN"]),
  publishedUrl: z.string().trim().min(1, "발행 URL을 입력해 주세요."),
  cutCount: z.number().int().min(1),
  totalSec: z.number().int().min(1),
});

export async function publishChannelAndEpisodeAction(
  input: z.infer<typeof PublishEpisodeFromChannelSchema>
): Promise<ActionResponse> {
  const parsed = PublishEpisodeFromChannelSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      error: parsed.error.issues[0]?.message ?? "발행 입력값이 올바르지 않습니다.",
    };
  }

  const { episodeNo, channelCode, publishedUrl, cutCount, totalSec } =
    parsed.data;

  try {
    const [episode, channel] = await Promise.all([
      db.episode.findUnique({
        where: { no: episodeNo },
        include: {
          versions: { include: { channel: true } },
        },
      }),
      db.channel.findUnique({
        where: { code: channelCode },
      }),
    ]);

    if (!episode || !channel) {
      return { ok: false, error: "에피소드 또는 채널 정보를 찾을 수 없습니다." };
    }

    // 1. 길이 규격 검증 (경고 시 저장은 허용하되 발행은 차단)
    const lengthCheck = validateChannelLength({
      cutCount,
      totalSec,
      targetCutCount: channel.cutCount,
      targetTotalSec: channel.totalSec,
      targetAvgCutSec: channel.avgCutSec,
    });

    if (lengthCheck.hasWarning) {
      return {
        ok: false,
        error: `발행할 수 없습니다. ${lengthCheck.warnings.join(" ")}`,
      };
    }

    // 2. 발행 게이트(3채널 완료 + 컴플라이언스 BEFORE_PUBLISH) 검증
    const checks = await db.complianceCheck.findMany({
      where: { episodeId: episode.id },
      include: { item: true },
    });

    const gate = canPublish({
      no: episode.no,
      complianceRisk: episode.complianceRisk,
      versions: episode.versions,
      checks,
    });

    if (!gate.canPublish) {
      return {
        ok: false,
        error: gate.reason ?? "발행 게이트 조건을 만족하지 못했습니다.",
      };
    }

    await db.$transaction([
      db.channelVersion.update({
        where: {
          episodeId_channelCode: {
            episodeId: episode.id,
            channelCode,
          },
        },
        data: {
          publishedUrl,
          publishedAt: new Date(),
          status: "DONE",
        },
      }),
      db.episode.update({
        where: { id: episode.id },
        data: { status: "PUBLISHED" },
      }),
    ]);

    revalidatePath("/dashboard");
    revalidatePath("/episodes");
    revalidatePath(`/episodes/${episodeNo}`);
    revalidatePath(`/episodes/${episodeNo}/channels/${channelCode}`);

    return {
      ok: true,
      message: `제${episodeNo}화 ${channelCode} 채널 발행 및 에피소드 발행을 완료했습니다.`,
    };
  } catch {
    return {
      ok: false,
      error: "발행 처리 중 오류가 발생했습니다. 다시 시도해 주세요.",
    };
  }
}

const UpdateCreditUsedSchema = z.object({
  month: z.string().min(4),
  creditUsed: z.number().int().min(0).max(1000000),
});

export async function updateBudgetCreditUsedAction(
  input: z.infer<typeof UpdateCreditUsedSchema>
): Promise<ActionResponse> {
  const parsed = UpdateCreditUsedSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: "올바른 크레딧 숫자를 입력해 주세요." };
  }

  try {
    await db.budgetMonth.update({
      where: { month: parsed.data.month },
      data: { creditUsed: parsed.data.creditUsed },
    });

    revalidatePath("/dashboard");
    revalidatePath("/credits");

    return { ok: true, message: "이번 달 크레딧 사용량을 반영했습니다." };
  } catch {
    return {
      ok: false,
      error: "크레딧 사용량을 저장하지 못했습니다.",
    };
  }
}

const RecordGenerationRunSchema = z.object({
  episodeNo: z.number().int().min(1).max(12),
  model: z.enum(["seedance-2.0", "seedance-2.5", "fast"]),
  purpose: z.enum(["base", "collection", "retry"]),
  attempts: z.number().int().min(1).max(500),
  accepted: z.number().int().min(0).max(500),
  credits: z.number().int().min(1).max(100000),
});

export async function recordGenerationRunAction(
  input: z.infer<typeof RecordGenerationRunSchema>
): Promise<ActionResponse> {
  const parsed = RecordGenerationRunSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: "생성 기록 입력값을 확인해 주세요." };
  }

  const data = parsed.data;
  if (data.accepted > data.attempts) {
    return {
      ok: false,
      error: "채택된 컷 수는 시도 횟수를 초과할 수 없습니다.",
    };
  }

  try {
    const episode = await db.episode.findUnique({
      where: { no: data.episodeNo },
    });
    if (!episode) {
      return { ok: false, error: "해당 회차를 찾을 수 없습니다." };
    }

    const latestBudget = await db.budgetMonth.findFirst({
      orderBy: { month: "desc" },
    });

    // 트랜잭션: 생성 로그 추가 + 월 누적 사용 크레딧 차감(가산) 연동
    await db.$transaction(async (tx) => {
      await tx.generationRun.create({
        data: {
          episodeId: episode.id,
          model: data.model,
          purpose: data.purpose,
          attempts: data.attempts,
          accepted: data.accepted,
          credits: data.credits,
        },
      });

      if (latestBudget) {
        await tx.budgetMonth.update({
          where: { month: latestBudget.month },
          data: {
            creditUsed: latestBudget.creditUsed + data.credits,
          },
        });
      }
    });

    revalidatePath("/dashboard");
    revalidatePath("/credits");
    revalidatePath(`/episodes/${data.episodeNo}`);

    return {
      ok: true,
      message: `제${data.episodeNo}화 생성 기록(${data.credits.toLocaleString()} 크레딧)을 저장하고 월 사용량에 반영했습니다.`,
    };
  } catch {
    return {
      ok: false,
      error: "생성 기록을 저장하지 못했습니다.",
    };
  }
}

const ToggleComplianceCheckSchema = z.object({
  episodeId: z.number().int().positive(),
  itemCode: z.string().min(2),
  done: z.boolean(),
  owner: z.string().optional(),
  note: z.string().optional(),
});

export async function toggleComplianceCheckAction(
  input: z.infer<typeof ToggleComplianceCheckSchema>
): Promise<ActionResponse> {
  const parsed = ToggleComplianceCheckSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: "잘못된 컴플라이언스 변경 요청입니다." };
  }

  const { episodeId, itemCode, done, owner, note } = parsed.data;

  try {
    await db.complianceCheck.upsert({
      where: {
        episodeId_itemCode: {
          episodeId,
          itemCode,
        },
      },
      update: {
        done,
        ...(owner !== undefined ? { owner } : {}),
        ...(note !== undefined ? { note } : {}),
      },
      create: {
        episodeId,
        itemCode,
        done,
        owner: owner ?? "",
        note: note ?? null,
      },
    });

    revalidatePath("/dashboard");
    revalidatePath("/compliance");
    revalidatePath("/episodes");

    return { ok: true, message: "컴플라이언스 검수 상태를 저장했습니다." };
  } catch {
    return {
      ok: false,
      error: "검수 상태를 저장하지 못했습니다.",
    };
  }
}

const UpdateGaugeSchema = z.object({
  id: z.number().int().positive(),
  current: z.number().int().min(0).max(100),
});

export async function updateGaugeAction(
  input: z.infer<typeof UpdateGaugeSchema>
): Promise<ActionResponse> {
  const parsed = UpdateGaugeSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: "유효하지 않은 게이지 수치입니다." };
  }

  try {
    const gauge = await db.gauge.findUnique({ where: { id: parsed.data.id } });
    if (!gauge) {
      return { ok: false, error: "게이지 항목을 찾을 수 없습니다." };
    }

    const unlocked = parsed.data.current >= gauge.threshold;

    await db.gauge.update({
      where: { id: gauge.id },
      data: {
        current: parsed.data.current,
        unlocked,
      },
    });

    revalidatePath("/engagement");

    return {
      ok: true,
      message: unlocked
        ? `응원 게이지 ${parsed.data.current}% 달성 — "${gauge.label}" 해금됨!`
        : `응원 게이지를 ${parsed.data.current}%로 업데이트했습니다.`,
    };
  } catch {
    return { ok: false, error: "게이지 업데이트에 실패했습니다." };
  }
}

const ToggleFandomCheckSchema = z.object({
  id: z.number().int().positive(),
  field: z.enum(["checkTm", "checkDup", "checkWord", "checkPron", "checkChant"]),
  value: z.boolean(),
});

export async function toggleFandomCheckAction(
  input: z.infer<typeof ToggleFandomCheckSchema>
): Promise<ActionResponse> {
  const parsed = ToggleFandomCheckSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: "잘못된 팬덤명 검증 항목입니다." };
  }

  try {
    const candidate = await db.fandomCandidate.findUnique({
      where: { id: parsed.data.id },
    });
    if (!candidate) {
      return { ok: false, error: "팬덤명 후보를 찾을 수 없습니다." };
    }

    const updatedChecks = {
      checkTm: candidate.checkTm,
      checkDup: candidate.checkDup,
      checkWord: candidate.checkWord,
      checkPron: candidate.checkPron,
      checkChant: candidate.checkChant,
      [parsed.data.field]: parsed.data.value,
    };

    // 만약 검사를 해제하여 5개 중 하나라도 미통과가 되면 SHORTLIST/ADOPTED에서 CANDIDATE로 강등
    const nextStatus =
      !canShortlist(updatedChecks) && candidate.status !== "CANDIDATE"
        ? "CANDIDATE"
        : candidate.status;

    await db.fandomCandidate.update({
      where: { id: candidate.id },
      data: {
        [parsed.data.field]: parsed.data.value,
        status: nextStatus,
      },
    });

    revalidatePath("/engagement");
    return { ok: true, message: "팬덤명 검증 항목을 반영했습니다." };
  } catch {
    return { ok: false, error: "팬덤명 검증 항목을 저장하지 못했습니다." };
  }
}

const UpdateFandomStatusSchema = z.object({
  id: z.number().int().positive(),
  status: z.enum(["CANDIDATE", "SHORTLIST", "ADOPTED"]),
});

export async function updateFandomStatusAction(
  input: z.infer<typeof UpdateFandomStatusSchema>
): Promise<ActionResponse> {
  const parsed = UpdateFandomStatusSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: "올바르지 않은 상태 요청입니다." };
  }

  try {
    const candidate = await db.fandomCandidate.findUnique({
      where: { id: parsed.data.id },
    });
    if (!candidate) {
      return { ok: false, error: "팬덤명 후보를 찾을 수 없습니다." };
    }

    if (
      (parsed.data.status === "SHORTLIST" || parsed.data.status === "ADOPTED") &&
      !canShortlist(candidate)
    ) {
      return {
        ok: false,
        error:
          "5개 검사(상표·중복·부적절어·발음·3음절 이내)를 전부 통과해야 SHORTLIST로 올릴 수 있습니다.",
      };
    }

    await db.fandomCandidate.update({
      where: { id: candidate.id },
      data: { status: parsed.data.status },
    });

    revalidatePath("/engagement");
    return {
      ok: true,
      message: `"${candidate.name}" 후보를 ${parsed.data.status} 상태로 변경했습니다.`,
    };
  } catch {
    return { ok: false, error: "팬덤명 상태를 변경하지 못했습니다." };
  }
}

const UpdateMissionStatusSchema = z.object({
  id: z.number().int().positive(),
  status: z.enum(["COLLECTING", "ADOPTED", "REJECTED"]),
});

export async function updateMissionStatusAction(
  input: z.infer<typeof UpdateMissionStatusSchema>
): Promise<ActionResponse> {
  const parsed = UpdateMissionStatusSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, error: "유효하지 않은 미션 상태입니다." };
  }

  try {
    await db.mission.update({
      where: { id: parsed.data.id },
      data: { status: parsed.data.status },
    });

    revalidatePath("/engagement");
    return { ok: true, message: "미션 상태를 업데이트했습니다." };
  } catch {
    return { ok: false, error: "미션 상태를 변경하지 못했습니다." };
  }
}
