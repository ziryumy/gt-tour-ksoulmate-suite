-- CreateTable
CREATE TABLE "Member" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "nameKo" TEXT NOT NULL,
    "nameJa" TEXT,
    "nameZh" TEXT,
    "nationality" TEXT NOT NULL,
    "position" TEXT NOT NULL,
    "age" INTEGER NOT NULL,
    "heightCm" INTEGER NOT NULL,
    "photoSheetUrl" TEXT NOT NULL,
    "animeSheetUrl" TEXT,
    "outfitSpec" TEXT NOT NULL,
    "faceSpec" TEXT NOT NULL,
    "voiceProfile" TEXT,
    "channelCode" TEXT,
    "locked" BOOLEAN NOT NULL DEFAULT true
);

-- CreateTable
CREATE TABLE "Channel" (
    "code" TEXT NOT NULL PRIMARY KEY,
    "label" TEXT NOT NULL,
    "narratorId" TEXT NOT NULL,
    "tone" TEXT NOT NULL,
    "totalSec" INTEGER NOT NULL,
    "cutCount" INTEGER NOT NULL,
    "avgCutSec" REAL NOT NULL,
    "rhythmBasis" TEXT NOT NULL,
    "workflowOrder" JSONB NOT NULL,
    "bgmTracks" JSONB NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true
);

-- CreateTable
CREATE TABLE "Episode" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "no" INTEGER NOT NULL,
    "title" TEXT NOT NULL,
    "place" TEXT NOT NULL,
    "memberId" TEXT,
    "expressions" JSONB NOT NULL,
    "baseVideoUrl" TEXT,
    "status" TEXT NOT NULL DEFAULT 'PLANNING',
    "complianceRisk" BOOLEAN NOT NULL DEFAULT false,
    CONSTRAINT "Episode_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "ChannelVersion" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "episodeId" INTEGER NOT NULL,
    "channelCode" TEXT NOT NULL,
    "narration" TEXT NOT NULL DEFAULT '',
    "voStatus" TEXT NOT NULL DEFAULT 'TODO',
    "bgmTrackId" TEXT,
    "cutCount" INTEGER,
    "totalSec" INTEGER,
    "status" TEXT NOT NULL DEFAULT 'TODO',
    "publishedUrl" TEXT,
    "publishedAt" DATETIME,
    CONSTRAINT "ChannelVersion_episodeId_fkey" FOREIGN KEY ("episodeId") REFERENCES "Episode" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "ChannelVersion_channelCode_fkey" FOREIGN KEY ("channelCode") REFERENCES "Channel" ("code") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "GenerationRun" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "episodeId" INTEGER NOT NULL,
    "model" TEXT NOT NULL,
    "purpose" TEXT NOT NULL,
    "attempts" INTEGER NOT NULL DEFAULT 1,
    "accepted" INTEGER NOT NULL DEFAULT 0,
    "credits" INTEGER NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "GenerationRun_episodeId_fkey" FOREIGN KEY ("episodeId") REFERENCES "Episode" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "BudgetMonth" (
    "month" TEXT NOT NULL PRIMARY KEY,
    "plan" TEXT NOT NULL,
    "creditCap" INTEGER NOT NULL,
    "creditUsed" INTEGER NOT NULL DEFAULT 0,
    "claudeSeats" INTEGER NOT NULL DEFAULT 2,
    "costUsd" REAL NOT NULL DEFAULT 0
);

-- CreateTable
CREATE TABLE "ComplianceItem" (
    "code" TEXT NOT NULL PRIMARY KEY,
    "label" TEXT NOT NULL,
    "detail" TEXT NOT NULL,
    "blockAt" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "ComplianceCheck" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "episodeId" INTEGER NOT NULL,
    "itemCode" TEXT NOT NULL,
    "done" BOOLEAN NOT NULL DEFAULT false,
    "owner" TEXT,
    "note" TEXT,
    CONSTRAINT "ComplianceCheck_itemCode_fkey" FOREIGN KEY ("itemCode") REFERENCES "ComplianceItem" ("code") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Mission" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "episodeId" INTEGER NOT NULL,
    "type" TEXT NOT NULL,
    "body" TEXT NOT NULL,
    "votes" INTEGER NOT NULL DEFAULT 0,
    "status" TEXT NOT NULL DEFAULT 'COLLECTING',
    CONSTRAINT "Mission_episodeId_fkey" FOREIGN KEY ("episodeId") REFERENCES "Episode" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "FandomCandidate" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "votes" INTEGER NOT NULL DEFAULT 0,
    "checkTm" BOOLEAN NOT NULL DEFAULT false,
    "checkDup" BOOLEAN NOT NULL DEFAULT false,
    "checkWord" BOOLEAN NOT NULL DEFAULT false,
    "checkPron" BOOLEAN NOT NULL DEFAULT false,
    "checkChant" BOOLEAN NOT NULL DEFAULT false,
    "status" TEXT NOT NULL DEFAULT 'CANDIDATE'
);

-- CreateTable
CREATE TABLE "Gauge" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "label" TEXT NOT NULL,
    "threshold" INTEGER NOT NULL,
    "current" INTEGER NOT NULL DEFAULT 0,
    "unlocked" BOOLEAN NOT NULL DEFAULT false
);

-- CreateIndex
CREATE UNIQUE INDEX "Episode_no_key" ON "Episode"("no");

-- CreateIndex
CREATE UNIQUE INDEX "ChannelVersion_episodeId_channelCode_key" ON "ChannelVersion"("episodeId", "channelCode");

-- CreateIndex
CREATE UNIQUE INDEX "ComplianceCheck_episodeId_itemCode_key" ON "ComplianceCheck"("episodeId", "itemCode");
