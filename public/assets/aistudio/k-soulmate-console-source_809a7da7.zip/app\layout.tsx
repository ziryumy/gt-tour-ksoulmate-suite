import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "K-soulmate 콘텐츠 운영 콘솔",
  description: "5인조 AI 아이돌 콘텐츠 12화 × 4채널 재조립·검수·발행 내부 운영 도구",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body className="antialiased bg-[#f8f9fa] text-zinc-900 selection:bg-[#1F5E63] selection:text-white">
        {children}
      </body>
    </html>
  );
}
