"use client";

import React, { useState, useTransition } from "react";
import {
  updateBudgetCreditUsedAction,
  recordGenerationRunAction,
} from "@/app/actions";
import { CheckCircle2, AlertCircle, PlusCircle, Save } from "lucide-react";

interface CreditsClientProps {
  month: string;
  initialCreditUsed: number;
  creditCap: number;
}

export function CreditsClient({
  month,
  initialCreditUsed,
  creditCap,
}: CreditsClientProps) {
  const [creditUsedInput, setCreditUsedInput] = useState<string>(
    String(initialCreditUsed)
  );
  const [episodeNo, setEpisodeNo] = useState<number>(3);
  const [model, setModel] = useState<"seedance-2.0" | "seedance-2.5" | "fast">(
    "seedance-2.0"
  );
  const [purpose, setPurpose] = useState<"base" | "collection" | "retry">(
    "retry"
  );
  const [attempts, setAttempts] = useState<string>("4");
  const [accepted, setAccepted] = useState<string>("3");
  const [credits, setCredits] = useState<string>("120");

  const [feedback, setFeedback] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);
  const [isPending, startTransition] = useTransition();

  const handleManualUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    const val = Number(creditUsedInput);
    if (!Number.isFinite(val) || val < 0) {
      setFeedback({
        type: "error",
        text: "0 이상의 올바른 크레딧 숫자를 입력해 주세요.",
      });
      return;
    }

    startTransition(async () => {
      const res = await updateBudgetCreditUsedAction({
        month,
        creditUsed: Math.round(val),
      });
      if (res.ok) {
        setFeedback({
          type: "success",
          text: res.message ?? "저장했습니다",
        });
      } else {
        setFeedback({
          type: "error",
          text: res.error ?? "저장하지 못했습니다.",
        });
      }
    });
  };

  const handleRecordRun = (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      const res = await recordGenerationRunAction({
        episodeNo,
        model,
        purpose,
        attempts: Number(attempts),
        accepted: Number(accepted),
        credits: Number(credits),
      });
      if (res.ok) {
        setCreditUsedInput(String(Number(creditUsedInput) + Number(credits)));
        setFeedback({
          type: "success",
          text: res.message ?? "생성 기록을 추가했습니다.",
        });
      } else {
        setFeedback({
          type: "error",
          text: res.error ?? "저장하지 못했습니다.",
        });
      }
    });
  };

  return (
    <div className="space-y-4">
      {feedback && (
        <div
          role="status"
          className={`flex items-center justify-between rounded-[4px] border px-3 py-2 text-xs font-medium ${
            feedback.type === "success"
              ? "border-emerald-300 bg-emerald-50 text-emerald-900"
              : "border-red-300 bg-red-50 text-red-900"
          }`}
        >
          <span className="inline-flex items-center gap-1.5">
            {feedback.type === "success" ? (
              <CheckCircle2 className="h-3.5 w-3.5" />
            ) : (
              <AlertCircle className="h-3.5 w-3.5" />
            )}
            {feedback.text}
          </span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="text-[11px] underline"
          >
            닫기
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* 5-1. 이번 달 크레딧 사용량 수동 입력 */}
        <form
          onSubmit={handleManualUpdate}
          className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-3"
        >
          <div>
            <h2 className="text-xs font-bold text-zinc-900">
              이번 달 크레딧 사용량 수동 동기화 ({month})
            </h2>
            <p className="text-[11px] text-zinc-500">
              외부 Higgsfield 대시보드에서 확인한 누적 크레딧 사용량을 수동 입력합니다. (상한 {creditCap.toLocaleString()} 기준 80%={Math.round(creditCap * 0.8).toLocaleString()}, 90%={Math.round(creditCap * 0.9).toLocaleString()})
            </p>
          </div>

          <div className="flex flex-wrap items-end gap-2">
            <div className="flex-1 min-w-[160px]">
              <label
                htmlFor="manual-credit-used"
                className="block text-[11px] font-medium text-zinc-600"
              >
                누적 사용 크레딧
              </label>
              <input
                id="manual-credit-used"
                type="number"
                min={0}
                max={1000000}
                value={creditUsedInput}
                onChange={(e) => setCreditUsedInput(e.target.value)}
                className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 font-mono text-xs text-zinc-900 focus:border-[#1F5E63] focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={isPending}
              className="inline-flex items-center gap-1.5 rounded-[4px] bg-[#1F5E63] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#17494d] disabled:opacity-50"
            >
              <Save className="h-3.5 w-3.5" />
              <span>사용량 저장</span>
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5 pt-1">
            <button
              type="button"
              onClick={() => setCreditUsedInput("5640")}
              className="rounded-[3px] border border-zinc-200 bg-zinc-50 px-2 py-0.5 font-mono text-[11px] text-zinc-600 hover:bg-zinc-100"
            >
              60% (5,640)
            </button>
            <button
              type="button"
              onClick={() => setCreditUsedInput("7520")}
              className="rounded-[3px] border border-amber-300 bg-amber-50 px-2 py-0.5 font-mono text-[11px] text-amber-800 hover:bg-amber-100"
            >
              80% 경고 (7,520)
            </button>
            <button
              type="button"
              onClick={() => setCreditUsedInput("8460")}
              className="rounded-[3px] border border-red-300 bg-red-50 px-2 py-0.5 font-mono text-[11px] text-red-800 hover:bg-red-100"
            >
              90% 위험 (8,460)
            </button>
          </div>
        </form>

        {/* 5-2. 회차별 생성 기록 추가 (트랜잭션 연동) */}
        <form
          onSubmit={handleRecordRun}
          className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-3"
        >
          <div>
            <h2 className="text-xs font-bold text-zinc-900">
              회차별 생성 로그 기록 (크레딧 자동 합산)
            </h2>
            <p className="text-[11px] text-zinc-500">
              외부 생성 실행 결과를 기록하면 월 사용 크레딧에도 트랜잭션으로 즉시 합산됩니다.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 text-xs">
            <div>
              <label className="block text-[11px] font-medium text-zinc-600">
                회차
              </label>
              <select
                value={episodeNo}
                onChange={(e) => setEpisodeNo(Number(e.target.value))}
                className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1.5 text-xs"
              >
                {Array.from({ length: 12 }, (_, i) => i + 1).map((n) => (
                  <option key={n} value={n}>
                    제{n}화
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-zinc-600">
                모델
              </label>
              <select
                value={model}
                onChange={(e) =>
                  setModel(
                    e.target.value as "seedance-2.0" | "seedance-2.5" | "fast"
                  )
                }
                className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1.5 font-mono text-xs"
              >
                <option value="seedance-2.0">seedance-2.0</option>
                <option value="seedance-2.5">seedance-2.5</option>
                <option value="fast">fast</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-zinc-600">
                목적
              </label>
              <select
                value={purpose}
                onChange={(e) =>
                  setPurpose(
                    e.target.value as "base" | "collection" | "retry"
                  )
                }
                className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1.5 text-xs"
              >
                <option value="base">베이스 생성 (base)</option>
                <option value="collection">집합 컷 (collection)</option>
                <option value="retry">재생성 (retry)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-zinc-600">
                시도 수
              </label>
              <input
                type="number"
                min={1}
                value={attempts}
                onChange={(e) => setAttempts(e.target.value)}
                className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1.5 font-mono text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-zinc-600">
                채택 컷 수
              </label>
              <input
                type="number"
                min={0}
                value={accepted}
                onChange={(e) => setAccepted(e.target.value)}
                className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1.5 font-mono text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-zinc-600">
                소모 크레딧
              </label>
              <input
                type="number"
                min={1}
                value={credits}
                onChange={(e) => setCredits(e.target.value)}
                className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1.5 font-mono text-xs"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isPending}
              className="inline-flex items-center gap-1.5 rounded-[4px] bg-[#1F5E63] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#17494d] disabled:opacity-50"
            >
              <PlusCircle className="h-3.5 w-3.5" />
              <span>생성 로그 기록 및 차감</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
