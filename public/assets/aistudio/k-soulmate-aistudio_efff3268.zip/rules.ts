import type {
  ChannelVersion,
  ComplianceCheck,
  ComplianceItem,
  FandomCandidate,
  GenerationRun,
} from "./types";

/**
 * 1. 길이 검증 규칙 (SPEC 5.1)
 */
export function validateChannelLength(input: {
  cutCount: number | null;
  totalSec: number | null;
  targetCutCount: number;
  targetTotalSec: number;
  targetAvgCutSec: number;
}) {
  const { cutCount, totalSec, targetTotalSec, targetAvgCutSec } = input;
  const warnings: string[] = [];

  if (!cutCount || !totalSec || cutCount <= 0 || totalSec <= 0) {
    return {
      avgCutSec: null as number | null,
      hasWarning: true,
      warnings: ["컷 수와 총 길이(초)를 1 이상의 값으로 입력해 주세요."],
    };
  }

  const rawAvg = totalSec / cutCount;
  const avgCutSec = Number(rawAvg.toFixed(2));
  const isAvgCutWarning = Math.abs(rawAvg - targetAvgCutSec) > 0.3001;
  const isTotalSecWarning = Math.abs(totalSec - targetTotalSec) > 3;

  if (isAvgCutWarning) {
    warnings.push(
      `평균 컷 길이(${avgCutSec}초)가 채널 규격(${targetAvgCutSec}초 ±0.3초)을 벗어났습니다.`
    );
  }
  if (isTotalSecWarning) {
    warnings.push(
      `총 길이(${totalSec}초)가 채널 규격(${targetTotalSec}초 ±3초)을 벗어났습니다.`
    );
  }

  return {
    avgCutSec,
    hasWarning: isAvgCutWarning || isTotalSecWarning,
    warnings,
  };
}

/**
 * 2. 발행 게이트 규칙 (SPEC 5.2)
 */
export function canPublish(input: {
  episodeId: number;
  complianceRisk: boolean;
  versions: ChannelVersion[];
  checks: ComplianceCheck[];
  items: ComplianceItem[];
}) {
  const activeChannelOrder = ["JP", "US", "KR"];
  const incompleteChannels: string[] = [];

  for (const code of activeChannelOrder) {
    const ver = input.versions.find(
      (v) => v.episodeId === input.episodeId && v.channelCode === code
    );
    if (!ver || ver.status !== "DONE") {
      incompleteChannels.push(code);
    }
  }

  const beforePublishCodes = new Set(
    input.items.filter((i) => i.blockAt === "BEFORE_PUBLISH").map((i) => i.code)
  );

  const incompleteChecks: string[] = [];
  for (const itemCode of beforePublishCodes) {
    if (itemCode === "JP-04" && !input.complianceRisk) continue;
    const chk = input.checks.find(
      (c) => c.episodeId === input.episodeId && c.itemCode === itemCode
    );
    if (!chk || !chk.done) {
      incompleteChecks.push(itemCode);
    }
  }

  incompleteChecks.sort();
  const ok = incompleteChannels.length === 0 && incompleteChecks.length === 0;

  if (ok) {
    return {
      canPublish: true,
      incompleteChannels: [],
      incompleteChecks: [],
      reason: null as string | null,
    };
  }

  const parts: string[] = [];
  if (incompleteChannels.length > 0) {
    parts.push(`미완성 채널: ${incompleteChannels.join(", ")}`);
  }
  if (incompleteChecks.length > 0) {
    parts.push(`미완료 검수: ${incompleteChecks.join(", ")}`);
  }

  return {
    canPublish: false,
    incompleteChannels,
    incompleteChecks,
    reason: `발행할 수 없습니다. ${parts.join(" / ")}`,
  };
}

/**
 * 3. 크레딧 임계치 규칙 (SPEC 5.3)
 */
export function evaluateCreditUsage(creditUsed: number, creditCap: number) {
  const safeCap = creditCap > 0 ? creditCap : 1;
  const usageRatio = creditUsed / safeCap;
  const usagePercent = Number((usageRatio * 100).toFixed(1));
  const remainingCredits = Math.max(0, creditCap - creditUsed);

  let alertLevel: "normal" | "warning" | "blocker" = "normal";
  let alertMessage: string | null = null;

  if (usageRatio >= 0.9) {
    alertLevel = "blocker";
    alertMessage = `이번 달 크레딧 사용률이 ${usagePercent}% (${creditUsed.toLocaleString()} / ${creditCap.toLocaleString()})로 위험 임계치(90%)를 도달·초과했습니다. 재생성을 중단하고 잔여 크레딧(${remainingCredits.toLocaleString()})을 점검하세요.`;
  } else if (usageRatio >= 0.8) {
    alertLevel = "warning";
    alertMessage = `이번 달 크레딧 사용률이 ${usagePercent}% (${creditUsed.toLocaleString()} / ${creditCap.toLocaleString()})로 경고 임계치(80%)를 넘었습니다.`;
  }

  return {
    creditUsed,
    creditCap,
    usageRatio,
    usagePercent,
    remainingCredits,
    alertLevel,
    alertMessage,
  };
}

export function calculateEpisodeCreditStats(
  episode: { id: number; no: number; title: string },
  runs: GenerationRun[],
  threshold = 0.75
) {
  const epRuns = runs.filter((r) => r.episodeId === episode.id);
  const totalAttempts = epRuns.reduce((acc, r) => acc + r.attempts, 0);
  const totalAccepted = epRuns.reduce((acc, r) => acc + r.accepted, 0);
  const totalCredits = epRuns.reduce((acc, r) => acc + r.credits, 0);

  if (totalAttempts === 0) {
    return {
      episodeId: episode.id,
      episodeNo: episode.no,
      episodeTitle: episode.title,
      totalAttempts: 0,
      totalAccepted: 0,
      adoptionPercent: null as number | null,
      isLowAdoption: false,
      totalCredits: 0,
    };
  }

  const adoptionRate = totalAccepted / totalAttempts;
  return {
    episodeId: episode.id,
    episodeNo: episode.no,
    episodeTitle: episode.title,
    totalAttempts,
    totalAccepted,
    adoptionPercent: Number((adoptionRate * 100).toFixed(1)),
    isLowAdoption: adoptionRate < threshold,
    totalCredits,
  };
}

/**
 * 4. 팬덤명 5대 조건 규칙 (SPEC 5.4)
 */
export const FANDOM_CHECK_META: Array<{
  key: "checkTm" | "checkDup" | "checkWord" | "checkPron" | "checkChant";
  label: string;
  tooltip: string;
}> = [
  {
    key: "checkTm",
    label: "상표",
    tooltip: "한·일·미 상표권 저촉 여부가 없어야 합니다",
  },
  {
    key: "checkDup",
    label: "중복",
    tooltip: "기존 아이돌 팬덤명과 중복되지 않아야 합니다",
  },
  {
    key: "checkWord",
    label: "부적절어",
    tooltip: "4개국 언어에서 부정적 의미·속어가 없어야 합니다",
  },
  {
    key: "checkPron",
    label: "발음",
    tooltip: "한·일·영·중 화자 모두 발음하기 쉬워야 합니다",
  },
  {
    key: "checkChant",
    label: "3음절",
    tooltip: "3음절 이내로 끊어 부를 수 있어야 합니다",
  },
];

export function canShortlist(
  cand: Pick<
    FandomCandidate,
    "checkTm" | "checkDup" | "checkWord" | "checkPron" | "checkChant"
  >
): boolean {
  return Boolean(
    cand.checkTm &&
      cand.checkDup &&
      cand.checkWord &&
      cand.checkPron &&
      cand.checkChant
  );
}
