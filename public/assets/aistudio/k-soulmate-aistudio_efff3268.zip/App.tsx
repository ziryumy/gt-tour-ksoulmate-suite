import React, { useState, useEffect, useRef } from "react";
import {
  LayoutDashboard,
  Users,
  Film,
  Coins,
  ShieldAlert,
  HeartHandshake,
  Menu,
  X,
  Lock,
  Unlock,
  Copy,
  Check,
  FileText,
  ChevronLeft,
  ChevronRight,
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Save,
  ArrowLeft,
  Award,
  PlusCircle,
  RotateCcw,
  ExternalLink,
  CheckSquare,
  Square,
} from "lucide-react";
import {
  type ConsoleStoreState,
  type EpisodeStatus,
  type VersionStatus,
  type Member,
  EPISODE_STATUS_LABELS,
  EPISODE_STATUS_ORDER,
  VERSION_STATUS_LABELS,
  PURPOSE_LABELS,
  formatDateDot,
} from "./types";
import {
  validateChannelLength,
  canPublish,
  evaluateCreditUsage,
  calculateEpisodeCreditStats,
  canShortlist,
  FANDOM_CHECK_META,
} from "./rules";
import {
  createInitialSeedState,
  loadStore,
  saveStore,
} from "./seedData";

type RouteView =
  | { page: "dashboard" }
  | { page: "members" }
  | { page: "episodes" }
  | { page: "episodeDetail"; episodeNo: number; channelCode?: string }
  | { page: "channelEdit"; episodeNo: number; channelCode: string }
  | { page: "credits" }
  | { page: "compliance" }
  | { page: "engagement" };

type BadgeVariant =
  | "default"
  | "teal"
  | "tealSolid"
  | "amber"
  | "red"
  | "emerald"
  | "muted";

function Badge({
  children,
  variant = "default",
  className = "",
}: {
  children: React.ReactNode;
  variant?: BadgeVariant;
  className?: string;
}) {
  const variantStyles: Record<BadgeVariant, string> = {
    default: "border-zinc-300 bg-zinc-100 text-zinc-700",
    teal: "border-[#1F5E63]/30 bg-[#1F5E63]/10 text-[#1F5E63]",
    tealSolid: "border-[#1F5E63] bg-[#1F5E63] text-white",
    amber: "border-amber-300 bg-amber-50 text-amber-800",
    red: "border-red-300 bg-red-50 text-red-700",
    emerald: "border-emerald-300 bg-emerald-50 text-emerald-800",
    muted: "border-zinc-200 bg-zinc-50 text-zinc-400",
  };
  return (
    <span
      className={`inline-flex items-center gap-1 border px-1.5 py-0.5 text-[11px] font-medium leading-tight rounded-[2px] select-none whitespace-nowrap ${variantStyles[variant]} ${className}`}
    >
      {children}
    </span>
  );
}

function EpisodeStatusBadge({ status }: { status: EpisodeStatus }) {
  const map: Record<EpisodeStatus, BadgeVariant> = {
    PLANNING: "default",
    SCRIPTED: "default",
    GENERATED: "teal",
    EDITED: "teal",
    REVIEWED: "amber",
    PUBLISHED: "tealSolid",
  };
  return <Badge variant={map[status]}>{EPISODE_STATUS_LABELS[status]}</Badge>;
}

function VersionStatusBadge({ status }: { status: VersionStatus }) {
  const map: Record<VersionStatus, BadgeVariant> = {
    TODO: "default",
    IN_PROGRESS: "amber",
    DONE: "tealSolid",
    BLOCKED: "red",
  };
  return <Badge variant={map[status]}>{VERSION_STATUS_LABELS[status]}</Badge>;
}

const CHANNEL_NARRATION_RULES: Record<
  string,
  { forbidden: string; required: string }
> = {
  JP: {
    forbidden: "감탄사(すごい！), 과장된 형용사, 설명하는 문장",
    required: "1인칭, 과거형 회상, 신체 감각(손·숨·목소리), 문장 사이 0.8~1.2초 여백",
  },
  US: {
    forbidden: "문어체, 긴 문장, 조용한 톤",
    required: '현재형, 감탄, 시청자에게 말 거는 호흡("watch this"), 하이햇 동기 컷 전환',
  },
  KR: {
    forbidden: "과장, 감성적 수사",
    required: "오늘의 표현 명시, 장소명, 다음 화 예고, 한 컷 5초 이상 유지",
  },
  CN: {
    forbidden: "일본어 대본 단순 번역",
    required: "감성적이되 짧은 문장, 화면 하단 자막 영역 확보 (1차 창작)",
  },
};

const WORKFLOW_STEP_TITLES: Record<string, string> = {
  script: "나레이션 대본",
  vo: "나레이션 보이스 (V.O.)",
  cut: "편집 호흡 (컷 수 · 총 길이)",
  bgm: "BGM 트랙 선택",
  subtitle: "자막 및 채널 버전 완료 확인",
  publish: "발행 (게이트 검증)",
};

export default function App() {
  const [store, setStore] = useState<ConsoleStoreState>(() => loadStore());
  const [route, setRoute] = useState<RouteView>({ page: "dashboard" });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // 멤버 상세 모달 상태
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [copiedMemberId, setCopiedMemberId] = useState<string | null>(null);

  // 에피소드 상태 이동 에러 알림
  const [statusErrors, setStatusErrors] = useState<Record<number, string>>({});

  // 상태 변경 시 localStorage 영속화
  useEffect(() => {
    saveStore(store);
  }, [store]);

  const handleResetSeed = () => {
    const seeded = createInitialSeedState();
    setStore(seeded);
    saveStore(seeded);
    setStatusErrors({});
  };

  const handleTransitionEpisodeStatus = (
    episodeNo: number,
    targetStatus: EpisodeStatus
  ): { ok: boolean; error?: string } => {
    const ep = store.episodes.find((e) => e.no === episodeNo);
    if (!ep) return { ok: false, error: "에피소드를 찾을 수 없습니다." };

    if (targetStatus === "PUBLISHED") {
      const gate = canPublish({
        episodeId: ep.id,
        complianceRisk: ep.complianceRisk,
        versions: store.channelVersions,
        checks: store.complianceChecks,
        items: store.complianceItems,
      });
      if (!gate.canPublish) {
        const msg =
          gate.reason ??
          "발행 조건(활성 3채널 완료 및 필수 컴플라이언스 검수)을 충족하지 못했습니다.";
        setStatusErrors((prev) => ({ ...prev, [episodeNo]: msg }));
        return { ok: false, error: msg };
      }
    }

    setStatusErrors((prev) => {
      const next = { ...prev };
      delete next[episodeNo];
      return next;
    });

    setStore((prev) => ({
      ...prev,
      episodes: prev.episodes.map((e) =>
        e.no === episodeNo ? { ...e, status: targetStatus } : e
      ),
    }));
    return { ok: true };
  };

  const handleCopyPrompt = async (member: Member, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const text = `${member.outfitSpec}\n${member.faceSpec}`;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopiedMemberId(member.id);
    setTimeout(() => {
      setCopiedMemberId((prev) => (prev === member.id ? null : prev));
    }, 2000);
  };

  const navItems = [
    {
      key: "dashboard" as const,
      label: "대시보드",
      subLabel: "오늘 할 일 · 요약",
      icon: LayoutDashboard,
    },
    {
      key: "members" as const,
      label: "캐릭터 락",
      subLabel: "5인 시트 · 프롬프트",
      icon: Users,
    },
    {
      key: "episodes" as const,
      label: "에피소드",
      subLabel: "시즌1 12화 × 4채널",
      icon: Film,
    },
    {
      key: "credits" as const,
      label: "크레딧",
      subLabel: "월 예산 · 채택률",
      icon: Coins,
    },
    {
      key: "compliance" as const,
      label: "컴플라이언스",
      subLabel: "일본 7항목 · 약기법",
      icon: ShieldAlert,
    },
    {
      key: "engagement" as const,
      label: "참여",
      subLabel: "게이지 · 팬덤명 · 미션",
      icon: HeartHandshake,
    },
  ];

  const isNavActive = (key: string) => {
    if (key === "episodes") {
      return (
        route.page === "episodes" ||
        route.page === "episodeDetail" ||
        route.page === "channelEdit"
      );
    }
    return route.page === key;
  };

  // --- 서브 컴포넌트: 에피소드 상태 컨트롤 (버튼/드롭다운 전용) ---
  const renderEpisodeStatusControl = (
    episodeNo: number,
    currentStatus: EpisodeStatus,
    compact = false
  ) => {
    const idx = EPISODE_STATUS_ORDER.indexOf(currentStatus);
    const prevSt = idx > 0 ? EPISODE_STATUS_ORDER[idx - 1] : null;
    const nextSt =
      idx < EPISODE_STATUS_ORDER.length - 1
        ? EPISODE_STATUS_ORDER[idx + 1]
        : null;
    const err = statusErrors[episodeNo];

    return (
      <div className="space-y-1">
        <div className="inline-flex items-center gap-1">
          <button
            type="button"
            disabled={!prevSt}
            onClick={() =>
              prevSt && handleTransitionEpisodeStatus(episodeNo, prevSt)
            }
            className="inline-flex items-center gap-0.5 rounded-[3px] border border-zinc-200 bg-white px-1.5 py-1 text-[11px] font-medium text-zinc-700 hover:bg-zinc-100 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <ChevronLeft className="h-3 w-3" />
            {!compact && <span>이전</span>}
          </button>

          <select
            aria-label={`제${episodeNo}화 단계 선택`}
            value={currentStatus}
            onChange={(e) =>
              handleTransitionEpisodeStatus(
                episodeNo,
                e.target.value as EpisodeStatus
              )
            }
            className={`rounded-[3px] border px-2 py-1 text-[11px] font-semibold focus:border-[#1F5E63] focus:outline-none ${
              currentStatus === "PUBLISHED"
                ? "border-[#1F5E63] bg-[#1F5E63] text-white"
                : currentStatus === "REVIEWED"
                ? "border-amber-300 bg-amber-50 text-amber-900"
                : "border-zinc-300 bg-white text-zinc-800"
            }`}
          >
            {EPISODE_STATUS_ORDER.map((st) => (
              <option
                key={st}
                value={st}
                className="bg-white text-zinc-900 font-normal"
              >
                {EPISODE_STATUS_LABELS[st]} ({st})
              </option>
            ))}
          </select>

          <button
            type="button"
            disabled={!nextSt}
            onClick={() =>
              nextSt && handleTransitionEpisodeStatus(episodeNo, nextSt)
            }
            className="inline-flex items-center gap-0.5 rounded-[3px] border border-zinc-200 bg-white px-1.5 py-1 text-[11px] font-medium text-zinc-700 hover:bg-zinc-100 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {!compact && <span>다음</span>}
            <ChevronRight className="h-3 w-3" />
          </button>
        </div>

        {err && (
          <div
            role="alert"
            className="flex items-start gap-1 rounded-[3px] border border-red-300 bg-red-50 px-2 py-1 text-[11px] text-red-800"
          >
            <AlertCircle className="mt-0.5 h-3 w-3 shrink-0 text-red-600" />
            <span>{err}</span>
          </div>
        )}
      </div>
    );
  };

  // --- 화면 1: 대시보드 (/dashboard) ---
  const renderDashboard = () => {
    if (
      store.members.length === 0 &&
      store.episodes.length === 0 &&
      store.channels.length === 0
    ) {
      return (
        <div className="rounded-[8px] border border-zinc-200 bg-white p-6 text-xs text-zinc-600">
          아직 데이터가 없습니다. 상단 <code>시드 복원</code> 버튼을 눌러 데이터를 적재하세요.
        </div>
      );
    }

    const publishedCount = store.episodes.filter(
      (e) => e.status === "PUBLISHED"
    ).length;
    const creditUsage = evaluateCreditUsage(
      store.budget.creditUsed,
      store.budget.creditCap
    );

    const activeChannelCodes = new Set(
      store.channels.filter((c) => c.active).map((c) => c.code)
    );
    const inProgressEpIds = new Set(
      store.episodes
        .filter((e) =>
          ["SCRIPTED", "GENERATED", "EDITED", "REVIEWED"].includes(e.status)
        )
        .map((e) => e.id)
    );

    const incompleteVersions = store.channelVersions.filter(
      (v) =>
        activeChannelCodes.has(v.channelCode) &&
        inProgressEpIds.has(v.episodeId) &&
        v.status !== "DONE"
    );

    const beforePublishCodes = new Set(
      store.complianceItems
        .filter((i) => i.blockAt === "BEFORE_PUBLISH")
        .map((i) => i.code)
    );
    const blockedEpisodes = store.episodes.filter((ep) => {
      if (ep.status === "PUBLISHED" || !ep.complianceRisk) return false;
      const epChecks = store.complianceChecks.filter(
        (c) => c.episodeId === ep.id && beforePublishCodes.has(c.itemCode)
      );
      return epChecks.some((c) => !c.done);
    });

    const alertReasons: string[] = [];
    if (incompleteVersions.length > 0) {
      const list = incompleteVersions
        .map((v) => {
          const ep = store.episodes.find((e) => e.id === v.episodeId);
          return `${ep?.no}화(${v.channelCode})`;
        })
        .join(", ");
      alertReasons.push(
        `이번 주 발행 예정 회차 중 미완성 채널 버전이 ${incompleteVersions.length}건 있습니다: ${list}`
      );
    }
    if (creditUsage.alertLevel === "blocker") {
      alertReasons.push(
        `이번 달 크레딧 사용률이 ${creditUsage.usagePercent}% (${store.budget.creditUsed.toLocaleString()} / ${store.budget.creditCap.toLocaleString()})로 90% 위험 임계치를 넘었습니다.`
      );
    }
    if (blockedEpisodes.length > 0) {
      alertReasons.push(
        `공개 예정 회차 중 컴플라이언스(약기법 JP-04 등) 미완료로 발행 차단된 회차가 있습니다: ${blockedEpisodes
          .map((e) => `${e.no}화`)
          .join(", ")}`
      );
    }

    const recentRuns = [...store.runs]
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )
      .slice(0, 5);

    return (
      <div className="space-y-4">
        {alertReasons.length > 0 && (
          <div
            role="alert"
            className="rounded-[8px] border border-red-300 bg-red-50 p-3.5 text-xs text-red-900"
          >
            <div className="flex items-center gap-2 font-bold text-red-800">
              <ShieldAlert className="h-4 w-4 shrink-0 text-red-600" />
              <span>운영 긴급 점검 필요 ({alertReasons.length}건)</span>
            </div>
            <ul className="mt-1.5 list-disc space-y-0.5 pl-5 text-red-800">
              {alertReasons.map((r, i) => (
                <li key={i}>{r}</li>
              ))}
            </ul>
          </div>
        )}

        {creditUsage.alertLevel === "warning" && (
          <div className="flex items-center gap-2 rounded-[8px] border border-amber-300 bg-amber-50 px-3.5 py-2.5 text-xs font-medium text-amber-900">
            <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600" />
            <span>{creditUsage.alertMessage}</span>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
          <div>
            <h1 className="text-base font-bold text-zinc-900">운영 대시보드</h1>
            <p className="text-xs text-zinc-500">
              오늘 처리할 채널 재조립 버전과 리소스 현황을 3초 안에 확인합니다.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-[11px] text-zinc-500">
              Members {store.members.length} · Episodes {store.episodes.length} ·
              Channels {store.channels.length}
            </span>
            <button
              type="button"
              onClick={handleResetSeed}
              className="inline-flex items-center gap-1 rounded-[4px] border border-zinc-300 bg-white px-2 py-1 text-[11px] font-medium text-zinc-700 hover:bg-zinc-100"
            >
              <RotateCcw className="h-3 w-3" />
              시드 초기화
            </button>
          </div>
        </div>

        {/* 4개 지표 카드 */}
        <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <div className="rounded-[8px] border border-zinc-200 bg-white p-3.5">
            <div className="text-[11px] font-medium text-zinc-500">
              이번 주 발행 수
            </div>
            <div className="mt-1.5 flex items-baseline justify-between">
              <span className="font-mono text-xl font-bold text-zinc-900">
                {publishedCount}본
              </span>
              <Badge variant="teal">누적 완료</Badge>
            </div>
            <div className="mt-1 text-[11px] text-zinc-400">
              3채널(JP·US·KR) 동시 발행 기준
            </div>
          </div>

          <div className="rounded-[8px] border border-zinc-200 bg-white p-3.5">
            <div className="text-[11px] font-medium text-zinc-500">
              이번 주 목표
            </div>
            <div className="mt-1.5 flex items-baseline justify-between">
              <span className="font-mono text-xl font-bold text-zinc-900">
                2본
              </span>
              <span className="font-mono text-[11px] text-zinc-500">
                25.3시간/주
              </span>
            </div>
            <div className="mt-1 text-[11px] text-zinc-400">
              숏폼 15.7h + 참여 4.5h + 장편 5.1h
            </div>
          </div>

          <div className="rounded-[8px] border border-zinc-200 bg-white p-3.5">
            <div className="text-[11px] font-medium text-zinc-500">
              월 크레딧 사용률
            </div>
            <div className="mt-1.5 flex items-baseline justify-between">
              <span className="font-mono text-xl font-bold text-zinc-900">
                {creditUsage.usagePercent}%
              </span>
              <span className="font-mono text-[11px] text-zinc-500">
                {store.budget.creditUsed.toLocaleString()} /{" "}
                {store.budget.creditCap.toLocaleString()}
              </span>
            </div>
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-[2px] bg-zinc-100">
              <div
                className={
                  creditUsage.alertLevel === "blocker"
                    ? "h-full bg-red-600"
                    : creditUsage.alertLevel === "warning"
                    ? "h-full bg-amber-500"
                    : "h-full bg-[#1F5E63]"
                }
                style={{ width: `${Math.min(100, creditUsage.usagePercent)}%` }}
              />
            </div>
          </div>

          <div className="rounded-[8px] border border-zinc-200 bg-white p-3.5">
            <div className="text-[11px] font-medium text-zinc-500">
              차단된 회차 수
            </div>
            <div className="mt-1.5 flex items-baseline justify-between">
              <span className="font-mono text-xl font-bold text-red-700">
                {blockedEpisodes.length}화
              </span>
              <Badge variant={blockedEpisodes.length > 0 ? "amber" : "default"}>
                약기법 대상
              </Badge>
            </div>
            <div className="mt-1 text-[11px] text-zinc-400">
              {blockedEpisodes.length > 0
                ? `검수 필요: ${blockedEpisodes.map((e) => `${e.no}화`).join(", ")}`
                : "차단된 위험 회차 없음"}
            </div>
          </div>
        </section>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
          {/* 이번 주 할 일 */}
          <section className="rounded-[8px] border border-zinc-200 bg-white lg:col-span-7">
            <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-2.5">
              <div>
                <h2 className="text-xs font-bold text-zinc-900">
                  이번 주 할 일 (미완성 채널 버전)
                </h2>
                <p className="text-[11px] text-zinc-500">
                  클릭 시 해당 회차·채널 재조립 편집 화면으로 이동합니다.
                </p>
              </div>
              <Badge variant="teal">{incompleteVersions.length}건</Badge>
            </div>

            {incompleteVersions.length === 0 ? (
              <div className="p-6 text-center text-xs text-zinc-500">
                진행 중인 미완성 채널 버전이 없습니다.
              </div>
            ) : (
              <div className="divide-y divide-zinc-200">
                {incompleteVersions.map((ver) => {
                  const ep = store.episodes.find((e) => e.id === ver.episodeId)!;
                  const ch = store.channels.find(
                    (c) => c.code === ver.channelCode
                  )!;
                  return (
                    <button
                      key={ver.id}
                      type="button"
                      onClick={() =>
                        setRoute({
                          page: "channelEdit",
                          episodeNo: ep.no,
                          channelCode: ch.code,
                        })
                      }
                      className="flex w-full items-center justify-between gap-3 px-4 py-2.5 text-left text-xs transition-colors hover:bg-zinc-50"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-semibold text-[#1F5E63]">
                            제{ep.no}화
                          </span>
                          <span className="truncate font-medium text-zinc-900">
                            {ep.title}
                          </span>
                          {ep.complianceRisk && (
                            <Badge variant="amber">약기법</Badge>
                          )}
                        </div>
                        <div className="mt-0.5 flex items-center gap-2 text-[11px] text-zinc-500">
                          <span className="font-mono font-semibold text-zinc-700">
                            [{ch.code}]
                          </span>
                          <span>{ch.label}</span>
                          <span>·</span>
                          <span>
                            규격 {ch.totalSec}초 / {ch.cutCount}컷
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <EpisodeStatusBadge status={ep.status} />
                        <VersionStatusBadge status={ver.status} />
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </section>

          {/* 최근 생성 기록 */}
          <section className="rounded-[8px] border border-zinc-200 bg-white lg:col-span-5">
            <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-2.5">
              <div>
                <h2 className="text-xs font-bold text-zinc-900">최근 생성 기록</h2>
                <p className="text-[11px] text-zinc-500">
                  최근 5건 (외부 생성 수동 기록)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setRoute({ page: "credits" })}
                className="text-[11px] font-medium text-[#1F5E63] hover:underline"
              >
                전체 보기
              </button>
            </div>
            <div className="divide-y divide-zinc-200">
              {recentRuns.map((run) => {
                const ep = store.episodes.find((e) => e.id === run.episodeId);
                return (
                  <div
                    key={run.id}
                    className="flex items-center justify-between gap-2 px-4 py-2.5 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono font-semibold text-zinc-800">
                          제{ep?.no ?? run.episodeId}화
                        </span>
                        <Badge variant="default">{run.model}</Badge>
                        <span className="text-[11px] text-zinc-500">
                          {PURPOSE_LABELS[run.purpose] ?? run.purpose}
                        </span>
                      </div>
                      <div className="mt-0.5 text-[11px] text-zinc-400">
                        시도 {run.attempts}회 · 채택 {run.accepted}컷 ·{" "}
                        {formatDateDot(run.createdAt)}
                      </div>
                    </div>
                    <div className="shrink-0 text-right font-mono text-xs font-semibold text-zinc-900">
                      {run.credits.toLocaleString()} 크레딧
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        </div>
      </div>
    );
  };

  // --- 화면 2: 캐릭터 락 (/members) ---
  const renderMembers = () => {
    const orderedMembers = [...store.members].sort((a, b) =>
      a.id.localeCompare(b.id)
    );

    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
          <div>
            <h1 className="text-base font-bold text-zinc-900">
              캐릭터 락 레지스트리 (5인)
            </h1>
            <p className="text-xs text-zinc-500">
              5인의 아이덴티티 고정 시트(M1~M5 고정 순서)를 확인하고 생성 프롬프트를 복사합니다.
            </p>
          </div>
          <div className="flex items-center gap-1.5">
            <Badge variant="tealSolid">
              실사 시트 {orderedMembers.filter((m) => m.locked).length}/5 확정
            </Badge>
            <Badge variant="default">정렬 고정 (M1~M5)</Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
          {orderedMembers.map((member) => (
            <div
              key={member.id}
              role="button"
              tabIndex={0}
              onClick={() => setSelectedMember(member)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  setSelectedMember(member);
                }
              }}
              className={`group flex flex-col overflow-hidden rounded-[8px] bg-white text-left transition-colors hover:border-[#1F5E63] ${
                member.locked
                  ? "border border-zinc-200"
                  : "border-2 border-dashed border-amber-400"
              }`}
            >
              <div className="relative aspect-[16/10] w-full bg-zinc-100 border-b border-zinc-200 overflow-hidden">
                <img
                  src={member.photoSheetUrl}
                  alt={`${member.nameKo} 실사 캐릭터 시트`}
                  className="h-full w-full object-cover object-top"
                />
                <div className="absolute left-2.5 top-2.5 flex items-center gap-1.5">
                  <span className="rounded-[2px] bg-zinc-900/85 px-1.5 py-0.5 font-mono text-[11px] font-bold text-white">
                    {member.id}
                  </span>
                  {member.channelCode && (
                    <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[11px] font-semibold text-white">
                      담당 {member.channelCode}
                    </span>
                  )}
                </div>
                <div className="absolute right-2.5 top-2.5">
                  {member.locked ? (
                    <Badge variant="tealSolid">
                      <Lock className="h-3 w-3" /> 락 확정
                    </Badge>
                  ) : (
                    <Badge variant="amber">
                      <Unlock className="h-3 w-3" /> 락 미확정
                    </Badge>
                  )}
                </div>
              </div>

              <div className="flex flex-1 flex-col justify-between p-3.5">
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-baseline gap-1.5">
                      <h2 className="text-sm font-bold text-zinc-900">
                        {member.nameKo}
                      </h2>
                      <span className="text-[11px] text-zinc-400">
                        {member.nameJa} · {member.nameZh}
                      </span>
                    </div>
                    {member.animeSheetUrl ? (
                      <Badge variant="amber">애니 시트 (판정 3/5 · 보류)</Badge>
                    ) : (
                      <Badge variant="muted">애니 시트 미제작</Badge>
                    )}
                  </div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-zinc-600">
                    <span>{member.nationality}</span>
                    <span className="text-zinc-300">|</span>
                    <span className="font-medium text-zinc-800">
                      {member.position}
                    </span>
                    <span className="text-zinc-300">|</span>
                    <span className="font-mono">
                      {member.age}세 · {member.heightCm}cm
                    </span>
                  </div>
                  <p className="mt-2 line-clamp-1 font-mono text-[11px] text-zinc-500">
                    의상: {member.outfitSpec}
                  </p>
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-zinc-100 pt-2.5 text-[11px]">
                  <span className="font-mono text-zinc-400">
                    보이스: {member.voiceProfile ?? "미지정"}
                  </span>
                  <span className="font-semibold text-[#1F5E63] group-hover:underline">
                    상세 · 프롬프트 보기 →
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // --- 화면 3: 에피소드 보드 (/episodes) ---
  const renderEpisodes = () => {
    const channelOrder = ["JP", "US", "KR", "CN"];

    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
          <div>
            <h1 className="text-base font-bold text-zinc-900">
              에피소드 보드 (시즌1 · 12화)
            </h1>
            <p className="text-xs text-zinc-500">
              12화의 제작 단계(버튼/드롭다운 이동), 담당 멤버, 오늘의 한국어 3표현 및 4채널 진행 현황을 관리합니다.
            </p>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-zinc-500">
            <span className="inline-flex items-center gap-1">
              <span className="inline-block h-2 w-2 rounded-[1px] bg-[#1F5E63]" />{" "}
              완료
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="inline-block h-2 w-2 rounded-[1px] bg-amber-500" />{" "}
              진행중
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="inline-block h-2 w-2 rounded-[1px] bg-zinc-200 border border-zinc-300" />{" "}
              대기/Phase2
            </span>
          </div>
        </div>

        {/* 데스크톱 테이블 */}
        <div className="hidden md:block overflow-x-auto rounded-[8px] border border-zinc-200 bg-white">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-200 bg-zinc-50 text-[11px] font-semibold text-zinc-600">
                <th className="px-3 py-2.5 w-14">화</th>
                <th className="px-3 py-2.5">제목</th>
                <th className="px-3 py-2.5">장소</th>
                <th className="px-3 py-2.5 w-24">담당</th>
                <th className="px-3 py-2.5">오늘의 표현 (3개)</th>
                <th className="px-3 py-2.5 w-56">상태 이동 (버튼/드롭다운)</th>
                <th className="px-3 py-2.5 w-44">채널 진행 (4개 점)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200">
              {store.episodes.map((ep) => {
                const member = store.members.find((m) => m.id === ep.memberId);
                return (
                  <tr
                    key={ep.id}
                    className={`transition-colors hover:bg-zinc-100/70 ${
                      ep.complianceRisk ? "bg-amber-50/70" : "bg-white"
                    }`}
                  >
                    <td className="px-3 py-2.5 font-mono font-bold text-zinc-900">
                      <button
                        type="button"
                        onClick={() =>
                          setRoute({ page: "episodeDetail", episodeNo: ep.no })
                        }
                        className="hover:text-[#1F5E63] hover:underline"
                      >
                        제{ep.no}화
                      </button>
                    </td>
                    <td className="px-3 py-2.5">
                      <button
                        type="button"
                        onClick={() =>
                          setRoute({ page: "episodeDetail", episodeNo: ep.no })
                        }
                        className="inline-flex items-center gap-1.5 font-semibold text-zinc-900 hover:text-[#1F5E63] hover:underline text-left"
                      >
                        <span>{ep.title}</span>
                        {ep.complianceRisk && (
                          <Badge variant="amber">약기법</Badge>
                        )}
                      </button>
                    </td>
                    <td className="px-3 py-2.5 text-zinc-600">{ep.place}</td>
                    <td className="px-3 py-2.5">
                      {member ? (
                        <span className="font-medium text-zinc-800">
                          {member.nameKo}{" "}
                          <span className="font-mono text-[10px] text-zinc-400">
                            ({member.id})
                          </span>
                        </span>
                      ) : (
                        <span className="text-zinc-500">5인 전원</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex flex-wrap gap-1">
                        {ep.expressions.map((expr, i) => (
                          <span
                            key={i}
                            className="rounded-[2px] border border-zinc-200 bg-white/80 px-1.5 py-0.5 text-[11px] text-zinc-700"
                          >
                            {expr}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-3 py-2.5">
                      {renderEpisodeStatusControl(ep.no, ep.status)}
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-1.5">
                        {channelOrder.map((code) => {
                          const ver = store.channelVersions.find(
                            (v) =>
                              v.episodeId === ep.id && v.channelCode === code
                          );
                          const ch = store.channels.find(
                            (c) => c.code === code
                          );
                          const active = ch?.active ?? code !== "CN";
                          const st = ver?.status ?? "TODO";
                          const dotClass = !active
                            ? "bg-zinc-200 border-zinc-300"
                            : st === "DONE"
                            ? "bg-[#1F5E63] border-[#1F5E63]"
                            : st === "IN_PROGRESS"
                            ? "bg-amber-500 border-amber-600"
                            : st === "BLOCKED"
                            ? "bg-red-500 border-red-600"
                            : "bg-zinc-200 border-zinc-300";

                          return (
                            <button
                              key={code}
                              type="button"
                              disabled={!active}
                              onClick={() =>
                                setRoute({
                                  page: "channelEdit",
                                  episodeNo: ep.no,
                                  channelCode: code,
                                })
                              }
                              className="inline-flex items-center gap-1 rounded-[2px] px-1 py-0.5 text-[10px] font-mono text-zinc-700 hover:bg-zinc-200/70 disabled:cursor-not-allowed disabled:text-zinc-400"
                            >
                              <span
                                className={`inline-block h-2 w-2 rounded-[1px] border ${dotClass}`}
                              />
                              <span>{code}</span>
                            </button>
                          );
                        })}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* 모바일 카드 리스트 (375px 대응) */}
        <div className="md:hidden space-y-2.5">
          {store.episodes.map((ep) => {
            const member = store.members.find((m) => m.id === ep.memberId);
            return (
              <div
                key={ep.id}
                className={`rounded-[8px] border p-3.5 ${
                  ep.complianceRisk
                    ? "border-amber-300 bg-amber-50/70"
                    : "border-zinc-200 bg-white"
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setRoute({ page: "episodeDetail", episodeNo: ep.no })
                    }
                    className="flex items-center gap-1.5"
                  >
                    <span className="font-mono text-xs font-bold text-[#1F5E63]">
                      제{ep.no}화
                    </span>
                    {ep.complianceRisk && <Badge variant="amber">약기법</Badge>}
                  </button>
                  {renderEpisodeStatusControl(ep.no, ep.status, true)}
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setRoute({ page: "episodeDetail", episodeNo: ep.no })
                  }
                  className="mt-1.5 block text-left"
                >
                  <h2 className="text-sm font-bold text-zinc-900 hover:text-[#1F5E63] hover:underline">
                    {ep.title}
                  </h2>
                  <div className="mt-0.5 text-xs text-zinc-600">
                    {ep.place} ·{" "}
                    {member ? `${member.nameKo} (${member.id})` : "5인 전원"}
                  </div>
                </button>
                <div className="mt-2 flex flex-wrap gap-1">
                  {ep.expressions.map((expr, i) => (
                    <span
                      key={i}
                      className="rounded-[2px] border border-zinc-200 bg-white px-1.5 py-0.5 text-[11px] text-zinc-700"
                    >
                      {expr}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // --- 공통 서브 컴포넌트: 채널 버전 편집기 (4.5) ---
  const ChannelEditorBlock = ({
    episodeNo,
    channelCode,
    showDedicatedButton = false,
  }: {
    episodeNo: number;
    channelCode: string;
    showDedicatedButton?: boolean;
  }) => {
    const episode = store.episodes.find((e) => e.no === episodeNo)!;
    const channel = store.channels.find((c) => c.code === channelCode)!;
    const version = store.channelVersions.find(
      (v) => v.episodeId === episode.id && v.channelCode === channel.code
    )!;
    const narrator =
      store.members.find((m) => m.id === channel.narratorId) ?? null;
    const episodeMember =
      store.members.find((m) => m.id === episode.memberId) ?? null;

    const [narration, setNarration] = useState(version.narration);
    const [voStatus, setVoStatus] = useState<VersionStatus>(version.voStatus);
    const [bgmTrackId, setBgmTrackId] = useState(
      version.bgmTrackId ?? channel.bgmTracks[0] ?? ""
    );
    const [cutCountInput, setCutCountInput] = useState(
      String(version.cutCount ?? channel.cutCount)
    );
    const [totalSecInput, setTotalSecInput] = useState(
      String(version.totalSec ?? channel.totalSec)
    );
    const [status, setStatus] = useState<VersionStatus>(version.status);
    const [publishedUrl, setPublishedUrl] = useState(
      version.publishedUrl ?? ""
    );
    const [isDirty, setIsDirty] = useState(false);
    const [toast, setToast] = useState<{
      type: "success" | "error";
      text: string;
    } | null>(null);

    const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    useEffect(() => {
      setNarration(version.narration);
      setVoStatus(version.voStatus);
      setBgmTrackId(version.bgmTrackId ?? channel.bgmTracks[0] ?? "");
      setCutCountInput(String(version.cutCount ?? channel.cutCount));
      setTotalSecInput(String(version.totalSec ?? channel.totalSec));
      setStatus(version.status);
      setPublishedUrl(version.publishedUrl ?? "");
      setIsDirty(false);
      setToast(null);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [episodeNo, channelCode]);

    const parsedCutCount =
      cutCountInput.trim() === "" ? null : Number(cutCountInput);
    const parsedTotalSec =
      totalSecInput.trim() === "" ? null : Number(totalSecInput);

    const lengthValidation = validateChannelLength({
      cutCount: parsedCutCount,
      totalSec: parsedTotalSec,
      targetCutCount: channel.cutCount,
      targetTotalSec: channel.totalSec,
      targetAvgCutSec: channel.avgCutSec,
    });

    const publishGate = canPublish({
      episodeId: episode.id,
      complianceRisk: episode.complianceRisk,
      versions: store.channelVersions,
      checks: store.complianceChecks,
      items: store.complianceItems,
    });

    const commitSave = () => {
      setStore((prev) => ({
        ...prev,
        channelVersions: prev.channelVersions.map((v) =>
          v.episodeId === episode.id && v.channelCode === channel.code
            ? {
                ...v,
                narration,
                voStatus,
                bgmTrackId: bgmTrackId || null,
                cutCount: parsedCutCount ? Math.round(parsedCutCount) : null,
                totalSec: parsedTotalSec ? Math.round(parsedTotalSec) : null,
                status,
                publishedUrl: publishedUrl.trim() || null,
              }
            : v
        ),
      }));
      setIsDirty(false);
      setToast({ type: "success", text: "저장했습니다" });
    };

    // 5초 디바운스 자동 저장
    useEffect(() => {
      if (!isDirty) return;
      if (debounceRef.current) clearTimeout(debounceRef.current);
      debounceRef.current = setTimeout(() => {
        commitSave();
      }, 5000);
      return () => {
        if (debounceRef.current) clearTimeout(debounceRef.current);
      };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
      isDirty,
      narration,
      voStatus,
      bgmTrackId,
      cutCountInput,
      totalSecInput,
      status,
      publishedUrl,
    ]);

    const handlePublish = () => {
      if (lengthValidation.hasWarning) {
        setToast({
          type: "error",
          text: `발행할 수 없습니다. ${lengthValidation.warnings.join(" ")}`,
        });
        return;
      }
      if (!publishGate.canPublish) {
        setToast({
          type: "error",
          text: publishGate.reason ?? "발행 게이트 조건을 만족하지 못했습니다.",
        });
        return;
      }
      if (!publishedUrl.trim()) {
        setToast({
          type: "error",
          text: "발행 게시물 URL을 입력해 주세요.",
        });
        return;
      }

      setStore((prev) => ({
        ...prev,
        channelVersions: prev.channelVersions.map((v) =>
          v.episodeId === episode.id && v.channelCode === channel.code
            ? {
                ...v,
                narration,
                voStatus,
                bgmTrackId: bgmTrackId || null,
                cutCount: parsedCutCount ? Math.round(parsedCutCount) : null,
                totalSec: parsedTotalSec ? Math.round(parsedTotalSec) : null,
                status: "DONE",
                publishedUrl: publishedUrl.trim(),
                publishedAt: new Date().toISOString(),
              }
            : v
        ),
        episodes: prev.episodes.map((e) =>
          e.id === episode.id ? { ...e, status: "PUBLISHED" } : e
        ),
      }));
      setIsDirty(false);
      setToast({
        type: "success",
        text: `제${episode.no}화 ${channel.code} 채널 발행을 완료했습니다.`,
      });
    };

    const ruleGuide = CHANNEL_NARRATION_RULES[channel.code] ?? {
      forbidden: "번역투 문장 금지",
      required: "채널 고유 호흡 준수",
    };
    const hasSeparateScriptStep = channel.workflowOrder.includes("script");

    const fixedMembers: Member[] = [];
    if (episodeMember) fixedMembers.push(episodeMember);
    if (narrator && (!episodeMember || narrator.id !== episodeMember.id)) {
      fixedMembers.push(narrator);
    }

    const renderScriptBlock = () => (
      <div className="space-y-2.5">
        <div className="rounded-[4px] border border-zinc-200 bg-zinc-50 p-2.5 text-xs space-y-1">
          <div className="flex flex-wrap items-center justify-between gap-1">
            <span className="font-semibold text-zinc-800">
              화법 규칙: {channel.tone}
            </span>
            <Badge variant="teal">독립 재창작 (번역 금지)</Badge>
          </div>
          <div className="text-[11px] text-red-700">
            <strong>금지:</strong> {ruleGuide.forbidden}
          </div>
          <div className="text-[11px] text-[#1F5E63]">
            <strong>필수:</strong> {ruleGuide.required}
          </div>
        </div>
        <div>
          <div className="mb-1 flex items-center justify-between text-[11px] text-zinc-500">
            <span>{channel.code} 채널 나레이션 대본 (입력 시 5초 뒤 자동 저장)</span>
            <span className="font-mono">{narration.length}자</span>
          </div>
          <textarea
            rows={6}
            value={narration}
            onChange={(e) => {
              setNarration(e.target.value);
              setIsDirty(true);
            }}
            placeholder={`${channel.code} 채널 화법(${channel.tone})에 맞춘 나레이션 대본을 작성하세요...`}
            className="w-full rounded-[4px] border border-zinc-300 bg-white p-3 font-mono text-xs leading-relaxed text-zinc-900 focus:border-[#1F5E63] focus:outline-none"
          />
        </div>
      </div>
    );

    const renderStep = (step: string, index: number) => {
      const stepNo = String(index + 1).padStart(2, "0");
      const stepTitle = WORKFLOW_STEP_TITLES[step] ?? step;

      switch (step) {
        case "script":
          return (
            <div
              key={step}
              className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-2.5"
            >
              <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                <div className="flex items-center gap-2">
                  <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                    STEP {stepNo}
                  </span>
                  <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
                </div>
                <span className="font-mono text-[11px] text-zinc-400">script</span>
              </div>
              {renderScriptBlock()}
            </div>
          );

        case "vo":
          return (
            <div
              key={step}
              className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-3"
            >
              <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                <div className="flex items-center gap-2">
                  <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                    STEP {stepNo}
                  </span>
                  <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
                </div>
                <span className="font-mono text-[11px] text-zinc-400">vo</span>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 text-xs">
                <div>
                  <label className="block text-[11px] font-medium text-zinc-600">
                    V.O. 제작 상태
                  </label>
                  <select
                    value={voStatus}
                    onChange={(e) => {
                      setVoStatus(e.target.value as VersionStatus);
                      setIsDirty(true);
                    }}
                    className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 text-xs font-medium text-zinc-900"
                  >
                    {(["TODO", "IN_PROGRESS", "DONE", "BLOCKED"] as VersionStatus[]).map(
                      (st) => (
                        <option key={st} value={st}>
                          {VERSION_STATUS_LABELS[st]} ({st})
                        </option>
                      )
                    )}
                  </select>
                </div>
                <div>
                  <span className="block text-[11px] font-medium text-zinc-500">
                    보이스 프로필 (읽기 전용 · 고정)
                  </span>
                  <div className="mt-1 flex items-center justify-between rounded-[4px] border border-zinc-200 bg-zinc-100 px-2.5 py-1.5 font-mono text-xs text-zinc-600">
                    <span>
                      {narrator
                        ? `${narrator.nameKo} (${narrator.voiceProfile ?? "미지정"})`
                        : channel.narratorId}
                    </span>
                    <Badge variant="default">고정</Badge>
                  </div>
                </div>
              </div>

              {!hasSeparateScriptStep && (
                <div className="border-t border-zinc-100 pt-2.5">
                  {renderScriptBlock()}
                </div>
              )}
            </div>
          );

        case "cut":
          return (
            <div
              key={step}
              className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-3"
            >
              <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                <div className="flex items-center gap-2">
                  <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                    STEP {stepNo}
                  </span>
                  <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
                </div>
                <span className="font-mono text-[11px] text-zinc-500">
                  규격: {channel.totalSec}초 / {channel.cutCount}컷 / 평균{" "}
                  {channel.avgCutSec}초 (±0.3초)
                </span>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 text-xs">
                <div>
                  <label className="block text-[11px] font-medium text-zinc-600">
                    컷 수 (기준 {channel.cutCount}컷)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={500}
                    value={cutCountInput}
                    onChange={(e) => {
                      setCutCountInput(e.target.value);
                      setIsDirty(true);
                    }}
                    className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-zinc-600">
                    총 길이 초 (기준 {channel.totalSec}초)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={1200}
                    value={totalSecInput}
                    onChange={(e) => {
                      setTotalSecInput(e.target.value);
                      setIsDirty(true);
                    }}
                    className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 font-mono text-xs"
                  />
                </div>
                <div>
                  <span className="block text-[11px] font-medium text-zinc-500">
                    계산된 평균 컷 (읽기 전용 · 실시간)
                  </span>
                  <div
                    className={`mt-1 flex items-center justify-between rounded-[4px] border px-2.5 py-1.5 font-mono text-xs font-bold ${
                      lengthValidation.hasWarning
                        ? "border-amber-400 bg-amber-50 text-amber-900"
                        : "border-zinc-200 bg-zinc-100 text-zinc-900"
                    }`}
                  >
                    <span>
                      {lengthValidation.avgCutSec !== null
                        ? `${lengthValidation.avgCutSec}초`
                        : "-"}
                    </span>
                    <span className="text-[10px] font-normal text-zinc-500">
                      목표 {channel.avgCutSec}초
                    </span>
                  </div>
                </div>
              </div>

              {lengthValidation.hasWarning && (
                <div className="flex items-start gap-2 rounded-[4px] border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900">
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" />
                  <div>
                    <div className="font-semibold">
                      편집 호흡 규격 이탈 경고 (저장은 가능하나 발행은 차단됩니다)
                    </div>
                    <ul className="mt-0.5 list-disc pl-4 text-[11px] text-amber-800">
                      {lengthValidation.warnings.map((w, i) => (
                        <li key={i}>{w}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          );

        case "bgm":
          return (
            <div
              key={step}
              className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-2.5"
            >
              <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                <div className="flex items-center gap-2">
                  <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                    STEP {stepNo}
                  </span>
                  <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
                </div>
                <span className="text-[11px] text-zinc-400">
                  미리듣기 미지원 (Phase 1)
                </span>
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 text-xs">
                <div>
                  <label className="block text-[11px] font-medium text-zinc-600">
                    라이브러리 트랙 (3종 중 선택)
                  </label>
                  <select
                    value={bgmTrackId}
                    onChange={(e) => {
                      setBgmTrackId(e.target.value);
                      setIsDirty(true);
                    }}
                    className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 font-mono text-xs"
                  >
                    {channel.bgmTracks.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="rounded-[4px] border border-zinc-200 bg-zinc-50 px-3 py-2 text-[11px] text-zinc-600">
                  리듬 기준: <strong>{channel.rhythmBasis}</strong>
                </div>
              </div>
            </div>
          );

        case "subtitle":
          return (
            <div
              key={step}
              className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-2.5"
            >
              <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                <div className="flex items-center gap-2">
                  <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                    STEP {stepNo}
                  </span>
                  <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
                </div>
                <VersionStatusBadge status={status} />
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 items-center text-xs">
                <label className="inline-flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={status === "DONE"}
                    onChange={(e) => {
                      setStatus(e.target.checked ? "DONE" : "IN_PROGRESS");
                      setIsDirty(true);
                    }}
                    className="h-4 w-4 accent-[#1F5E63]"
                  />
                  <span className="font-medium text-zinc-800">
                    자막 검수 및 싱크 배치 완료 (체크 시 DONE 전환)
                  </span>
                </label>

                <div>
                  <label className="block text-[11px] font-medium text-zinc-600">
                    채널 버전 전체 상태
                  </label>
                  <select
                    value={status}
                    onChange={(e) => {
                      setStatus(e.target.value as VersionStatus);
                      setIsDirty(true);
                    }}
                    className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 text-xs font-semibold"
                  >
                    {(["TODO", "IN_PROGRESS", "DONE", "BLOCKED"] as VersionStatus[]).map(
                      (st) => (
                        <option key={st} value={st}>
                          {VERSION_STATUS_LABELS[st]} ({st})
                        </option>
                      )
                    )}
                  </select>
                </div>
              </div>
            </div>
          );

        case "publish": {
          const isPublishBlocked =
            !publishGate.canPublish || lengthValidation.hasWarning;
          return (
            <div
              key={step}
              className="rounded-[6px] border border-zinc-200 bg-white p-3.5 space-y-3"
            >
              <div className="flex items-center justify-between border-b border-zinc-100 pb-2">
                <div className="flex items-center gap-2">
                  <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                    STEP {stepNo}
                  </span>
                  <h3 className="text-xs font-bold text-zinc-900">{stepTitle}</h3>
                </div>
                {version.publishedAt && (
                  <span className="font-mono text-[11px] text-[#1F5E63]">
                    발행일: {formatDateDot(version.publishedAt)}
                  </span>
                )}
              </div>

              {!publishGate.canPublish && (
                <div className="flex items-start gap-2 rounded-[4px] border border-red-300 bg-red-50 px-3 py-2 text-xs text-red-900">
                  <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
                  <div>
                    <div className="font-bold">{publishGate.reason}</div>
                    <p className="mt-0.5 text-[11px] text-red-700">
                      활성 3개 채널(JP·US·KR) 모두 DONE 상태이고 발행 전 필수 컴플라이언스 검수가 완료되어야 발행 버튼이 활성화됩니다.
                    </p>
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
                <div className="flex-1">
                  <label className="block text-[11px] font-medium text-zinc-600">
                    발행 게시물 URL (수동 입력)
                  </label>
                  <input
                    type="url"
                    value={publishedUrl}
                    onChange={(e) => {
                      setPublishedUrl(e.target.value);
                      setIsDirty(true);
                    }}
                    placeholder={`https://social.k-soulmate.internal/${channel.code.toLowerCase()}/ep-${String(
                      episode.no
                    ).padStart(2, "0")}`}
                    className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 font-mono text-xs"
                  />
                </div>
                <button
                  type="button"
                  disabled={isPublishBlocked || !publishedUrl.trim()}
                  onClick={handlePublish}
                  className="inline-flex items-center justify-center rounded-[4px] bg-[#1F5E63] px-4 py-1.5 text-xs font-semibold text-white hover:bg-[#17494d] disabled:cursor-not-allowed disabled:bg-zinc-300 disabled:text-zinc-500"
                >
                  발행 확정
                </button>
              </div>
            </div>
          );
        }

        default:
          return null;
      }
    };

    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-[6px] border border-zinc-200 bg-zinc-50 px-3.5 py-2.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-xs font-bold text-white">
              {channel.code}
            </span>
            <span className="text-xs font-bold text-zinc-900">
              {channel.label}
            </span>
            <span className="text-[11px] text-zinc-500">
              · 작업 순서:{" "}
              <strong className="font-mono text-[#1F5E63]">
                {channel.workflowOrder.join(" → ")}
              </strong>
            </span>
          </div>
          <div className="flex items-center gap-2">
            {showDedicatedButton && (
              <button
                type="button"
                onClick={() =>
                  setRoute({
                    page: "channelEdit",
                    episodeNo: episode.no,
                    channelCode: channel.code,
                  })
                }
                className="inline-flex items-center gap-1 rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1 text-[11px] font-medium text-zinc-700 hover:bg-zinc-100"
              >
                <span>전용 편집 화면</span>
                <ExternalLink className="h-3 w-3" />
              </button>
            )}
            <button
              type="button"
              onClick={commitSave}
              className="inline-flex items-center gap-1.5 rounded-[4px] bg-[#1F5E63] px-3 py-1 text-xs font-semibold text-white hover:bg-[#17494d]"
            >
              <Save className="h-3.5 w-3.5" />
              <span>저장</span>
            </button>
          </div>
        </div>

        {toast && (
          <div
            className={`flex items-center justify-between rounded-[4px] border px-3 py-2 text-xs font-medium ${
              toast.type === "success"
                ? "border-emerald-300 bg-emerald-50 text-emerald-900"
                : "border-red-300 bg-red-50 text-red-900"
            }`}
          >
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5" />
              {toast.text}
            </span>
            <button
              type="button"
              onClick={() => setToast(null)}
              className="text-[11px] underline"
            >
              닫기
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
          <div className="space-y-3 lg:col-span-8">
            {channel.workflowOrder.map((step, i) => renderStep(step, i))}
          </div>

          <aside className="lg:col-span-4 space-y-3">
            <div className="rounded-[6px] border border-zinc-200 bg-zinc-100/80 p-3.5 space-y-3">
              <div className="flex items-center justify-between border-b border-zinc-200 pb-2">
                <div className="flex items-center gap-1.5">
                  <Lock className="h-3.5 w-3.5 text-zinc-500" />
                  <span className="text-xs font-bold text-zinc-700">
                    고정 — 채널과 무관하게 동일
                  </span>
                </div>
                <Badge variant="default">편집 불가</Badge>
              </div>

              <div className="space-y-1 text-xs">
                <div className="text-[11px] font-semibold text-zinc-500">
                  베이스 영상 마스터 (130초 헤드룸)
                </div>
                <div className="rounded-[4px] border border-zinc-200 bg-zinc-50 px-2.5 py-1.5 font-mono text-[11px] text-zinc-600 break-all">
                  {episode.baseVideoUrl ?? "베이스 마스터 미등록 (생성 대기)"}
                </div>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="text-[11px] font-semibold text-zinc-500">
                  오늘의 한국어 3표현 (대사 원음 고정)
                </div>
                <div className="space-y-1">
                  {episode.expressions.map((expr, i) => (
                    <div
                      key={i}
                      className="rounded-[4px] border border-zinc-200 bg-zinc-50 px-2.5 py-1.5 text-xs font-medium text-zinc-700"
                    >
                      <span className="mr-1.5 font-mono text-[10px] text-zinc-400">
                        0{i + 1}
                      </span>
                      「{expr}」
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="text-[11px] font-semibold text-zinc-500">
                  참여 캐릭터 시트 (회차 담당 · 채널 내레이터)
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {fixedMembers.map((m) => (
                    <div
                      key={m.id}
                      className="overflow-hidden rounded-[4px] border border-zinc-200 bg-zinc-50"
                    >
                      <div className="aspect-[4/3] w-full bg-zinc-200 overflow-hidden">
                        <img
                          src={m.photoSheetUrl}
                          alt={m.nameKo}
                          className="h-full w-full object-cover object-top"
                        />
                      </div>
                      <div className="p-1.5 text-[11px]">
                        <div className="font-bold text-zinc-800">
                          {m.nameKo}{" "}
                          <span className="font-mono text-[10px] text-zinc-500">
                            ({m.id})
                          </span>
                        </div>
                        <div className="text-[10px] text-zinc-500">
                          {episodeMember?.id === m.id && narrator?.id === m.id
                            ? "주인공 · 내레이터"
                            : episodeMember?.id === m.id
                            ? "회차 주인공"
                            : `${channel.code} 내레이터`}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-[4px] border border-zinc-200 bg-zinc-50 px-2.5 py-2 text-[11px] text-zinc-500">
                장소 고정:{" "}
                <strong className="text-zinc-700">{episode.place}</strong>
              </div>
            </div>
          </aside>
        </div>
      </div>
    );
  };

  // --- 화면 4: 에피소드 상세 (/episodes/[no]) ---
  const renderEpisodeDetail = (episodeNo: number, initialChannel = "JP") => {
    const episode = store.episodes.find((e) => e.no === episodeNo);
    if (!episode) return null;

    const member = store.members.find((m) => m.id === episode.memberId);
    const activeTabCode =
      initialChannel && initialChannel !== "CN" ? initialChannel : "JP";

    const publishGate = canPublish({
      episodeId: episode.id,
      complianceRisk: episode.complianceRisk,
      versions: store.channelVersions,
      checks: store.complianceChecks,
      items: store.complianceItems,
    });

    const epRuns = store.runs.filter((r) => r.episodeId === episode.id);
    const totalRunCredits = epRuns.reduce((acc, r) => acc + r.credits, 0);

    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => setRoute({ page: "episodes" })}
            className="inline-flex items-center gap-1 text-xs font-medium text-zinc-500 hover:text-[#1F5E63]"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            에피소드 보드(12화)로 돌아가기
          </button>

          {publishGate.canPublish ? (
            <div className="inline-flex items-center gap-1.5 rounded-[4px] border border-emerald-300 bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-900">
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-700" />
              <span>발행 가능 (3채널 완료 · 필수 검수 통과)</span>
            </div>
          ) : (
            <div className="inline-flex items-center gap-1.5 rounded-[4px] border border-red-300 bg-red-50 px-2.5 py-1 text-[11px] font-semibold text-red-900">
              <ShieldAlert className="h-3.5 w-3.5 text-red-600" />
              <span>{publishGate.reason}</span>
            </div>
          )}
        </div>

        <header
          className={`rounded-[8px] border p-4 ${
            episode.complianceRisk
              ? "border-amber-300 bg-amber-50/60"
              : "border-zinc-200 bg-white"
          }`}
        >
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-[2px] bg-[#1F5E63] px-2 py-0.5 font-mono text-xs font-bold text-white">
                  제{episode.no}화
                </span>
                <h1 className="text-base font-bold text-zinc-900">
                  {episode.title}
                </h1>
                {episode.complianceRisk && (
                  <Badge variant="amber">약기법 필수 검수 회차</Badge>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-zinc-600">
                <span>장소: {episode.place}</span>
                <span className="text-zinc-300">|</span>
                <span>
                  담당 멤버:{" "}
                  <strong className="font-semibold text-zinc-800">
                    {member
                      ? `${member.nameKo} (${member.id} · ${member.position})`
                      : "5인 전원 합류"}
                  </strong>
                </span>
              </div>
            </div>
            <div className="flex flex-col items-end gap-1">
              <span className="text-[11px] text-zinc-500">
                단계 이동 (버튼 / 드롭다운)
              </span>
              {renderEpisodeStatusControl(episode.no, episode.status)}
            </div>
          </div>
        </header>

        {/* 오늘의 표현 3개 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white p-4">
          <div className="mb-2.5 flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Lock className="h-3.5 w-3.5 text-zinc-500" />
              <h2 className="text-xs font-bold text-zinc-900">
                오늘의 한국어 3표현
              </h2>
            </div>
            <Badge variant="default">고정 — 4채널 공통 원음</Badge>
          </div>
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
            {episode.expressions.map((expr, i) => (
              <div
                key={i}
                className="rounded-[6px] border border-zinc-200 bg-zinc-50 p-3"
              >
                <div className="font-mono text-[10px] font-semibold text-zinc-400">
                  표현 0{i + 1}
                </div>
                <div className="mt-1 text-xs font-semibold text-zinc-800">
                  「{expr}」
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 4개 채널 탭 + 편집기 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white">
          <div className="flex flex-wrap border-b border-zinc-200 bg-zinc-50 px-2 pt-2 gap-1">
            {store.channels.map((ch) => {
              const ver = store.channelVersions.find(
                (v) => v.episodeId === episode.id && v.channelCode === ch.code
              );
              const isDisabled = !ch.active || ch.code === "CN";
              const isSelected = activeTabCode === ch.code && !isDisabled;

              return (
                <button
                  key={ch.code}
                  type="button"
                  disabled={isDisabled}
                  onClick={() =>
                    !isDisabled &&
                    setRoute({
                      page: "episodeDetail",
                      episodeNo: episode.no,
                      channelCode: ch.code,
                    })
                  }
                  className={`inline-flex items-center gap-2 rounded-t-[4px] border-x border-t px-3.5 py-2 text-xs font-semibold transition-colors ${
                    isDisabled
                      ? "cursor-not-allowed border-transparent bg-zinc-100 text-zinc-400"
                      : isSelected
                      ? "-mb-px border-zinc-200 bg-white text-[#1F5E63]"
                      : "border-transparent bg-transparent text-zinc-600 hover:bg-zinc-100"
                  }`}
                >
                  <span className="font-mono font-bold">{ch.code}</span>
                  <span className="hidden sm:inline text-[11px] font-normal">
                    {ch.label}
                  </span>
                  {isDisabled ? (
                    <Badge variant="muted">Phase 2</Badge>
                  ) : (
                    ver && <VersionStatusBadge status={ver.status} />
                  )}
                </button>
              );
            })}
          </div>
          <div className="p-4">
            <ChannelEditorBlock
              episodeNo={episode.no}
              channelCode={activeTabCode}
              showDedicatedButton
            />
          </div>
        </section>

        {/* 하단 2열: 생성 기록 표 + 컴플라이언스 체크리스트 */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
          <section className="rounded-[8px] border border-zinc-200 bg-white lg:col-span-6">
            <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-2.5">
              <div>
                <h2 className="text-xs font-bold text-zinc-900">생성 기록</h2>
                <p className="text-[11px] text-zinc-500">
                  제{episode.no}화 외부 영상 생성 로그
                </p>
              </div>
              <span className="font-mono text-xs font-semibold text-[#1F5E63]">
                합계 {totalRunCredits.toLocaleString()} 크레딧
              </span>
            </div>
            {epRuns.length === 0 ? (
              <div className="p-6 text-center text-xs text-zinc-500">
                아직 기록된 생성 로그가 없습니다.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-left text-xs">
                  <thead>
                    <tr className="border-b border-zinc-200 bg-zinc-50 text-[11px] font-semibold text-zinc-600">
                      <th className="px-3 py-2">모델</th>
                      <th className="px-3 py-2">목적</th>
                      <th className="px-3 py-2 text-right">시도</th>
                      <th className="px-3 py-2 text-right">채택</th>
                      <th className="px-3 py-2 text-right">크레딧</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-200">
                    {epRuns.map((run) => (
                      <tr key={run.id}>
                        <td className="px-3 py-2 font-mono font-medium">
                          {run.model}
                        </td>
                        <td className="px-3 py-2 text-zinc-600">
                          {PURPOSE_LABELS[run.purpose] ?? run.purpose}
                        </td>
                        <td className="px-3 py-2 text-right font-mono">
                          {run.attempts}
                        </td>
                        <td className="px-3 py-2 text-right font-mono">
                          {run.accepted}
                        </td>
                        <td className="px-3 py-2 text-right font-mono font-semibold">
                          {run.credits.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>

          <section className="rounded-[8px] border border-zinc-200 bg-white lg:col-span-6">
            <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-2.5">
              <div>
                <h2 className="text-xs font-bold text-zinc-900">
                  컴플라이언스 체크리스트 요약
                </h2>
                <p className="text-[11px] text-zinc-500">
                  일본 시장 7개 법규 검수 상태
                </p>
              </div>
              <button
                type="button"
                onClick={() => setRoute({ page: "compliance" })}
                className="text-[11px] font-medium text-[#1F5E63] hover:underline"
              >
                매트릭스에서 편집 →
              </button>
            </div>
            <div className="divide-y divide-zinc-200">
              {store.complianceItems.map((item) => {
                const chk = store.complianceChecks.find(
                  (c) => c.episodeId === episode.id && c.itemCode === item.code
                );
                const done = chk?.done ?? false;
                const isMandatoryYakgi =
                  item.code === "JP-04" && episode.complianceRisk;
                const isGreyYakgi =
                  item.code === "JP-04" && !episode.complianceRisk;

                return (
                  <div
                    key={item.code}
                    className={`flex items-center justify-between gap-2 px-4 py-2 text-xs ${
                      isMandatoryYakgi && !done
                        ? "bg-amber-50/70"
                        : isGreyYakgi
                        ? "bg-zinc-50 text-zinc-400"
                        : ""
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      {done ? (
                        <CheckSquare className="h-3.5 w-3.5 shrink-0 text-[#1F5E63]" />
                      ) : (
                        <Square className="h-3.5 w-3.5 shrink-0 text-zinc-400" />
                      )}
                      <span className="font-mono text-[11px] font-semibold">
                        {item.code}
                      </span>
                      <span className="truncate font-medium">{item.label}</span>
                      {isMandatoryYakgi && (
                        <Badge variant="amber">약기법 필수</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      {isGreyYakgi ? (
                        <Badge variant="muted">일반 회차 (비대상)</Badge>
                      ) : (
                        <>
                          <Badge
                            variant={
                              item.blockAt === "BEFORE_PUBLISH"
                                ? "red"
                                : "default"
                            }
                          >
                            {item.blockAt === "BEFORE_PUBLISH"
                              ? "발행 전 필수"
                              : "런칭 시"}
                          </Badge>
                          <Badge variant={done ? "tealSolid" : "default"}>
                            {done ? "완료" : "미완료"}
                          </Badge>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        </div>
      </div>
    );
  };

  // --- 화면 5: 채널 전용 편집 (/episodes/[no]/channels/[code]) ---
  const renderChannelEditPage = (episodeNo: number, channelCode: string) => {
    const episode = store.episodes.find((e) => e.no === episodeNo);
    const channel = store.channels.find((c) => c.code === channelCode);
    if (!episode || !channel) return null;

    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <button
            type="button"
            onClick={() =>
              setRoute({
                page: "episodeDetail",
                episodeNo: episode.no,
                channelCode: channel.code,
              })
            }
            className="inline-flex items-center gap-1 text-xs font-medium text-zinc-500 hover:text-[#1F5E63]"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            제{episode.no}화 상세로 돌아가기
          </button>
          <div className="flex items-center gap-2">
            <EpisodeStatusBadge status={episode.status} />
            {episode.complianceRisk && <Badge variant="amber">약기법</Badge>}
          </div>
        </div>

        <div className="rounded-[8px] border border-zinc-200 bg-white">
          <div className="border-b border-zinc-200 px-4 py-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-[2px] bg-[#1F5E63] px-2 py-0.5 font-mono text-xs font-bold text-white">
                제{episode.no}화 · {channel.code}
              </span>
              <h1 className="text-base font-bold text-zinc-900">
                {episode.title} — {channel.label} 버전 편집
              </h1>
            </div>
          </div>

          <div className="flex flex-wrap gap-1 border-b border-zinc-200 bg-zinc-50 px-2 pt-2">
            {store.channels.map((ch) => {
              const ver = store.channelVersions.find(
                (v) => v.episodeId === episode.id && v.channelCode === ch.code
              );
              const isDisabled = !ch.active || ch.code === "CN";
              const isCurrent = ch.code === channel.code;

              if (isDisabled) {
                return (
                  <span
                    key={ch.code}
                    className="inline-flex cursor-not-allowed items-center gap-2 rounded-t-[4px] px-3.5 py-2 text-xs font-semibold text-zinc-400"
                  >
                    <span className="font-mono font-bold">{ch.code}</span>
                    <Badge variant="muted">Phase 2</Badge>
                  </span>
                );
              }

              return (
                <button
                  key={ch.code}
                  type="button"
                  onClick={() =>
                    setRoute({
                      page: "channelEdit",
                      episodeNo: episode.no,
                      channelCode: ch.code,
                    })
                  }
                  className={`inline-flex items-center gap-2 rounded-t-[4px] border-x border-t px-3.5 py-2 text-xs font-semibold transition-colors ${
                    isCurrent
                      ? "-mb-px border-zinc-200 bg-white text-[#1F5E63]"
                      : "border-transparent text-zinc-600 hover:bg-zinc-100"
                  }`}
                >
                  <span className="font-mono font-bold">{ch.code}</span>
                  <span className="hidden sm:inline text-[11px] font-normal">
                    {ch.label}
                  </span>
                  {ver && <VersionStatusBadge status={ver.status} />}
                </button>
              );
            })}
          </div>

          <div className="p-4">
            <ChannelEditorBlock
              episodeNo={episode.no}
              channelCode={channel.code}
            />
          </div>
        </div>
      </div>
    );
  };

  // --- 화면 6: 크레딧·예산 (/credits) ---
  const CreditsView = () => {
    const [creditInput, setCreditInput] = useState(
      String(store.budget.creditUsed)
    );
    const [epNo, setEpNo] = useState(3);
    const [model, setModel] = useState("seedance-2.0");
    const [purpose, setPurpose] = useState("retry");
    const [attempts, setAttempts] = useState("4");
    const [accepted, setAccepted] = useState("3");
    const [credits, setCredits] = useState("120");
    const [msg, setMsg] = useState<string | null>(null);

    const usage = evaluateCreditUsage(
      store.budget.creditUsed,
      store.budget.creditCap
    );
    const epStats = store.episodes.map((ep) =>
      calculateEpisodeCreditStats(ep, store.runs, 0.75)
    );
    const totalLogged = epStats.reduce((a, b) => a + b.totalCredits, 0);

    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
          <div>
            <h1 className="text-base font-bold text-zinc-900">
              크레딧 · 예산 관리
            </h1>
            <p className="text-xs text-zinc-500">
              크레딧은 다음 달로 이월되지 않습니다. 월 단위 상한과 회차별 채택률(기준 75%)을 점검합니다.
            </p>
          </div>
          <Badge variant="amber">월 단위 리셋 · 이월 불가</Badge>
        </div>

        {usage.alertLevel !== "normal" && usage.alertMessage && (
          <div
            className={`flex items-start gap-2 rounded-[6px] border px-4 py-3 text-xs ${
              usage.alertLevel === "blocker"
                ? "border-red-300 bg-red-50 text-red-900"
                : "border-amber-300 bg-amber-50 text-amber-900"
            }`}
          >
            <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
            <div>
              <div className="font-bold">
                {usage.alertLevel === "blocker"
                  ? "크레딧 90% 초과 위험 경보"
                  : "크레딧 80% 도달 주의"}
              </div>
              <p className="mt-0.5">{usage.alertMessage}</p>
            </div>
          </div>
        )}

        {msg && (
          <div className="flex items-center justify-between rounded-[4px] border border-emerald-300 bg-emerald-50 px-3 py-2 text-xs font-medium text-emerald-900">
            <span>{msg}</span>
            <button
              type="button"
              onClick={() => setMsg(null)}
              className="text-[11px] underline"
            >
              닫기
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
          <section className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-900">
                이번 달 크레딧 게이지 ({store.budget.month})
              </span>
              <Badge
                variant={
                  usage.alertLevel === "blocker"
                    ? "red"
                    : usage.alertLevel === "warning"
                    ? "amber"
                    : "teal"
                }
              >
                {usage.usagePercent}% 사용
              </Badge>
            </div>
            <div className="flex items-baseline justify-between font-mono">
              <span className="text-xl font-bold text-zinc-900">
                {usage.creditUsed.toLocaleString()}
              </span>
              <span className="text-xs text-zinc-500">
                / {usage.creditCap.toLocaleString()} 크레딧 (잔여{" "}
                {usage.remainingCredits.toLocaleString()})
              </span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-[2px] bg-zinc-100">
              <div
                className={`h-full transition-all ${
                  usage.alertLevel === "blocker"
                    ? "bg-red-600"
                    : usage.alertLevel === "warning"
                    ? "bg-amber-500"
                    : "bg-[#1F5E63]"
                }`}
                style={{ width: `${Math.min(100, usage.usagePercent)}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] font-mono text-zinc-400">
              <span>0%</span>
              <span className="text-amber-600">80% 경고 (7,520)</span>
              <span className="text-red-600">90% 차단 (8,460)</span>
            </div>
          </section>

          <section className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-900">
                현재 요금제 구성
              </span>
              <Badge variant="tealSolid">
                {store.budget.plan.toUpperCase()}
              </Badge>
            </div>
            <div className="space-y-1 text-xs text-zinc-600">
              <div className="flex justify-between">
                <span>Higgsfield 플랜</span>
                <span className="font-mono font-semibold text-zinc-900">
                  ULTRA (승인 상한 9,400 크레딧)
                </span>
              </div>
              <div className="flex justify-between">
                <span>Claude Team Standard</span>
                <span className="font-mono font-semibold text-zinc-900">
                  {store.budget.claudeSeats}석 ($20 × 2)
                </span>
              </div>
              <div className="flex justify-between">
                <span>월 계획 생성량</span>
                <span className="font-mono text-zinc-800">
                  약 416회 (숏폼4·참여4·장편1)
                </span>
              </div>
            </div>
          </section>

          <section className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-900">
                월 예산 요약
              </span>
              <span className="font-mono text-[11px] text-zinc-500">
                가정 환율 1,400원/$
              </span>
            </div>
            <div className="space-y-1 text-xs text-zinc-600">
              <div className="flex justify-between">
                <span>크레딧 비용 + Claude 비용</span>
                <span className="font-mono text-zinc-900">$310 + $40</span>
              </div>
              <div className="flex justify-between border-t border-zinc-100 pt-1.5">
                <span className="font-semibold text-zinc-800">월 합계</span>
                <span className="font-mono text-sm font-bold text-[#1F5E63]">
                  $350 (약 49만 원)
                </span>
              </div>
              <div className="flex justify-between text-[11px] text-zinc-400">
                <span>연간 환산</span>
                <span className="font-mono">$4,200</span>
              </div>
            </div>
          </section>
        </div>

        {/* 수동 입력 + 생성 로그 추가 */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <div className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-3">
            <div>
              <h2 className="text-xs font-bold text-zinc-900">
                이번 달 크레딧 사용량 수동 동기화
              </h2>
              <p className="text-[11px] text-zinc-500">
                외부 대시보드에서 확인한 누적 크레딧 사용량을 수동 입력합니다.
              </p>
            </div>
            <div className="flex flex-wrap items-end gap-2">
              <div className="flex-1 min-w-[140px]">
                <label className="block text-[11px] font-medium text-zinc-600">
                  누적 사용 크레딧
                </label>
                <input
                  type="number"
                  min={0}
                  value={creditInput}
                  onChange={(e) => setCreditInput(e.target.value)}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1.5 font-mono text-xs"
                />
              </div>
              <button
                type="button"
                onClick={() => {
                  const val = Math.max(0, Math.round(Number(creditInput) || 0));
                  setStore((prev) => ({
                    ...prev,
                    budget: { ...prev.budget, creditUsed: val },
                  }));
                  setMsg(`이번 달 크레딧 사용량을 ${val.toLocaleString()}으로 업데이트했습니다.`);
                }}
                className="inline-flex items-center gap-1.5 rounded-[4px] bg-[#1F5E63] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#17494d]"
              >
                <Save className="h-3.5 w-3.5" />
                <span>사용량 저장</span>
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {[
                { label: "60% 기본 (5,640)", val: 5640 },
                { label: "80% 경고 (7,520)", val: 7520 },
                { label: "90% 위험 (8,460)", val: 8460 },
              ].map((preset) => (
                <button
                  key={preset.val}
                  type="button"
                  onClick={() => {
                    setCreditInput(String(preset.val));
                    setStore((prev) => ({
                      ...prev,
                      budget: { ...prev.budget, creditUsed: preset.val },
                    }));
                    setMsg(`${preset.label} 상태로 즉시 변경했습니다.`);
                  }}
                  className="rounded-[3px] border border-zinc-200 bg-zinc-50 px-2 py-0.5 font-mono text-[11px] text-zinc-700 hover:bg-zinc-100"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-3">
            <div>
              <h2 className="text-xs font-bold text-zinc-900">
                회차별 생성 로그 기록 (크레딧 자동 합산)
              </h2>
              <p className="text-[11px] text-zinc-500">
                기록 시 해당 회차 생성 내역과 월 누적 크레딧에 동시에 반영됩니다.
              </p>
            </div>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div>
                <label className="block text-[11px] text-zinc-600">회차</label>
                <select
                  value={epNo}
                  onChange={(e) => setEpNo(Number(e.target.value))}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1 text-xs"
                >
                  {store.episodes.map((e) => (
                    <option key={e.no} value={e.no}>
                      제{e.no}화
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[11px] text-zinc-600">모델</label>
                <select
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1 font-mono text-xs"
                >
                  <option value="seedance-2.0">seedance-2.0</option>
                  <option value="seedance-2.5">seedance-2.5</option>
                  <option value="fast">fast</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] text-zinc-600">목적</label>
                <select
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1 text-xs"
                >
                  <option value="base">base</option>
                  <option value="collection">collection</option>
                  <option value="retry">retry</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] text-zinc-600">시도</label>
                <input
                  type="number"
                  min={1}
                  value={attempts}
                  onChange={(e) => setAttempts(e.target.value)}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1 font-mono text-xs"
                />
              </div>
              <div>
                <label className="block text-[11px] text-zinc-600">채택</label>
                <input
                  type="number"
                  min={0}
                  value={accepted}
                  onChange={(e) => setAccepted(e.target.value)}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1 font-mono text-xs"
                />
              </div>
              <div>
                <label className="block text-[11px] text-zinc-600">크레딧</label>
                <input
                  type="number"
                  min={1}
                  value={credits}
                  onChange={(e) => setCredits(e.target.value)}
                  className="mt-1 w-full rounded-[4px] border border-zinc-300 bg-white px-2 py-1 font-mono text-xs"
                />
              </div>
            </div>
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => {
                  const ep = store.episodes.find((e) => e.no === epNo)!;
                  const cVal = Math.max(1, Number(credits) || 0);
                  setStore((prev) => ({
                    ...prev,
                    runs: [
                      ...prev.runs,
                      {
                        id: Date.now(),
                        episodeId: ep.id,
                        model,
                        purpose,
                        attempts: Math.max(1, Number(attempts) || 1),
                        accepted: Math.max(0, Number(accepted) || 0),
                        credits: cVal,
                        createdAt: new Date().toISOString(),
                      },
                    ],
                    budget: {
                      ...prev.budget,
                      creditUsed: prev.budget.creditUsed + cVal,
                    },
                  }));
                  setCreditInput(String(store.budget.creditUsed + cVal));
                  setMsg(`제${epNo}화 생성 기록(${cVal} 크레딧)을 추가했습니다.`);
                }}
                className="inline-flex items-center gap-1.5 rounded-[4px] bg-[#1F5E63] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#17494d]"
              >
                <PlusCircle className="h-3.5 w-3.5" />
                <span>생성 로그 기록 및 차감</span>
              </button>
            </div>
          </div>
        </div>

        {/* 회차별 소모 표 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 px-4 py-3">
            <div>
              <h2 className="text-xs font-bold text-zinc-900">
                회차별 생성 소모 및 채택률 표
              </h2>
              <p className="text-[11px] text-zinc-500">
                채택률이 기준값 75% 미만인 회차는 재생성 위험으로 강조됩니다.
              </p>
            </div>
            <div className="font-mono text-xs font-semibold text-zinc-700">
              회차 로그 합계: {totalLogged.toLocaleString()} 크레딧
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-zinc-200 bg-zinc-50 text-[11px] font-semibold text-zinc-600">
                  <th className="px-3.5 py-2.5 w-16">회차</th>
                  <th className="px-3.5 py-2.5">제목</th>
                  <th className="px-3.5 py-2.5 text-right">생성 횟수 (시도/채택)</th>
                  <th className="px-3.5 py-2.5 text-right">채택률 (기준 75%)</th>
                  <th className="px-3.5 py-2.5 text-right">소모 크레딧</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200">
                {epStats.map((st) => (
                  <tr
                    key={st.episodeId}
                    className={
                      st.isLowAdoption ? "bg-amber-50/80" : "bg-white"
                    }
                  >
                    <td className="px-3.5 py-2.5 font-mono font-bold">
                      제{st.episodeNo}화
                    </td>
                    <td className="px-3.5 py-2.5 font-medium">
                      <div className="flex items-center gap-2">
                        <span>{st.episodeTitle}</span>
                        {st.isLowAdoption && (
                          <Badge variant="amber">재생성 위험 (&lt;75%)</Badge>
                        )}
                      </div>
                    </td>
                    <td className="px-3.5 py-2.5 text-right font-mono">
                      {st.totalAttempts > 0
                        ? `${st.totalAttempts}회 (${st.totalAccepted}컷 채택)`
                        : "-"}
                    </td>
                    <td className="px-3.5 py-2.5 text-right font-mono">
                      {st.adoptionPercent !== null ? (
                        <span
                          className={`font-semibold ${
                            st.isLowAdoption
                              ? "text-amber-800"
                              : "text-[#1F5E63]"
                          }`}
                        >
                          {st.adoptionPercent}%
                        </span>
                      ) : (
                        <span className="text-zinc-400">미실행</span>
                      )}
                    </td>
                    <td className="px-3.5 py-2.5 text-right font-mono font-semibold">
                      {st.totalCredits > 0
                        ? `${st.totalCredits.toLocaleString()} 크레딧`
                        : "0"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    );
  };

  // --- 화면 7: 컴플라이언스 (/compliance) ---
  const renderCompliance = () => {
    const beforePublishCodes = new Set(
      store.complianceItems
        .filter((i) => i.blockAt === "BEFORE_PUBLISH")
        .map((i) => i.code)
    );
    const riskBlocked = store.episodes.filter((ep) => {
      if (!ep.complianceRisk) return false;
      const epChecks = store.complianceChecks.filter(
        (c) => c.episodeId === ep.id && beforePublishCodes.has(c.itemCode)
      );
      return epChecks.some((c) => !c.done);
    });

    const toggleCheck = (episodeId: number, itemCode: string, done: boolean) => {
      setStore((prev) => ({
        ...prev,
        complianceChecks: prev.complianceChecks.map((c) =>
          c.episodeId === episodeId && c.itemCode === itemCode
            ? { ...c, done }
            : c
        ),
      }));
    };

    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
          <div>
            <h1 className="text-base font-bold text-zinc-900">
              컴플라이언스 게이트 (일본 시장 7항목 × 12화)
            </h1>
            <p className="text-xs text-zinc-500">
              특정상거래법·경품표시법·개인정보보호법·약기법(JP-01~04) 미완료 시 해당 회차의 발행이 차단됩니다.
            </p>
          </div>
          <div className="flex items-center gap-1.5">
            <Badge variant="amber">3·6·7화 약기법 필수</Badge>
            <Badge variant="red">발행 전 차단 4항목</Badge>
          </div>
        </div>

        {riskBlocked.length > 0 ? (
          <div className="flex items-center gap-2 rounded-[6px] border border-red-300 bg-red-50 px-4 py-3 text-xs font-bold text-red-900">
            <ShieldAlert className="h-4 w-4 shrink-0 text-red-600" />
            <span>
              발행 차단 중인 회차 (약기법 필수 대상):{" "}
              {riskBlocked.map((e) => `${e.no}화`).join(", ")}
            </span>
          </div>
        ) : (
          <div className="flex items-center gap-2 rounded-[6px] border border-emerald-300 bg-emerald-50 px-4 py-3 text-xs font-semibold text-emerald-900">
            <CheckCircle2 className="h-4 w-4 text-emerald-700" />
            <span>3·6·7화 약기법 필수 회차의 발행 전 검수가 모두 완료되었습니다.</span>
          </div>
        )}

        <div className="overflow-x-auto rounded-[8px] border border-zinc-200 bg-white">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-200 bg-zinc-50 text-[11px] font-semibold text-zinc-600">
                <th className="px-3 py-2.5 w-64">법규 항목 (7종)</th>
                <th className="px-2 py-2.5 w-20 text-center">차단 시점</th>
                <th className="px-2 py-2.5 w-16 text-center">담당</th>
                {store.episodes.map((ep) => (
                  <th
                    key={ep.id}
                    className={`px-1.5 py-2.5 text-center font-mono ${
                      ep.complianceRisk
                        ? "bg-amber-100/70 text-amber-900 font-bold"
                        : "text-zinc-700"
                    }`}
                  >
                    <div>{ep.no}화</div>
                    {ep.complianceRisk && (
                      <div className="text-[9px] font-sans text-amber-800">
                        약기법
                      </div>
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200">
              {store.complianceItems.map((item) => {
                const isYakgiRow = item.code === "JP-04";
                return (
                  <tr key={item.code} className="hover:bg-zinc-50/70">
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-[11px] font-bold text-[#1F5E63]">
                          {item.code}
                        </span>
                        <span className="font-semibold text-zinc-900">
                          {item.label}
                        </span>
                        {isYakgiRow && (
                          <Badge variant="amber">3·6·7화 필수</Badge>
                        )}
                      </div>
                      <p className="mt-0.5 text-[11px] text-zinc-500 line-clamp-2">
                        {item.detail}
                      </p>
                    </td>
                    <td className="px-2 py-2.5 text-center">
                      <Badge
                        variant={
                          item.blockAt === "BEFORE_PUBLISH" ? "red" : "default"
                        }
                      >
                        {item.blockAt === "BEFORE_PUBLISH"
                          ? "발행 전"
                          : "런칭 시"}
                      </Badge>
                    </td>
                    <td className="px-2 py-2.5 text-center text-[11px] text-zinc-600">
                      {item.ownerRole || "미지정"}
                    </td>
                    {store.episodes.map((ep) => {
                      const chk = store.complianceChecks.find(
                        (c) =>
                          c.episodeId === ep.id && c.itemCode === item.code
                      );
                      const done = chk?.done ?? false;
                      const isMandatory = isYakgiRow && ep.complianceRisk;
                      const isGrey = isYakgiRow && !ep.complianceRisk;

                      return (
                        <td
                          key={ep.id}
                          className={`px-1.5 py-2.5 text-center align-middle ${
                            isMandatory
                              ? done
                                ? "bg-emerald-50/70"
                                : "bg-amber-100/80"
                              : isGrey
                              ? "bg-zinc-100 text-zinc-300"
                              : ""
                          }`}
                        >
                          {isGrey ? (
                            <span className="font-mono text-[10px] text-zinc-400">
                              -
                            </span>
                          ) : (
                            <div className="flex flex-col items-center justify-center gap-0.5">
                              <input
                                type="checkbox"
                                checked={done}
                                onChange={(e) =>
                                  toggleCheck(ep.id, item.code, e.target.checked)
                                }
                                className="h-4 w-4 cursor-pointer accent-[#1F5E63]"
                              />
                              {isMandatory && (
                                <span
                                  className={`text-[9px] font-bold ${
                                    done ? "text-[#1F5E63]" : "text-red-700"
                                  }`}
                                >
                                  필수
                                </span>
                              )}
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  // --- 화면 8: 참여 관리 (/engagement) ---
  const renderEngagement = () => {
    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 pb-3">
          <div>
            <h1 className="text-base font-bold text-zinc-900">
              참여 관리 (응원 게이지 · 팬덤명 후보 · 미션 회수)
            </h1>
            <p className="text-xs text-zinc-500">
              팬 참여형 콘텐츠(편당 4.5시간)의 해금 게이지와 팬덤명 5대 검수 게이트를 운영합니다.
            </p>
          </div>
          <div className="flex items-center gap-1.5">
            <Badge variant="teal">
              SHORTLIST{" "}
              {
                store.fandomCandidates.filter((c) => c.status === "SHORTLIST")
                  .length
              }
              건
            </Badge>
            <Badge variant="default">
              채택 미션{" "}
              {store.missions.filter((m) => m.status === "ADOPTED").length}건
            </Badge>
          </div>
        </div>

        {/* 1. 응원 게이지 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-zinc-100 pb-2.5">
            <div>
              <h2 className="text-xs font-bold text-zinc-900">
                1. 응원 게이지 (해금 트래커)
              </h2>
              <p className="text-[11px] text-zinc-500">
                임계값 달성 시 해금됨 상태로 전환됩니다. (기본 시드: 하루토 얼굴 공개 50%)
              </p>
            </div>
            <Badge variant="default">실시간 연동</Badge>
          </div>

          {store.gauges.map((g) => {
            const isUnlocked = g.unlocked || g.current >= g.threshold;
            return (
              <div
                key={g.id}
                className={`rounded-[6px] border p-3.5 space-y-2.5 ${
                  isUnlocked
                    ? "border-[#1F5E63] bg-[#1F5E63]/5"
                    : "border-zinc-200 bg-zinc-50"
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {isUnlocked ? (
                      <Unlock className="h-4 w-4 text-[#1F5E63]" />
                    ) : (
                      <Lock className="h-4 w-4 text-zinc-400" />
                    )}
                    <span className="text-sm font-bold text-zinc-900">
                      {g.label}
                    </span>
                    {isUnlocked ? (
                      <Badge variant="tealSolid">해금됨</Badge>
                    ) : (
                      <Badge variant="default">잠김 (목표 {g.threshold}%)</Badge>
                    )}
                  </div>
                  <div className="font-mono text-xs font-bold text-zinc-900">
                    현재 {g.current}% / 임계값 {g.threshold}%
                  </div>
                </div>

                <div className="relative h-3 w-full overflow-hidden rounded-[2px] bg-zinc-200">
                  <div
                    className={`h-full transition-all ${
                      isUnlocked ? "bg-[#1F5E63]" : "bg-amber-500"
                    }`}
                    style={{ width: `${Math.min(100, g.current)}%` }}
                  />
                  <div
                    className="absolute inset-y-0 w-0.5 bg-red-600"
                    style={{ left: `${Math.min(100, g.threshold)}%` }}
                  />
                </div>

                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  {[0, 25, 49, 50, 75, 100].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() =>
                        setStore((prev) => ({
                          ...prev,
                          gauges: prev.gauges.map((item) =>
                            item.id === g.id
                              ? {
                                  ...item,
                                  current: pct,
                                  unlocked: pct >= item.threshold,
                                }
                              : item
                          ),
                        }))
                      }
                      className={`rounded-[3px] border px-2 py-1 font-mono text-[11px] font-medium ${
                        g.current === pct
                          ? "border-[#1F5E63] bg-[#1F5E63] text-white"
                          : "border-zinc-300 bg-white text-zinc-700 hover:bg-zinc-100"
                      }`}
                    >
                      {pct}%{pct === g.threshold ? " (해금 기준)" : ""}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </section>

        {/* 2. 팬덤명 후보 검수 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-200 px-4 py-3">
            <div>
              <h2 className="text-xs font-bold text-zinc-900">
                2. 팬덤명 후보 검수 (5대 조건 게이트)
              </h2>
              <p className="text-[11px] text-zinc-500">
                상표·중복·부적절어·발음·3음절 이내 5개 검사를 모두 통과해야만 SHORTLIST로 올릴 수 있습니다.
              </p>
            </div>
            <Badge variant="default">그룹명은 미확정 (B-1 준수)</Badge>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-zinc-200 bg-zinc-50 text-[11px] font-semibold text-zinc-600">
                  <th className="px-3.5 py-2.5 w-24">후보명</th>
                  <th className="px-3.5 py-2.5">제안 이유</th>
                  <th className="px-3.5 py-2.5 w-16 text-right">득표</th>
                  <th className="px-3.5 py-2.5">
                    5개 검사 통과 여부 (클릭 시 전환)
                  </th>
                  <th className="px-3.5 py-2.5 w-28">현재 상태</th>
                  <th className="px-3.5 py-2.5 w-44 text-right">단계 변경</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200">
                {store.fandomCandidates.map((cand) => {
                  const eligible = canShortlist(cand);
                  return (
                    <tr key={cand.id} className="hover:bg-zinc-50">
                      <td className="px-3.5 py-2.5 font-bold text-zinc-900">
                        {cand.name}
                      </td>
                      <td className="px-3.5 py-2.5 text-zinc-600">
                        {cand.reason}
                      </td>
                      <td className="px-3.5 py-2.5 text-right font-mono font-semibold">
                        {cand.votes}표
                      </td>
                      <td className="px-3.5 py-2.5">
                        <div className="flex flex-wrap items-center gap-1.5">
                          {FANDOM_CHECK_META.map((meta) => {
                            const passed = cand[meta.key];
                            return (
                              <button
                                key={meta.key}
                                type="button"
                                title={meta.tooltip}
                                onClick={() =>
                                  setStore((prev) => ({
                                    ...prev,
                                    fandomCandidates: prev.fandomCandidates.map(
                                      (item) => {
                                        if (item.id !== cand.id) return item;
                                        const next = {
                                          ...item,
                                          [meta.key]: !passed,
                                        };
                                        if (
                                          !canShortlist(next) &&
                                          next.status !== "CANDIDATE"
                                        ) {
                                          next.status = "CANDIDATE";
                                        }
                                        return next;
                                      }
                                    ),
                                  }))
                                }
                                className={`inline-flex items-center gap-1 rounded-[2px] border px-1.5 py-0.5 text-[11px] font-medium ${
                                  passed
                                    ? "border-[#1F5E63]/40 bg-[#1F5E63]/10 text-[#1F5E63]"
                                    : "border-red-300 bg-red-50 text-red-700"
                                }`}
                              >
                                {passed ? (
                                  <CheckCircle2 className="h-3 w-3" />
                                ) : (
                                  <XCircle className="h-3 w-3" />
                                )}
                                <span>{meta.label}</span>
                              </button>
                            );
                          })}
                        </div>
                        {!cand.checkChant && (
                          <div className="mt-1 text-[10px] text-red-600">
                            ※ 3음절 이내로 끊어 부를 수 있어야 합니다
                          </div>
                        )}
                      </td>
                      <td className="px-3.5 py-2.5">
                        <Badge
                          variant={
                            cand.status === "SHORTLIST" ? "tealSolid" : "default"
                          }
                        >
                          {cand.status}
                        </Badge>
                      </td>
                      <td className="px-3.5 py-2.5 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            disabled={!eligible || cand.status === "SHORTLIST"}
                            title={
                              eligible
                                ? "SHORTLIST로 승격"
                                : "3음절 이내로 끊어 부를 수 있어야 합니다"
                            }
                            onClick={() =>
                              setStore((prev) => ({
                                ...prev,
                                fandomCandidates: prev.fandomCandidates.map(
                                  (item) =>
                                    item.id === cand.id && canShortlist(item)
                                      ? { ...item, status: "SHORTLIST" }
                                      : item
                                ),
                              }))
                            }
                            className="rounded-[3px] border border-[#1F5E63] bg-[#1F5E63] px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-[#17494d] disabled:cursor-not-allowed disabled:border-zinc-200 disabled:bg-zinc-200 disabled:text-zinc-400"
                          >
                            SHORTLIST
                          </button>
                          {cand.status !== "CANDIDATE" && (
                            <button
                              type="button"
                              onClick={() =>
                                setStore((prev) => ({
                                  ...prev,
                                  fandomCandidates: prev.fandomCandidates.map(
                                    (item) =>
                                      item.id === cand.id
                                        ? { ...item, status: "CANDIDATE" }
                                        : item
                                  ),
                                }))
                              }
                              className="rounded-[3px] border border-zinc-300 bg-white px-2 py-1 text-[11px] text-zinc-600 hover:bg-zinc-100"
                            >
                              해제
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* 3. 미션 회수 트래커 */}
        <section className="rounded-[8px] border border-zinc-200 bg-white">
          <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-3">
            <div>
              <h2 className="text-xs font-bold text-zinc-900">
                3. 회차별 팬 미션 회수 트래커
              </h2>
              <p className="text-[11px] text-zinc-500">
                COLLECTING에서 ADOPTED(채택)로 전환된 미션은 해당 회차 엔딩 크레딧 등재 대상으로 표시됩니다.
              </p>
            </div>
            <Badge variant="teal">{store.missions.length}건</Badge>
          </div>
          <div className="divide-y divide-zinc-200">
            {store.missions.map((ms) => {
              const ep = store.episodes.find((e) => e.id === ms.episodeId);
              const isAdopted = ms.status === "ADOPTED";
              return (
                <div
                  key={ms.id}
                  className={`flex flex-wrap items-center justify-between gap-3 px-4 py-3 text-xs ${
                    isAdopted ? "bg-[#1F5E63]/5" : "bg-white"
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono font-bold text-[#1F5E63]">
                        제{ep?.no ?? ms.episodeId}화
                      </span>
                      <Badge variant="default">
                        {ms.type === "expression" ? "표현 미션" : "팬덤명 공모"}
                      </Badge>
                      <span className="font-semibold text-zinc-900">
                        {ms.body}
                      </span>
                      {isAdopted && (
                        <Badge variant="tealSolid">
                          <Award className="h-3 w-3" /> 엔딩 크레딧 등재 대상
                        </Badge>
                      )}
                    </div>
                    <div className="text-[11px] text-zinc-500">
                      회차: {ep?.title} · 참여 투표 {ms.votes}건
                    </div>
                  </div>
                  <select
                    value={ms.status}
                    onChange={(e) =>
                      setStore((prev) => ({
                        ...prev,
                        missions: prev.missions.map((item) =>
                          item.id === ms.id
                            ? {
                                ...item,
                                status: e.target.value as
                                  | "COLLECTING"
                                  | "ADOPTED"
                                  | "REJECTED",
                              }
                            : item
                        ),
                      }))
                    }
                    className="rounded-[4px] border border-zinc-300 bg-white px-2.5 py-1 text-xs font-semibold"
                  >
                    <option value="COLLECTING">수집중 (COLLECTING)</option>
                    <option value="ADOPTED">
                      채택됨 · 크레딧 대상 (ADOPTED)
                    </option>
                    <option value="REJECTED">보류 (REJECTED)</option>
                  </select>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#f8f9fa] text-zinc-900">
      {/* 모바일 상단 바 (375px ~ 767px) */}
      <header className="md:hidden sticky top-0 z-30 flex items-center justify-between border-b border-zinc-200 bg-white px-3.5 py-2.5">
        <div className="flex items-center gap-2">
          <span className="inline-block h-2.5 w-2.5 rounded-[2px] bg-[#1F5E63]" />
          <span className="text-sm font-semibold tracking-tight text-zinc-900">
            K-soulmate 운영 콘솔
          </span>
        </div>
        <button
          type="button"
          onClick={() => setMobileMenuOpen((prev) => !prev)}
          className="inline-flex items-center justify-center rounded-[4px] border border-zinc-200 p-1.5 text-zinc-700 hover:bg-zinc-100"
        >
          {mobileMenuOpen ? (
            <X className="h-4 w-4" />
          ) : (
            <Menu className="h-4 w-4" />
          )}
        </button>
      </header>

      {/* 모바일 드로어 */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div
            className="fixed inset-0 bg-black/30"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-50 flex w-60 flex-col border-r border-zinc-200 bg-white">
            <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-3">
              <div>
                <p className="text-xs font-semibold text-[#1F5E63]">
                  K-soulmate
                </p>
                <p className="text-sm font-bold text-zinc-900">
                  콘텐츠 운영 콘솔
                </p>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="rounded-[4px] p-1 text-zinc-500 hover:bg-zinc-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <nav className="flex-1 space-y-0.5 p-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = isNavActive(item.key);
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => {
                      setRoute({ page: item.key });
                      setMobileMenuOpen(false);
                    }}
                    className={`flex w-full items-center gap-2.5 rounded-[4px] px-2.5 py-2 text-left text-xs font-medium transition-colors ${
                      active
                        ? "bg-[#1F5E63] text-white"
                        : "text-zinc-700 hover:bg-zinc-100"
                    }`}
                  >
                    <Icon
                      className={`h-4 w-4 shrink-0 ${
                        active ? "text-white" : "text-zinc-500"
                      }`}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="truncate">{item.label}</div>
                      <div
                        className={`truncate text-[10px] ${
                          active ? "text-zinc-200" : "text-zinc-400"
                        }`}
                      >
                        {item.subLabel}
                      </div>
                    </div>
                  </button>
                );
              })}
            </nav>
          </aside>
        </div>
      )}

      {/* 데스크톱 고정 좌측 사이드바 */}
      <aside className="hidden md:flex md:w-56 md:flex-col md:fixed md:inset-y-0 md:left-0 border-r border-zinc-200 bg-white z-20">
        <div className="border-b border-zinc-200 px-4 py-3.5">
          <div className="flex items-center gap-1.5">
            <span className="inline-block h-2 w-2 rounded-[2px] bg-[#1F5E63]" />
            <span className="text-[11px] font-semibold tracking-wider text-[#1F5E63]">
              K-SOULMATE
            </span>
          </div>
          <h1 className="mt-0.5 text-sm font-bold text-zinc-900">
            콘텐츠 운영 콘솔
          </h1>
          <p className="mt-0.5 text-[11px] text-zinc-500">
            5인 · 12화 · 4채널 재조립
          </p>
        </div>

        <nav className="flex-1 space-y-0.5 px-2.5 py-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = isNavActive(item.key);
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => setRoute({ page: item.key })}
                className={`flex w-full items-center gap-2.5 rounded-[4px] px-2.5 py-2 text-left text-xs font-medium transition-colors ${
                  active
                    ? "bg-[#1F5E63] text-white"
                    : "text-zinc-700 hover:bg-zinc-100"
                }`}
              >
                <Icon
                  className={`h-4 w-4 shrink-0 ${
                    active ? "text-white" : "text-zinc-500"
                  }`}
                />
                <div className="min-w-0 flex-1">
                  <div className="truncate leading-snug">{item.label}</div>
                  <div
                    className={`truncate text-[10px] leading-tight ${
                      active ? "text-zinc-200" : "text-zinc-400"
                    }`}
                  >
                    {item.subLabel}
                  </div>
                </div>
              </button>
            );
          })}
        </nav>

        <div className="border-t border-zinc-200 px-4 py-2.5 text-[11px] text-zinc-500 space-y-0.5">
          <div className="flex items-center justify-between">
            <span>운영 단계</span>
            <span className="font-mono font-semibold text-zinc-700">
              Phase 1
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span>주당 기준 공수</span>
            <span className="font-mono text-zinc-700">25.3시간</span>
          </div>
        </div>
      </aside>

      {/* 메인 콘텐츠 영역 */}
      <div className="md:pl-56">
        <main className="mx-auto max-w-6xl px-3.5 py-4 sm:px-5 sm:py-5">
          {route.page === "dashboard" && renderDashboard()}
          {route.page === "members" && renderMembers()}
          {route.page === "episodes" && renderEpisodes()}
          {route.page === "episodeDetail" &&
            renderEpisodeDetail(route.episodeNo, route.channelCode)}
          {route.page === "channelEdit" &&
            renderChannelEditPage(route.episodeNo, route.channelCode)}
          {route.page === "credits" && <CreditsView />}
          {route.page === "compliance" && renderCompliance()}
          {route.page === "engagement" && renderEngagement()}
        </main>
      </div>

      {/* 멤버 상세 모달 */}
      {selectedMember && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-3.5"
          onClick={() => setSelectedMember(null)}
        >
          <div
            role="dialog"
            aria-modal="true"
            className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-[8px] border border-zinc-200 bg-white"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-zinc-200 bg-white px-4 py-3">
              <div className="flex items-center gap-2">
                <span className="rounded-[2px] bg-[#1F5E63] px-1.5 py-0.5 font-mono text-xs font-bold text-white">
                  {selectedMember.id}
                </span>
                <h3 className="text-sm font-bold text-zinc-900">
                  {selectedMember.nameKo} ({selectedMember.nameJa} ·{" "}
                  {selectedMember.nameZh})
                </h3>
                {selectedMember.locked ? (
                  <Badge variant="tealSolid">락 확정</Badge>
                ) : (
                  <Badge variant="amber">락 미확정</Badge>
                )}
              </div>
              <button
                type="button"
                onClick={() => setSelectedMember(null)}
                className="rounded-[4px] p-1 text-zinc-500 hover:bg-zinc-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-4 p-4">
              <div>
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="text-xs font-semibold text-zinc-800">
                    실사 캐릭터 시트 원본 (검증 완료)
                  </span>
                  <span className="font-mono text-[11px] text-zinc-500">
                    {selectedMember.nationality} · {selectedMember.position} ·{" "}
                    {selectedMember.age}세 · {selectedMember.heightCm}cm
                  </span>
                </div>
                <div className="aspect-[4/3] w-full overflow-hidden rounded-[6px] border border-zinc-200 bg-zinc-100">
                  <img
                    src={selectedMember.photoSheetUrl}
                    alt={`${selectedMember.nameKo} 실사 캐릭터 시트`}
                    className="h-full w-full object-contain"
                  />
                </div>
              </div>

              <div className="space-y-3 rounded-[6px] border border-zinc-200 bg-zinc-50 p-3.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-900">
                    생성 고정 프롬프트 (outfitSpec + faceSpec)
                  </span>
                  <button
                    type="button"
                    onClick={(e) => handleCopyPrompt(selectedMember, e)}
                    className="inline-flex items-center gap-1.5 rounded-[4px] bg-[#1F5E63] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#17494d]"
                  >
                    {copiedMemberId === selectedMember.id ? (
                      <>
                        <Check className="h-3.5 w-3.5" /> 복사 완료
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" /> 프롬프트 복사
                      </>
                    )}
                  </button>
                </div>

                <div className="space-y-2 text-xs">
                  <div>
                    <div className="text-[11px] font-semibold text-zinc-500">
                      고정 의상 (outfitSpec)
                    </div>
                    <p className="mt-0.5 rounded-[4px] border border-zinc-200 bg-white p-2 font-mono text-[11px] text-zinc-800">
                      {selectedMember.outfitSpec}
                    </p>
                  </div>
                  <div>
                    <div className="text-[11px] font-semibold text-zinc-500">
                      얼굴 고정 조건 (faceSpec)
                    </div>
                    <p className="mt-0.5 rounded-[4px] border border-zinc-200 bg-white p-2 font-mono text-[11px] text-zinc-800">
                      {selectedMember.faceSpec}
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-[6px] border border-zinc-200 p-3.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-zinc-800">
                    애니메이션 캐릭터 시트
                  </span>
                  {selectedMember.animeSheetUrl ? (
                    <Badge variant="amber">
                      파일럿 테스트 3/5 (그대로 사용 불가)
                    </Badge>
                  ) : (
                    <Badge variant="muted">애니 시트 미제작</Badge>
                  )}
                </div>
                {selectedMember.animeSheetUrl ? (
                  <div className="mt-2 space-y-2">
                    <div className="aspect-[4/3] w-full overflow-hidden rounded-[4px] border border-zinc-200 bg-zinc-100">
                      <img
                        src={selectedMember.animeSheetUrl}
                        alt={`${selectedMember.nameKo} 애니 시트`}
                        className="h-full w-full object-contain"
                      />
                    </div>
                    <p className="text-[11px] text-amber-800">
                      의상(5/5)과 색감은 일치하나 얼굴 동일성 3/5(13~15세로 보임)로 판정되어 실사 시트 참조 변환 방식으로 재시도 예정입니다. (참조:{" "}
                      <span className="font-mono underline">
                        prompts/character-anime.md
                      </span>
                      )
                    </p>
                  </div>
                ) : (
                  <div className="mt-2 flex items-center justify-between rounded-[4px] bg-zinc-50 px-3 py-2 text-[11px] text-zinc-600">
                    <span>
                      애니 시트 미제작 — 실사 시트 참조 변환 방식으로 제작 예정
                    </span>
                    <span className="inline-flex items-center gap-1 font-mono font-medium text-[#1F5E63]">
                      <FileText className="h-3 w-3" />
                      prompts/character-anime.md
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
