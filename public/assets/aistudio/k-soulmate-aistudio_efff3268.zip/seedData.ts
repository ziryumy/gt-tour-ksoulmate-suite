import type {
  ConsoleStoreState,
  Member,
  Channel,
  Episode,
  ChannelVersion,
  ComplianceItem,
  ComplianceCheck,
} from "./types";

const MEMBERS_SEED: Member[] = [
  {
    id: "M1",
    nameKo: "한지후",
    nameJa: "ジフ",
    nameZh: "智厚",
    nationality: "한국",
    position: "리더 · 메인보컬",
    age: 24,
    heightCm: 182,
    photoSheetUrl:
      "https://cdn.omniultra.imagine.art/ceaed39a-684f-4da0-a1e9-ca9f91ee1c26/media/image/61e140b03ebe4296a90e4ccf16d471e6.png",
    animeSheetUrl: null,
    outfitSpec:
      "black tailored blazer worn open over an ivory ribbed turtleneck, straight-leg black trousers, black Chelsea boots, silver band ring",
    faceSpec:
      "Korean man, 24, 182cm lean athletic. Soft dark-brown wavy hair falling over the brow, warm brown eyes, calm mature handsome, understated elegance",
    voiceProfile: "voice-jihu-ko-01",
    channelCode: null,
    locked: true,
  },
  {
    id: "M2",
    nameKo: "이든 박",
    nameJa: "イーデン・パク",
    nameZh: "伊登·朴",
    nationality: "영어권(호주교포)",
    position: "센터 댄서",
    age: 22,
    heightCm: 178,
    photoSheetUrl:
      "https://cdn.omniultra.imagine.art/ceaed39a-684f-4da0-a1e9-ca9f91ee1c26/media/image/3fdc42c697944fc08c64416f4ab76801.png",
    animeSheetUrl: null,
    outfitSpec:
      "black cropped leather biker jacket over a plain black tee, black tapered cargo trousers, chunky black combat boots, thin silver chain necklace",
    faceSpec:
      "Korean-Australian man, 22, 178cm compact dancer build. Jet-black hair with a short undercut, narrow intense eyes, sharp defined jaw",
    voiceProfile: "voice-eden-en-01",
    channelCode: "US",
    locked: true,
  },
  {
    id: "M3",
    nameKo: "린위하오",
    nameJa: "リン・ウィハオ",
    nameZh: "林宇浩",
    nationality: "중화권",
    position: "리드보컬",
    age: 23,
    heightCm: 180,
    photoSheetUrl:
      "https://cdn.omniultra.imagine.art/ceaed39a-684f-4da0-a1e9-ca9f91ee1c26/media/image/df39d50e33424081b9eda2fb5d801c98.png",
    animeSheetUrl: null,
    outfitSpec:
      "slate-grey oversized wool coat worn open over a crisp white shirt, dark indigo straight trousers, black leather loafers, small silver ear stud",
    faceSpec:
      "Taiwanese man, 23, 180cm slim elegant build. Wavy honey-brown hair parted loosely, cat-shaped almond eyes with lifted outer corners, soft features",
    voiceProfile: "voice-weihao-zh-01",
    channelCode: "CN",
    locked: true,
  },
  {
    id: "M4",
    nameKo: "하루토",
    nameJa: "ハルト",
    nameZh: "春人",
    nationality: "일어권",
    position: "서브보컬",
    age: 20,
    heightCm: 175,
    photoSheetUrl:
      "https://cdn.omniultra.imagine.art/ceaed39a-684f-4da0-a1e9-ca9f91ee1c26/media/image/cce760424fbc432f86215e02161ffab0.png",
    animeSheetUrl:
      "https://cdn.omniultra.imagine.art/ceaed39a-684f-4da0-a1e9-ca9f91ee1c26/media/image/0253faf113ac41a39ccab96184458976.png",
    outfitSpec:
      "light washed-blue denim jacket worn open over a plain white tee, cream straight trousers, white low-top sneakers",
    faceSpec:
      "Japanese man, 20, 175cm slender. Fluffy ash-light-brown hair falling naturally over the forehead, large round friendly eyes, youthful boyish features",
    voiceProfile: "voice-haruto-ja-01",
    channelCode: "JP",
    locked: true,
  },
  {
    id: "M5",
    nameKo: "아이만",
    nameJa: "アイマン",
    nameZh: "艾曼",
    nationality: "말레이시아",
    position: "래퍼",
    age: 21,
    heightCm: 176,
    photoSheetUrl:
      "https://cdn.omniultra.imagine.art/ceaed39a-684f-4da0-a1e9-ca9f91ee1c26/media/image/b0c0d3e0fb9b48129ec76e8445e65c7e.png",
    animeSheetUrl: null,
    outfitSpec:
      "oversized charcoal-black hoodie with the hood down, wide-leg black trousers, chunky grey-and-black sneakers, black wristband",
    faceSpec:
      "Malaysian man of Chinese-Malay heritage, 21, 176cm athletic build. Warm tan skin, short textured dark curls on top with closely faded sides, thick defined brows",
    voiceProfile: "voice-aiman-en-01",
    channelCode: "MY",
    locked: true,
  },
];

const CHANNELS_SEED: Channel[] = [
  {
    code: "JP",
    label: "일본 · LINE / YouTube JP",
    narratorId: "M4",
    tone: "일기체 · 1인칭 · 과거 회상",
    totalSec: 90,
    cutCount: 24,
    avgCutSec: 3.8,
    rhythmBasis: "문장 호흡 — 나레이션 대본이 컷 길이를 정한다",
    workflowOrder: ["script", "vo", "cut", "bgm", "subtitle", "publish"],
    bgmTracks: ["jp-01-piano-room", "jp-02-piano-soft", "jp-03-strings-pad"],
    active: true,
  },
  {
    code: "US",
    label: "미국 · TikTok / Reels",
    narratorId: "M2",
    tone: "비트체 · 현재형 · 구어",
    totalSec: 60,
    cutCount: 32,
    avgCutSec: 1.9,
    rhythmBasis: "비트 — BGM 타임라인에 먼저 컷을 맞춘다",
    workflowOrder: ["bgm", "cut", "vo", "subtitle", "publish"],
    bgmTracks: ["us-01-boombap-96", "us-02-trap-92", "us-03-drill-100"],
    active: true,
  },
  {
    code: "KR",
    label: "한국 · Instagram",
    narratorId: "M1",
    tone: "담백체 · 정보 전달",
    totalSec: 90,
    cutCount: 18,
    avgCutSec: 5.0,
    rhythmBasis: "자막 가독 — 자막 읽는 시간이 컷 최소 길이",
    workflowOrder: ["subtitle", "cut", "vo", "bgm", "publish"],
    bgmTracks: ["kr-01-lofi-bright", "kr-02-upbeat-85", "kr-03-soft-pop"],
    active: true,
  },
  {
    code: "CN",
    label: "중화권 · 샤오홍슈",
    narratorId: "M3",
    tone: "감성체 · 짧은 문장",
    totalSec: 88,
    cutCount: 22,
    avgCutSec: 4.0,
    rhythmBasis: "하단 자막 영역 확보 우선",
    workflowOrder: ["subtitle", "cut", "vo", "bgm", "publish"],
    bgmTracks: ["cn-01-citypop-90", "cn-02-citypop-soft", "cn-03-ambient"],
    active: false,
  },
];

const EPISODES_SEED: Episode[] = [
  { id: 1, no: 1, title: "아이스 아메리카노 한 잔 주세요", place: "성수동 카페 (2층 창가)", memberId: "M4", expressions: ["아이스 아메리카노 한 잔 주세요", "얼음은 적게 넣어 주세요", "여기서 마시고 갈게요"], baseVideoUrl: "https://storage.k-soulmate.internal/ep-01-master-130s.mp4", status: "PUBLISHED", complianceRisk: false },
  { id: 2, no: 2, title: "이거 다른 색 있어요?", place: "성수동 편집숍", memberId: "M3", expressions: ["이거 다른 색 있어요?", "한 사이즈 크게 주세요", "입어봐도 돼요?"], baseVideoUrl: "https://storage.k-soulmate.internal/ep-02-master-130s.mp4", status: "REVIEWED", complianceRisk: false },
  { id: 3, no: 3, title: "여기 스타일 좀 바꿔 주세요", place: "협력 · K-pop 헤어메이크업 스튜디오", memberId: "M4", expressions: ["이렇게 스타일링해 주세요", "너무 짧지 않게 해 주세요", "사진처럼 해 주실 수 있어요?"], baseVideoUrl: "https://storage.k-soulmate.internal/ep-03-master-130s.mp4", status: "EDITED", complianceRisk: true },
  { id: 4, no: 4, title: "이 동작 다시 알려 주세요", place: "협력 · K-pop 댄스 트레이닝", memberId: "M5", expressions: ["이 동작 다시 알려 주세요", "조금 천천히 해 주세요", "박자에 맞춰 볼게요"], baseVideoUrl: "https://storage.k-soulmate.internal/ep-04-master-130s.mp4", status: "GENERATED", complianceRisk: false },
  { id: 5, no: 5, title: "여기 줄이에요?", place: "성수동 팝업스토어", memberId: "M2", expressions: ["여기 줄 서는 거예요?", "이거 아직 재고 있어요?", "몇 시까지 해요?"], baseVideoUrl: null, status: "SCRIPTED", complianceRisk: false },
  { id: 6, no: 6, title: "제 피부 고민은요", place: "협력 · 프리미엄 피부과·안티에이징", memberId: "M3", expressions: ["여기서 상담받을 수 있나요?", "제 피부 타입이 어떻게 되나요?", "관리 후 주의할 점이 있나요?"], baseVideoUrl: null, status: "PLANNING", complianceRisk: true },
  { id: 7, no: 7, title: "제 피부 타입 설명해 주세요", place: "협력 · 1:1 뷰티 클래스", memberId: "M2", expressions: ["제 피부는 어떤 타입인가요?", "이 단계는 어떻게 하는 거예요?", "집에서도 이렇게 하면 되나요?"], baseVideoUrl: null, status: "PLANNING", complianceRisk: true },
  { id: 8, no: 8, title: "이 부분 다시 불러 주세요", place: "협력 · K-pop 보컬 트레이닝", memberId: "M3", expressions: ["이 부분 다시 불러 주세요", "숨을 어디서 쉬어야 해요?", "조금 더 감정을 넣어 볼게요"], baseVideoUrl: null, status: "PLANNING", complianceRisk: false },
  { id: 9, no: 9, title: "덜 맵게 해 주세요", place: "성수동 한식당", memberId: "M5", expressions: ["덜 맵게 해 주세요", "뭐가 제일 맛있어요?", "물 좀 더 주시겠어요?"], baseVideoUrl: null, status: "PLANNING", complianceRisk: false },
  { id: 10, no: 10, title: "사진 한 장 찍어 주세요", place: "성수동 사진관", memberId: "M4", expressions: ["여기서 사진 찍어도 돼요?", "한 장만 더 찍어 주세요", "이거 받을 수 있어요?"], baseVideoUrl: null, status: "PLANNING", complianceRisk: false },
  { id: 11, no: 11, title: "5인 합류 · 성수동 전역 미션", place: "성수동 전역", memberId: null, expressions: ["각자 미션 수행", "다섯 명 동시 주문", "합격 판정"], baseVideoUrl: null, status: "PLANNING", complianceRisk: false },
  { id: 12, no: 12, title: "첫 한국어 발표", place: "성수동 (실내)", memberId: null, expressions: ["5분 스피치", "자기소개", "앞으로의 목표"], baseVideoUrl: null, status: "PLANNING", complianceRisk: false },
];

const COMPLIANCE_ITEMS_SEED: ComplianceItem[] = [
  {
    code: "JP-01",
    label: "특정상거래법",
    detail: "일본 소비자에게 유상 판매 시 사업자명·소재지·연락처·반품 조건 등의 표시 의무. 한국 법인이 일본향으로 판매해도 적용.",
    blockAt: "BEFORE_PUBLISH",
    ownerRole: "유키",
  },
  {
    code: "JP-02",
    label: "경품표시법 (현상 제한)",
    detail: "팬덤명 공모의 상품. 일반 현상은 상품 최고액 상한이 있고 초과 설계는 위반. '반드시 당첨' 표시 금지.",
    blockAt: "BEFORE_PUBLISH",
    ownerRole: "유키",
  },
  {
    code: "JP-03",
    label: "개인정보보호법",
    detail: "팬클럽 가입 시 이용 목적 특정·통지, 제3자 제공 제한. 한국 서버 저장은 국경 이전에 해당해 동의·폴리시 기재 필요.",
    blockAt: "BEFORE_PUBLISH",
    ownerRole: "유키",
  },
  {
    code: "JP-04",
    label: "약기법 · 의료광고 가이드라인",
    detail: "제3·6·7화 뷰티·클리닉 회차. 효과효능 표현 불가, 시술 전후 비교 표현 원칙 불가. 촬영 전 표현집 작성 필수.",
    blockAt: "BEFORE_PUBLISH",
    ownerRole: "유키",
  },
  {
    code: "JP-05",
    label: "초상권 · 저작권",
    detail: "협력 매장 스태프 초상 사용 동의, 매장명 노출 범위, BGM 라이선스. 촬영 전 동의서 취득.",
    blockAt: "AT_LAUNCH",
    ownerRole: "유코",
  },
  {
    code: "JP-06",
    label: "AI 생성물 표시",
    detail: "플랫폼마다 AI 생성 라벨 필요 여부가 다름. 각 채널 정책 확인 후 설명란 기재.",
    blockAt: "AT_LAUNCH",
    ownerRole: "유코",
  },
  {
    code: "JP-07",
    label: "LINE 발송 한도",
    detail: "무료 플랜은 월 발송 통수 상한이 있어 주간 발송에는 유료 플랜 필요. 계약 시 최신 조건 확인.",
    blockAt: "AT_LAUNCH",
    ownerRole: "유키",
  },
];

export function createInitialSeedState(): ConsoleStoreState {
  const ep1Narrations: Record<string, string> = {
    JP: `오늘, 처음으로 혼자 주문했어요.\n형은 밖에 나가 있었어요. 저 혼자였어요.\n카운터까지 걸어가는 동안, 손이 조금 떨렸어요.\n「얼음은 적게 넣어 주세요」\n연습한 그 문장이, 제 입에서 나왔어요.\n컵을 받았을 때 —\n아, 왠지 조금 자랑스러웠어요.\n형은 밖에서 웃고 있었어요.`,
    US: `Okay so — watch this.\nHyung dips. Leaves him ALONE.\nJust him, the counter, and pure pressure.\nBarista's like "... you good?"\nAnd he says it. Clean.\n「얼음은 적게」— ICE. LESS.\nMan said it PERFECT. First try. No help.\nOkay okay okay. That's my boy.`,
    KR: `혼자 주문에 성공했습니다.\n오늘 배운 표현은 「얼음은 적게 넣어 주세요」입니다.\n성수동 ○○카페에서 실제로 통하는 문장입니다.\n다음 화는 편의점입니다. 훨씬 어렵습니다.`,
    CN: "",
  };

  const channelVersions: ChannelVersion[] = [];
  let verId = 1;
  for (const ep of EPISODES_SEED) {
    for (const ch of CHANNELS_SEED) {
      let status: ChannelVersion["status"] = "TODO";
      let voStatus: ChannelVersion["voStatus"] = "TODO";
      if (ep.no === 1 && ch.active) {
        status = "DONE";
        voStatus = "DONE";
      } else if (ep.no === 2 && ch.code === "JP") {
        status = "DONE";
        voStatus = "DONE";
      } else if (ep.no === 2 && (ch.code === "US" || ch.code === "KR")) {
        status = "IN_PROGRESS";
        voStatus = "IN_PROGRESS";
      } else if (ep.no === 3 && ch.code === "JP") {
        status = "IN_PROGRESS";
        voStatus = "DONE";
      }

      channelVersions.push({
        id: verId++,
        episodeId: ep.id,
        channelCode: ch.code,
        narration: ep.no === 1 ? ep1Narrations[ch.code] ?? "" : "",
        voStatus,
        bgmTrackId: ch.bgmTracks[0] ?? null,
        cutCount: ch.cutCount,
        totalSec: ch.totalSec,
        status,
        publishedUrl:
          ep.no === 1 && ch.active
            ? `https://social.k-soulmate.internal/${ch.code.toLowerCase()}/ep-01`
            : null,
        publishedAt:
          ep.no === 1 && ch.active ? "2026-10-20T09:00:00.000Z" : null,
      });
    }
  }

  const complianceChecks: ComplianceCheck[] = [];
  let chkId = 1;
  for (const ep of EPISODES_SEED) {
    for (const item of COMPLIANCE_ITEMS_SEED) {
      const done =
        ep.no === 1 ||
        (ep.no === 2 && item.blockAt === "BEFORE_PUBLISH");
      complianceChecks.push({
        id: chkId++,
        episodeId: ep.id,
        itemCode: item.code,
        done,
        owner: item.ownerRole ?? "",
        note: null,
      });
    }
  }

  return {
    members: MEMBERS_SEED,
    channels: CHANNELS_SEED,
    episodes: EPISODES_SEED,
    channelVersions,
    runs: [
      { id: 1, episodeId: 1, model: "seedance-2.0", purpose: "base", attempts: 59, accepted: 44, credits: 1350, createdAt: "2026-10-18T10:00:00.000Z" },
      { id: 2, episodeId: 1, model: "seedance-2.0", purpose: "retry", attempts: 2, accepted: 2, credits: 60, createdAt: "2026-10-19T14:00:00.000Z" },
      { id: 3, episodeId: 2, model: "seedance-2.0", purpose: "base", attempts: 61, accepted: 46, credits: 1410, createdAt: "2026-10-22T11:00:00.000Z" },
      { id: 4, episodeId: 3, model: "seedance-2.5", purpose: "base", attempts: 68, accepted: 44, credits: 1720, createdAt: "2026-10-25T16:00:00.000Z" },
      { id: 5, episodeId: 4, model: "seedance-2.0", purpose: "base", attempts: 52, accepted: 40, credits: 1100, createdAt: "2026-10-27T09:00:00.000Z" },
    ],
    budget: {
      month: "2026-11",
      plan: "ultra",
      creditCap: 9400,
      creditUsed: 5640,
      claudeSeats: 2,
      costUsd: 350,
    },
    complianceItems: COMPLIANCE_ITEMS_SEED,
    complianceChecks,
    missions: [
      { id: 1, episodeId: 1, type: "expression", body: "성수동 카페에서 실제로 쓰는 테이크아웃 표현 추천", votes: 48, status: "ADOPTED" },
      { id: 2, episodeId: 2, type: "expression", body: "편집숍에서 사이즈 교환 요청할 때 자연스러운 한마디", votes: 31, status: "COLLECTING" },
      { id: 3, episodeId: 3, type: "fandom_name", body: "K-soulmate 공식 팬덤명 1차 아이디어 응모", votes: 92, status: "COLLECTING" },
    ],
    fandomCandidates: [
      { id: 1, name: "오롯", reason: "모자람 없이 온전한 다섯 명의 하모니", votes: 142, checkTm: true, checkDup: true, checkWord: true, checkPron: true, checkChant: true, status: "SHORTLIST" },
      { id: 2, name: "이음", reason: "한국어 표현으로 세계 팬들의 마음을 잇다", votes: 118, checkTm: true, checkDup: true, checkWord: true, checkPron: true, checkChant: true, status: "CANDIDATE" },
      { id: 3, name: "가온", reason: "세상의 중심에서 함께 성장하는 메이트", votes: 95, checkTm: true, checkDup: false, checkWord: true, checkPron: true, checkChant: true, status: "CANDIDATE" },
      { id: 4, name: "새김", reason: "매일 세 문장씩 마음에 새기는 기록", votes: 84, checkTm: true, checkDup: true, checkWord: true, checkPron: false, checkChant: true, status: "CANDIDATE" },
      { id: 5, name: "한결", reason: "처음부터 끝까지 한결같은 응원", votes: 63, checkTm: true, checkDup: true, checkWord: true, checkPron: true, checkChant: false, status: "CANDIDATE" },
    ],
    gauges: [
      { id: 1, label: "하루토 얼굴 공개", threshold: 50, current: 0, unlocked: false },
    ],
  };
}

const STORAGE_KEY = "k_soulmate_console_store_v1";

export function loadStore(): ConsoleStoreState {
  if (typeof window === "undefined") {
    return createInitialSeedState();
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const seeded = createInitialSeedState();
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(seeded));
      return seeded;
    }
    return JSON.parse(raw) as ConsoleStoreState;
  } catch {
    return createInitialSeedState();
  }
}

export function saveStore(state: ConsoleStoreState): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore storage quota errors
  }
}
