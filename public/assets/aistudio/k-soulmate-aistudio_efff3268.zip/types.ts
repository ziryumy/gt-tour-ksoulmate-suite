export type EpisodeStatus =
  | "PLANNING"
  | "SCRIPTED"
  | "GENERATED"
  | "EDITED"
  | "REVIEWED"
  | "PUBLISHED";

export type VersionStatus = "TODO" | "IN_PROGRESS" | "DONE" | "BLOCKED";

export interface Member {
  id: string;
  nameKo: string;
  nameJa: string | null;
  nameZh: string | null;
  nationality: string;
  position: string;
  age: number;
  heightCm: number;
  photoSheetUrl: string;
  animeSheetUrl: string | null;
  outfitSpec: string;
  faceSpec: string;
  voiceProfile: string | null;
  channelCode: string | null;
  locked: boolean;
}

export interface Channel {
  code: string; // "JP" | "US" | "KR" | "CN"
  label: string;
  narratorId: string;
  tone: string;
  totalSec: number;
  cutCount: number;
  avgCutSec: number;
  rhythmBasis: string;
  workflowOrder: string[];
  bgmTracks: string[];
  active: boolean;
}

export interface Episode {
  id: number;
  no: number;
  title: string;
  place: string;
  memberId: string | null;
  expressions: string[];
  baseVideoUrl: string | null;
  status: EpisodeStatus;
  complianceRisk: boolean;
}

export interface ChannelVersion {
  id: number;
  episodeId: number;
  channelCode: string;
  narration: string;
  voStatus: VersionStatus;
  bgmTrackId: string | null;
  cutCount: number | null;
  totalSec: number | null;
  status: VersionStatus;
  publishedUrl: string | null;
  publishedAt: string | null;
}

export interface GenerationRun {
  id: number;
  episodeId: number;
  model: string;
  purpose: string;
  attempts: number;
  accepted: number;
  credits: number;
  createdAt: string;
}

export interface BudgetMonth {
  month: string;
  plan: string;
  creditCap: number;
  creditUsed: number;
  claudeSeats: number;
  costUsd: number;
}

export interface ComplianceItem {
  code: string;
  label: string;
  detail: string;
  blockAt: "BEFORE_PUBLISH" | "AT_LAUNCH";
  ownerRole?: string;
}

export interface ComplianceCheck {
  id: number;
  episodeId: number;
  itemCode: string;
  done: boolean;
  owner: string | null;
  note: string | null;
}

export interface Mission {
  id: number;
  episodeId: number;
  type: "expression" | "fandom_name";
  body: string;
  votes: number;
  status: "COLLECTING" | "ADOPTED" | "REJECTED";
}

export interface FandomCandidate {
  id: number;
  name: string;
  reason: string;
  votes: number;
  checkTm: boolean;
  checkDup: boolean;
  checkWord: boolean;
  checkPron: boolean;
  checkChant: boolean;
  status: "CANDIDATE" | "SHORTLIST" | "ADOPTED";
}

export interface Gauge {
  id: number;
  label: string;
  threshold: number;
  current: number;
  unlocked: boolean;
}

export interface ConsoleStoreState {
  members: Member[];
  channels: Channel[];
  episodes: Episode[];
  channelVersions: ChannelVersion[];
  runs: GenerationRun[];
  budget: BudgetMonth;
  complianceItems: ComplianceItem[];
  complianceChecks: ComplianceCheck[];
  missions: Mission[];
  fandomCandidates: FandomCandidate[];
  gauges: Gauge[];
}

export const EPISODE_STATUS_LABELS: Record<EpisodeStatus, string> = {
  PLANNING: "기획",
  SCRIPTED: "대본",
  GENERATED: "생성",
  EDITED: "편집",
  REVIEWED: "검수",
  PUBLISHED: "발행",
};

export const EPISODE_STATUS_ORDER: EpisodeStatus[] = [
  "PLANNING",
  "SCRIPTED",
  "GENERATED",
  "EDITED",
  "REVIEWED",
  "PUBLISHED",
];

export const VERSION_STATUS_LABELS: Record<VersionStatus, string> = {
  TODO: "대기",
  IN_PROGRESS: "진행중",
  DONE: "완료",
  BLOCKED: "차단",
};

export const PURPOSE_LABELS: Record<string, string> = {
  base: "베이스 생성",
  collection: "집합 컷",
  retry: "재생성",
};

export function formatDateDot(dateStr: string | null | undefined): string {
  if (!dateStr) return "-";
  const d = new Date(dateStr);
  if (Number.isNaN(d.getTime())) return "-";
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}.${mm}.${dd}`;
}
